sap.ui.define([
    "sap/m/MessageToast",
    "sap/ui/core/BusyIndicator"
], function (MessageToast, BusyIndicator) {
    'use strict';

    return {
        onPress: function (oEvent) {

        },
        formatThumbnailUrl: function (mediaType) {
            var iconUrl;
            switch (mediaType) {
                case "image/png":
                    iconUrl = "sap-icon://card";
                    break;
                case "text/plain":
                    iconUrl = "sap-icon://document-text";
                    break;
                case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                    iconUrl = "sap-icon://excel-attachment";
                    break;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                    iconUrl = "sap-icon://doc-attachment";
                    break;
                case "application/pdf":
                    iconUrl = "sap-icon://pdf-attachment";
                    break;
                default:
                    iconUrl = "sap-icon://attachment";
            }
        },
        onOpenPressed: async function (oEvent) {
            BusyIndicator.show(); // Show the busy indicator before starting the process
            try {
                oEvent.preventDefault();
                let filename = oEvent.getSource().getBindingContext().getObject().fileName;
                let path = oEvent.getSource().getBindingContext().getObject().folder;

                // Get the signed URL from the backend
                let oFunction = oEvent.getSource().getModel().bindContext("/getFileForVOB(...)");
                oFunction.setParameter("fileName", path); // Use only the filename here, assuming path is included in the backend
                await oFunction.execute();

                // Retrieve the signed URL directly
                let fileUrl = oFunction.getBoundContext().getValue().value;
                let fileExtension = filename.split('.').pop().toLowerCase(); // Extract file extension

                // Check the file type to determine whether to open in a new window or download
                if (["pdf", "png", "jpeg", "jpg"].includes(fileExtension)) {
                    // For PDF and image files, open them in a new window
                    let newWindow = window.open(fileUrl, '_blank');
                    if (!newWindow) {
                        sap.m.MessageToast.show("Please allow pop-ups to view the file.");
                    }
                } else {
                    // For other file types, initiate download
                    let link = document.createElement("a");
                    link.href = fileUrl;
                    link.download = filename; // Set the file name for download
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link); // Clean up
                }
            } catch (error) {
                // Log the error and show a toast message or handle the error
                console.error("An error occurred:", error);
                sap.m.MessageToast.show("An error occurred while opening the file.");
            } finally {
                // Hide the busy indicator after the process is complete (success or failure)
                BusyIndicator.hide();
            }
        },
    };
});
