sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'searchhelpvobrequest/test/integration/FirstJourney',
		'searchhelpvobrequest/test/integration/pages/Sector_searchhelpList',
		'searchhelpvobrequest/test/integration/pages/Sector_searchhelpObjectPage'
    ],
    function(JourneyRunner, opaJourney, Sector_searchhelpList, Sector_searchhelpObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('searchhelpvobrequest') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheSector_searchhelpList: Sector_searchhelpList,
					onTheSector_searchhelpObjectPage: Sector_searchhelpObjectPage
                }
            },
            opaJourney.run
        );
    }
);