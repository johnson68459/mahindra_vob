sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Text",
    "sap/ui/unified/FileUploader",
    "sap/ui/model/json/JSONModel",
    "sap/m/Tree",
    "sap/m/CustomTreeItem",
    "sap/m/HBox",
    "sap/ui/core/Icon",
    "sap/m/library",
    "sap/m/Link",
    "sap/m/BusyDialog",
    "sap/m/MessageBox"
],
    function (Controller, MessageToast, Dialog, Button, Text, FileUploader, JSONModel, Tree, CustomTreeItem, HBox, Icon, mobileLibrary, Link, BusyDialog, MessageBox) {
        "use strict";
        // shortcut for sap.m.ButtonType
        var ButtonType = mobileLibrary.ButtonType;
        var DialogType = mobileLibrary.DialogType;

        var textbox;
        var foldernode1;
        var rolestatus;
        var oBaseUri;
        var fileSizeLimit
        var AllowedFileTypes

        function foldersList(nodes, linktext) {
            if (nodes == undefined) {
                return null;
            }
            for (let i = 0; i < nodes.length; i++) {
                if (nodes[i].text == linktext) {
                    var folder = nodes[i]?.nodes ?? [];
                    return folder;
                }
            }
        }

        var foldernode = [{
            text: "NDA"
        },
        {
            text: "RFQ"
        },
        {
            text: "Quote and Quote Synthesis"
        },
        {
            text: "Quote Backup",
            nodes: [
                {
                    text: "BOP details"
                },
                {
                    text: "Raw Material Details"
                }
            ]
        },
        {
            text: "Supplier Details",
            nodes: [
                {
                    text: "PPT"
                },
                {
                    text: "Assesment Form"
                },
                {
                    text: "Evaluation report"
                },
                {
                    text: "Visit Observations"
                },
                {
                    text: "DSA"
                },
                {
                    text: "COC"
                },
                {
                    text: "IPR Letter Sign-off"
                }

            ]
        },
        {
            text: "Offer price Approval from Bazzar Sales Team"
        },
        {
            text: "SBU VOB FORUM",
            nodes: [
                {
                    text: "PPT"
                },
                {
                    text: "Backup data"
                },
                {
                    text: "Approval"
                },
            ],
        },
        {
            text: "Vendor Code Creation"
        },
        {
            text: "NDA sign-off with Packaging Supplier"
        },
        {
            text: "Packaging Sign-off"
        },
        {
            text: "Proposed and Approved Drawings"
        },
        {
            text: "validation Reports",
            nodes: [
                {
                    text: "DVP Sign-off"
                },
                {
                    text: "Supplier End Testing"
                },
                {
                    text: "Field Testing"
                },
                {
                    text: "3rd Party Testing"
                }
            ]
        },
        {
            text: "Final Drawing Approval for Production"
        },
        {
            text: "VPPAP"
        },
        ]
        var foldernodenew = [{
            text: "NDA"
        },
        {
            text: "RFQ"
        },
        {
            text: "Quote and Quote Synthesis"
        },
        {
            text: "Quote Backup",
            nodes: [
                {
                    text: "BOP details"
                },
                {
                    text: "Raw Material Details"
                }
            ]
        },
        {
            text: "Supplier Details",
            nodes: [
                {
                    text: "PPT"
                },
                {
                    text: "Assesment Form"
                },
                {
                    text: "Evaluation report"
                },
                {
                    text: "Visit Observations"
                },
                {
                    text: "DSA"
                },
                {
                    text: "COC"
                },
                {
                    text: "IPR Letter Sign-off"
                }

            ]
        },
        {
            text: "Offer price Approval from Bazzar Sales Team"
        },
        {
            text: "SBU VOB FORUM",
            nodes: [
                {
                    text: "PPT"
                },
                {
                    text: "Backup data"
                },
                {
                    text: "Approval"
                },
            ],
        },
        {
            text: "Vendor Code Creation"
        },
        {
            text: "NDA sign-off with Packaging Supplier"
        },
        {
            text: "Packaging Sign-off"
        },
        {
            text: "Proposed and Approved Drawings"
        },
        {
            text: "validation Reports",
            nodes: [
                {
                    text: "DVP Sign-off"
                },
                {
                    text: "Supplier End Testing"
                },
                {
                    text: "Field Testing"
                },
                {
                    text: "3rd Party Testing"
                }
            ]
        },
        {
            text: "Final Drawing Approval for Production"
        },
        {
            text: "VPPAP"
        },
        ]

        var _onBreadcrumbPress = (oEvent) => {
            debugger
            var oLink = oEvent.getSource();
            var sPathText = oLink.getText();
            var oModel = oEvent.getSource().getModel("getDocTree");
            var aNavigationStack = oModel.getProperty("/navigationStack");

            // Find the index of the clicked breadcrumb in the path array
            var iBreadcrumbIndex = path.indexOf(sPathText);

            if (iBreadcrumbIndex !== -1) {
                // Update the path array to the clicked breadcrumb level
                path = path.slice(0, iBreadcrumbIndex + 1);
                if (path.length < 2) {
                    var del_upl_button = oEvent.oSource.getParent().getParent().getParent().mAggregations.items[1].mAggregations.items;
                    for (var i = 0; i < del_upl_button.length; i++) {
                        debugger
                        if (del_upl_button[i].getText() == 'Create') {
                            del_upl_button[i].setVisible(true)
                        }
                        else {
                            del_upl_button[i].setVisible(false);
                        }

                    }
                }
                // Update the current items and navigation stack
                var aPreviousItems;
                while (aNavigationStack.length - 1 > iBreadcrumbIndex) {
                    aPreviousItems = aNavigationStack.pop();
                }
                if (aPreviousItems) {
                    oModel.setProperty("/currentItems", aPreviousItems || oModel.getProperty("/rootItems"));
                    oModel.setProperty("/navigationStack", aNavigationStack);
                }


                // Update breadcrumbs
                var oBreadcrumbs = oEvent.getSource().getParent();
                oBreadcrumbs.destroyLinks();
                for (let key in path) {
                    let oLink = new sap.m.Link({ text: path[key], press: _onBreadcrumbPress });
                    oBreadcrumbs.addLink(oLink);
                }
            }

            var pathString = path.length > 0 ? path.join('/') : 'Root';
            console.log(pathString);
        };

        var path = [];

        return Controller.extend("folderstructureapp.controller.Folder", {
            onInit: function () {

            },
            onBeforeRendering: async function (oEvent) {
                const busy = new sap.m.BusyDialog({ text: "Fetching Files, please wait..." });
                try {
                    debugger;


                    busy.open();

                    // Fetch user role
                    const roleContext = this.getView().getModel().bindContext("/getrole(...)");
                    roleContext.setParameter("role", ""); // Assuming 'role' is an input parameter
                    await roleContext.execute();
                    var roleresult = roleContext.getBoundContext().getValue();
                    debugger
                    roleresult = JSON.parse(roleresult.value);
                    fileSizeLimit = roleresult.fileSizeLimit;
                    AllowedFileTypes = roleresult.AllowedFileTypes;


                    // Determine role-based permissions
                    const oList = this.byId("folderList");
                    var isAdmin = roleresult && roleresult.userrole === "Admin";
                    // isAdmin = true;
                    rolestatus = isAdmin;

                    if (isAdmin) {
                        oList.setMode("SingleSelect");
                    } else {
                        oList.setMode("None");
                        this.getView().byId("create").setVisible(false);
                    }
                    // rolestatus = true;
                    // oList.setMode("SingleSelect");

                    // Fetch file list
                    const fileContext = this.getView().getModel().bindContext("/getFilesList(...)");
                    fileContext.setParameter("fileName", ""); // Assuming 'fileName' is an input parameter
                    await fileContext.execute();
                    const fileResult = JSON.parse(fileContext.getBoundContext().getValue().value);
                    debugger

                    console.log(fileResult);

                    // Update tree model with fetched data
                    const folderNodeData = fileResult.nodes[0]?.nodes || [];
                    const treeModel = new sap.ui.model.json.JSONModel({
                        currentItems: folderNodeData,
                        navigationStack: [],
                        previousItems: null,
                        path: []
                    });
                    this.getView().setModel(treeModel, "getDocTree");

                    busy.close();
                } catch (error) {
                    busy.close();
                    MessageToast.show("Failed to Load Files");
                    console.error("Error in onBeforeRendering:", error);
                }
            },
            onAfterRendering: function (oEvent) {
                debugger
                const attachmentSection = document.querySelector(".listClass");
                if (attachmentSection && attachmentSection.parentElement) {
                    attachmentSection.parentElement.style.height = "100%";
                    attachmentSection.parentElement.style.backgroundColor = "#f4f4f4";
                }
                oBaseUri = this.oView.getParent().getParent().getParent()._oManifest._oBaseUri._string;
                // oBaseUri = "/"
            },
            onItemPress: async function (oEvent) {
                // Event handler for item selection
                var oItem = oEvent.getSource();
                var oContext = oItem.getBindingContext("getDocTree");
                var oModel = oEvent.getSource().getModel("getDocTree");
                var oNode = oContext.getObject();
                var oBreadcrumbs = this.byId("oBreadcrumbs");

                // Clear previous breadcrumb links
                oBreadcrumbs.destroyLinks();

                // Rebuild breadcrumb trail from the path
                path.forEach((segment) => {
                    let oLink = new Link({ text: segment, press: _onBreadcrumbPress });
                    oBreadcrumbs.addLink(oLink);
                });

                // If the selected item is a folder (no file extension)
                if (!oNode.text?.includes(".")) {
                    oBreadcrumbs.addLink(new Link({ text: `${oEvent.getSource().getTitle()}` }));
                    path.push(oNode.text);

                    // If the folder has child nodes
                    if (oNode.nodes) {
                        debugger
                        // Save current items to navigation stack
                        var aNavigationStack = oModel.getProperty("/navigationStack") || [];
                        aNavigationStack.push(oModel.getProperty("/currentItems"));
                        oModel.setProperty("/navigationStack", aNavigationStack);

                        // Update model with child nodes
                        oModel.setProperty("/previousItems", oModel.getProperty("/currentItems"));
                        oModel.setProperty("/currentItems", oNode.nodes);


                        // Manage visibility of action buttons based on breadcrumbs
                        if (oBreadcrumbs.getLinks().length >= 2 && rolestatus) {
                            this.getView().byId("delete").setVisible(true);
                            this.getView().byId("upload").setVisible(true);
                            if (rolestatus) {
                                this.getView().byId("create").setVisible(false);
                            }

                        }
                    } else {
                        // Handle empty folders by fetching additional data
                        if (oBreadcrumbs.getLinks().length >= 2 && rolestatus) {
                            this.getView().byId("delete").setVisible(true);
                            this.getView().byId("upload").setVisible(true);
                            if (rolestatus) {
                                this.getView().byId("create").setVisible(false);
                            }

                        }
                        fetchFolderContents.call(this, oNode.text);
                    }
                } else {
                    // Handle non-PDF files
                    fetchAndDownloadFile.call(this, oNode.text);
                }

                // Function to fetch folder contents
                async function fetchFolderContents(folderName) {
                    debugger
                    var pathString = path.length > 0 ? path.join('/') : 'Root';
                    var sFullPath = `/${pathString}`;

                    try {
                        // Call backend to get folder contents
                        var oFunc = this.getView().getModel().bindContext("/getDocumentsByPath(...)");
                        oFunc.setParameter("sPath", sFullPath);

                        var busy = new BusyDialog({ text: "Fetching Data..." });
                        busy.open();
                        await oFunc.execute();
                        busy.close();

                        var result = oFunc.getBoundContext().getValue()?.value ?? '';
                        if (result) {
                            var aFiles = JSON.parse(result).map(filePath => createFileObject(filePath));
                            updateNavigationStackAndModel(aFiles);
                        }
                    } catch (error) {
                        console.error("Error fetching folder contents:", error);
                    }
                }

                // Function to fetch and download non-PDF files
                async function fetchAndDownloadFile(fileName) {
                    var pathString = path.join('/');
                    var sFullPath = `/${pathString}/${fileName}`;

                    var busy = new BusyDialog({ text: "Fetching File..." });
                    busy.open();

                    try {
                        debugger
                        var oFunc = this.getView().getModel().bindContext("/getFile(...)");
                        oFunc.setParameter("fileName", sFullPath);
                        await oFunc.execute();

                        var signedUrl = oFunc.getBoundContext().getValue().value;
                        let fileExtension = sFullPath.split('.').pop().toLowerCase(); // Extract file extension

                        // Check the file type to determine whether to open in a new window or download
                        if (["pdf", "png", "jpeg", "jpg"].includes(fileExtension)) {
                            // For PDF and image files, open them in a new window
                            let newWindow = window.open(signedUrl, '_blank');
                            if (!newWindow) {
                                sap.m.MessageToast.show("Please allow pop-ups to view the file.");
                            }
                        } else {
                            // For other file types, initiate download
                            let link = document.createElement("a");
                            link.href = signedUrl;
                            link.download = sFullPath; // Set the file name for download
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link); // Clean up
                        }

                        busy.close();
                    } catch (error) {
                        console.error("Error fetching file:", error);
                        busy.close();
                    }
                }


                // Utility function to create file object for UI
                function createFileObject(filePath) {
                    debugger
                    var fileName = filePath.split('/').pop();
                    var sText = fileName.toLowerCase();
                    var sIcon = getIconForFile(sText);
                    return { text: fileName, url: filePath, iconUrl: sIcon };
                }

                // Utility function to get icon based on file extension
                function getIconForFile(fileName) {
                    debugger
                    if (fileName.endsWith(".pdf")) return "sap-icon://pdf-attachment";
                    if ([".jpeg", ".jpg", ".png"].some(ext => fileName.endsWith(ext))) return "sap-icon://attachment-photo";
                    if (fileName.endsWith(".mp4")) return "sap-icon://attachment-video";
                    if (fileName.endsWith(".mp3")) return "sap-icon://attachment-audio";
                    return "sap-icon://folder";
                }

                // Function to update navigation stack and model
                function updateNavigationStackAndModel(aFiles) {
                    var aNavigationStack = oModel.getProperty("/navigationStack") || [];
                    aNavigationStack.push(oModel.getProperty("/currentItems"));
                    oModel.setProperty("/navigationStack", aNavigationStack);
                    oModel.setProperty("/currentItems", aFiles);
                }
            },
            onBackPress: async function (oEvent) {
                debugger
                var oModel = this.getView().getModel("getDocTree");
                var aNavigationStack = oModel.getProperty("/navigationStack");

                if (aNavigationStack.length > 0) {
                    // Pop the last item from the navigation stack
                    var busy = new BusyDialog({ text: "Please wait..." });
                    busy.open();
                    var aPreviousItems = aNavigationStack.pop();

                    oModel.setProperty("/currentItems", aPreviousItems);
                    oModel.setProperty("/navigationStack", aNavigationStack);


                    busy.close();

                    path.pop()

                    var oBreadcrumbs = this.byId("oBreadcrumbs");
                    oBreadcrumbs.destroyLinks()
                    for (let key in path) {
                        let oLink = new Link({ text: path[key] });
                        oBreadcrumbs.addLink(oLink);
                    }
                    if (path.length < 2) {
                        this.getView().byId("upload").setVisible(false);
                        this.getView().byId("delete").setVisible(false);
                        if (rolestatus) {
                            this.getView().byId("create").setVisible(true);
                        }


                    }
                    // oBreadcrumbs.addLink(new Link({ text: `${oEvent.getSource().getTitle()}` }))

                    var pathString = path.length > 0 ? path.join('/') : 'Root';
                    console.log(pathString);
                }
            },
            onUploadPress: async function (oEvent) {
                debugger
                var breadlinks = this.getView().byId("oBreadcrumbs").getLinks();
                var linktext;
                var funccall;
                var linklen = breadlinks.length;
                if (linklen == 2) {

                    foldernode = [{
                        text: "NDA"
                    },
                    {
                        text: "RFQ"
                    },
                    {
                        text: "Quote and Quote Synthesis"
                    },
                    {
                        text: "Quote Backup",
                        nodes: [
                            {
                                text: "BOP details"
                            },
                            {
                                text: "Raw Material Details"
                            }
                        ]
                    },
                    {
                        text: "Supplier Details",
                        nodes: [
                            {
                                text: "PPT"
                            },
                            {
                                text: "Assesment Form"
                            },
                            {
                                text: "Evaluation report"
                            },
                            {
                                text: "Visit Observations"
                            },
                            {
                                text: "DSA"
                            },
                            {
                                text: "COC"
                            },
                            {
                                text: "IPR Letter Sign-off"
                            }

                        ]
                    },
                    {
                        text: "Offer price Approval from Bazzar Sales Team"
                    },
                    {
                        text: "SBU VOB FORUM",
                        nodes: [
                            {
                                text: "PPT"
                            },
                            {
                                text: "Backup data"
                            },
                            {
                                text: "Approval"
                            },
                        ],
                    },
                    {
                        text: "Vendor Code Creation"
                    },
                    {
                        text: "NDA sign-off with Packaging Supplier"
                    },
                    {
                        text: "Packaging Sign-off"
                    },
                    {
                        text: "Proposed and Approved Drawings"
                    },
                    {
                        text: "validation Reports",
                        nodes: [
                            {
                                text: "DVP Sign-off"
                            },
                            {
                                text: "Supplier End Testing"
                            },
                            {
                                text: "Field Testing"
                            },
                            {
                                text: "3rd Party Testing"
                            }
                        ]
                    },
                    {
                        text: "Final Drawing Approval for Production"
                    },
                    {
                        text: "VPPAP"
                    },
                    ]

                }
                else if (linklen == 3) {
                    linktext = breadlinks[linklen - 1].getText();
                    foldernode = foldersList(foldernodenew, linktext);
                    console.log(funccall);


                }
                else if (linklen == 4) {
                    linktext = breadlinks[linklen - 2].getText();
                    funccall = foldersList(foldernodenew, linktext);
                    linktext = breadlinks[linklen - 1].getText();
                    foldernode = foldersList(funccall, linktext);
                }
                var vb1 = new sap.m.VBox();
                var oDialog
                var Base64Data
                var folderPath
                var SelectedFile;
                var fileSizeInMb = 50
                if (!oDialog) {
                    oDialog = new Dialog({
                        title: "Upload",
                        type: DialogType.Message,
                        content: [
                            new sap.ui.unified.FileUploader({
                                width: "400px",
                                maximumFileSize: fileSizeLimit,
                                fileType: AllowedFileTypes,
                                fileSizeExceed: function (oEvent) {
                                    debugger
                                    MessageToast.show(`The file size exceeds the allowed limit of ${fileSizeLimit} MB. Please upload a smaller file.`)
                                },
                                change: function (oEvent) {
                                    debugger
                                    var aFiles = oEvent.getParameter("files"); // Get the uploaded file(s)
                                    if (aFiles && aFiles.length > 0) {
                                        var oFile = aFiles[0]; // Get the first file (you can handle multiple files as well)
                                        SelectedFile = oFile;

                                        function readFileAsBase64(oFile) {
                                            return new Promise((resolve, reject) => {
                                                var reader = new FileReader();

                                                reader.onload = function (e) {
                                                    var sBase64 = e.target.result.split(',')[1]; // Extract base64
                                                    resolve(sBase64);
                                                };

                                                reader.onerror = function (error) {
                                                    reject(error);
                                                };

                                                reader.readAsDataURL(oFile); // Start reading the file
                                            });
                                        }

                                        readFileAsBase64(oFile)
                                            .then((sBase64) => {
                                                debugger;
                                                Base64Data = sBase64; // Set base64 data for later use
                                            })
                                            .catch((error) => {
                                                console.error("Error reading file: ", error);
                                            });
                                    }
                                }
                            })
                        ],
                        beginButton: new Button({
                            type: ButtonType.Emphasized,
                            text: "OK",
                            enabled: true,
                            press: async function (oEvent) {
                                debugger
                                let oFileValue = oEvent.getSource().getParent().getContent()[0].getValue();
                                let oList = oEvent.getSource().getParent().getContent()[1].getItems()[0]
                                let selectedItem = oList.getSelectedItem();
                                if (!oFileValue) {
                                    MessageToast.show("Please select the file");
                                    return

                                }
                                else if (!selectedItem && oList.getItems().length != 0) {
                                    MessageToast.show("please select the folder to upload");
                                    return

                                }

                                function sanitizeFileName(fileName) {
                                    // Define allowed characters (letters, numbers, dashes, underscores, and dots)
                                    const sanitizedFileName = fileName.replace(/[^a-zA-Z0-9_\-\.]/g, "_");

                                    // Optionally, limit the length of the file name to a specific number of characters
                                    return sanitizedFileName.substring(0, 255); // Max length of 255 characters
                                }
                                let sanitizedFileName = sanitizeFileName(SelectedFile.name);
                                const fileName = sanitizedFileName;
                                const mediaType = SelectedFile.type || "application/octet-stream";
                                var malwareDetected;
                                var oScanDialog = new sap.m.BusyDialog({
                                    text: "Scanning the file for malware. Please wait..."
                                });
                                oScanDialog.open();

                                const formData = new FormData();
                                formData.append("file", SelectedFile);

                                // await $.ajax({
                                //     url: oBaseUri + "scanMalwareFile",
                                //     type: "POST",
                                //     data: formData,
                                //     processData: false,
                                //     contentType: false,
                                //     success: function (response) {
                                //         debugger
                                //         console.log(response);
                                //         var response = response;
                                //         malwareDetected = response.value.malwareDetected;
                                //         oScanDialog.close()
                                //         if (malwareDetected == true) {
                                //             sap.m.MessageBox.error("Malware detected in the file. Upload aborted.");
                                //         } else {
                                //             sap.m.MessageToast.show("No Malware found. File is safe to upload.");
                                //         }
                                //     },
                                //     error: function (error) {
                                //         debugger
                                //         console.error(error);
                                //     }
                                // });

                                await $.ajax({
                                    url: oBaseUri + `odata/v4/vob/scanMalwareFile`,
                                    type: "POST",
                                    contentType: "application/json",
                                    data: JSON.stringify({
                                        filedata: Base64Data
                                    }),
                                    success: function (response) {
                                        debugger
                                        var response = response;
                                        malwareDetected = response.value.malwareDetected;
                                        oScanDialog.close()
                                        if (malwareDetected == true) {
                                            sap.m.MessageBox.error("Malware detected in the file. Upload aborted.");
                                        } else {
                                            sap.m.MessageToast.show("No Malware found. File is safe to upload.");
                                        }
                                    },
                                    error: function (error) {
                                        debugger;
                                        // BusyIndicator.hide();
                                        console.error("Error retrieving files:", error);
                                        oScanDialog.close()
                                        // Handle error (e.g., show a message to the user)
                                    }
                                });
                                if (malwareDetected == false) {

                                    console.log("Scan complete")

                                    let fullFilePath = `/${path.join('/')}/${folderPath}/${fileName}`;
                                    // let fullFilePath = `/${path.join('/')}/${folderPath}/${oEvent.getSource().getParent().getContent()[0].getValue()}`;
                                    if (!folderPath) {
                                        fullFilePath = `/${path.join('/')}/${fileName}`;
                                    }

                                    let contentType = SelectedFile.type;

                                    // Show a busy dialog to indicate upload process
                                    let busy = new BusyDialog({ text: "Uploading File..." });
                                    busy.open();
                                    var filePath;

                                    try {
                                        // Step 1: Request a signed URL from the backend for Google Cloud Storage
                                        let getSignedURLForFolderStructure = this.getView().getModel().bindContext("/getSignedURLForFolderStructure(...)");
                                        getSignedURLForFolderStructure.setParameter("path", fullFilePath);
                                        getSignedURLForFolderStructure.setParameter("contentType", contentType);
                                        await getSignedURLForFolderStructure.execute();

                                        let signedUrlResponse = getSignedURLForFolderStructure.getBoundContext().getValue();
                                        const signedUrl = signedUrlResponse.signedUrl;
                                        filePath = signedUrlResponse.filePath;

                                        // Step 2: Upload the file to Google Cloud Storage using the signed URL
                                        await $.ajax({
                                            url: signedUrl,
                                            method: "PUT",
                                            contentType: SelectedFile.type,
                                            processData: false,
                                            data: SelectedFile
                                        });
                                        console.log("File uploaded successfully to path:", filePath);

                                        // Step 3: Notify backend about the uploaded file
                                        let notifyBackendForGCS = this.getView().getModel().bindContext("/notifyBackendForGCS(...)");
                                        notifyBackendForGCS.setParameter("fileName", "");
                                        notifyBackendForGCS.setParameter("contentType", "");
                                        notifyBackendForGCS.setParameter("vobid", "");
                                        notifyBackendForGCS.setParameter("path", filePath);
                                        await notifyBackendForGCS.execute();

                                        // Step 4: Fetch the updated file list from the backend
                                        let linksformodel = `/${path.join('/')}`;
                                        let oFunc = this.getView().getModel().bindContext("/getFilesList(...)");
                                        oFunc.setParameter("fileName", linksformodel);
                                        await oFunc.execute();

                                        let result = JSON.parse(oFunc.getBoundContext().getValue().value);
                                        let resultNodes = result.nodes;

                                        // Update the `currentItems` in the model with the fetched file list
                                        let docTreeModel = this.getView().getModel("getDocTree");
                                        docTreeModel.setProperty("/currentItems", resultNodes);
                                        docTreeModel.refresh(true);

                                        // Function to update the navigation stack with the current path
                                        function updateNavigationStackAtPath(navigationStack, currentItems, path) {
                                            const currentItemTexts = currentItems.map(item => item.text);

                                            // Recursive function to locate and update the target node
                                            function updateNodeAtPath(nodes, path, pathIndex) {
                                                if (pathIndex >= path.length) return;

                                                const currentPathText = path[pathIndex];
                                                let targetNode = nodes.find(node => node.text === currentPathText);

                                                if (!targetNode) return;

                                                if (pathIndex === path.length - 1) {
                                                    // Update `nodes` of the final path node
                                                    targetNode.nodes = currentItems;
                                                } else if (targetNode.nodes) {
                                                    // Traverse deeper into the path
                                                    updateNodeAtPath(targetNode.nodes, path, pathIndex + 1);
                                                }
                                            }

                                            // Start the recursive update for each level in the navigation stack
                                            navigationStack.forEach(stackLevel => {
                                                updateNodeAtPath(stackLevel, path, 0);
                                            });

                                            return navigationStack;
                                        }

                                        // Step 5: Update the navigation stack and refresh the model
                                        let navigationStack = docTreeModel.getProperty("/navigationStack");
                                        const updatedNavigationStack = updateNavigationStackAtPath(navigationStack, resultNodes, path);
                                        docTreeModel.setProperty("/navigationStack", updatedNavigationStack);
                                        docTreeModel.refresh(true);

                                        console.log("Updated Navigation Stack:", updatedNavigationStack);
                                        // MessageToast.show(`File uploaded to successfully to file path ${filePath}`)

                                    } catch (error) {
                                        console.error("Error during file upload or processing:", error);
                                    } finally {
                                        // Close the busy dialog
                                        busy.close();
                                        oDialog.close();
                                        sap.m.MessageBox.success(`File successfully uploaded to the file path: ${filePath}`, {
                                            title: "Success",

                                        });

                                    }
                                }
                                else {
                                    MessageToast.show("File contains Malware");
                                }



                            }.bind(this)
                        }),
                        endButton: new Button({
                            text: "Cancel",
                            press: function () {
                                oDialog.close();
                            }.bind(this)
                        })
                    });

                }
                var mainNode = foldernode;

                var treeModel = new JSONModel({ treeModel: { nodes: mainNode } });

                console.log("Mainnode", mainNode);
                var oTree = new Tree({
                    mode: "SingleSelect",
                    items: {
                        path: "/treeModel/nodes",
                        template: new CustomTreeItem({
                            content: new HBox({
                                items: [
                                    new Icon({ src: 'sap-icon://folder-blank' }).addStyleClass("iconWithMargin"),
                                    new Text({ text: '{text}' }).addStyleClass("text").addStyleClass("text"),
                                    // new Icon({ src: 'sap-icon://message-success' })
                                ]
                            }).addStyleClass("TreeHboxClass"),
                        })
                    },
                    selectionChange: function (oEvent) {
                        debugger
                        var aSelectedItems = oTree.getSelectedItems();
                        console.log("Tree selectionChange event triggered");

                        if (aSelectedItems.length > 0) {
                            var oSelectedItem = aSelectedItems[0];
                            var oBindingContext = oSelectedItem.getBindingContext();
                            var selectedNode = oBindingContext.getObject();

                            // Check if the selected node has any child nodes
                            if (selectedNode.nodes && selectedNode.nodes.length > 0) {
                                // Clear the selection if the selected node is not a leaf node
                                oTree.removeSelections(true);
                                MessageToast.show("Selection cleared. Only leaf nodes can be selected.");
                                textbox.setText("Click on the folder to select path");
                                oAcceptButton.setEnabled(false);
                                console.log("Selection cleared. Only leaf nodes can be selected.");
                            } else {
                                // Proceed with your existing logic for handling selection of a leaf node
                                var sPath = oBindingContext.getPath();
                                console.log("Selected Path: " + sPath);

                                function getNodeTextFromPath(nodes, path) {
                                    var pathComponents = path.split('/').filter(Boolean);
                                    var currentNodes = nodes;
                                    var textAsPath = '';

                                    for (var i = 0; i < pathComponents.length; i++) {
                                        var index = parseInt(pathComponents[i], 10);
                                        if (isNaN(index) || index < 0 || index >= currentNodes.length) {
                                            continue;
                                        }
                                        var currentNode = currentNodes[index];
                                        textAsPath += (textAsPath ? '/' : '') + currentNode.text;
                                        currentNodes = currentNode.nodes || [];
                                    }

                                    return textAsPath;
                                }

                                var folder_path = getNodeTextFromPath(mainNode, sPath);
                                console.log("Text at path:", folder_path);
                                textbox.setText(folder_path);
                                folderPath = folder_path;


                            }
                        }
                    }
                });
                oTree.setModel(treeModel);
                vb1.addItem(oTree);
                textbox = new sap.m.Text({ text: "Click on the folder to select path" });
                vb1.addItem(
                    textbox
                )


                oDialog.addContent(vb1);



                oDialog.open();
            },
            onDeletePress: async function (oEvent) {

                debugger;
                var that = this;
                var oList = that.byId("folderList");
                if (oList.getSelectedItem() == null) {
                    let error = MessageBox.error("File not selected", {
                        title: "Error"
                    });

                }
                else {
                    var success = MessageBox.confirm("Do you want to delete the file?", {
                        title: "Delete",

                        onClose: async function (status) {
                            debugger
                            if (status == "OK") {
                                debugger

                                // Create the path string
                                let pathString = path.length > 0 ? path.join('/') : 'Root';

                                // Get the selected item's title (file name)
                                let oFileName = oList.getSelectedItem().getTitle();

                                // Append the file name to the path
                                pathString = "/" + pathString + "/" + oFileName;

                                // Check if the selected item has a file extension
                                if (/\.[^\.]+$/.test(oFileName)) {
                                    console.log("The string has an extension.");

                                    // Prepare the function call for deleting the file
                                    var oFunc = that.getView().getModel().bindContext("/deleteFile(...)");

                                    // Set the file name as a parameter for the delete function
                                    oFunc.setParameter("fileName", pathString);

                                    try {
                                        var busy = new BusyDialog({ text: "Deleting File..." });
                                        busy.open();
                                        // Execute the function call asynchronously
                                        await oFunc.execute();

                                        // Retrieve the result of the function execution
                                        busy.close();
                                        var result = oFunc.getBoundContext()?.getValue()?.value ?? '';

                                        // Show a success message with the result
                                        // MessageToast.show(result);
                                        var success = new MessageBox.success(result, {
                                            title: "Success",
                                        });

                                        // ==========================
                                        // Update the model after deletion
                                        // ==========================

                                        var linksformodel = `/${path.join('/')}`;
                                        console.log();
                                        var oFunc = that.getView().getModel().bindContext("/getFilesList(...)");
                                        oFunc.setParameter("fileName", linksformodel);

                                        await oFunc.execute();
                                        var result = oFunc.getBoundContext().getValue();
                                        result = JSON.parse(result.value);

                                        debugger



                                        debugger
                                        // Get the current items from the model
                                        var currentItems = that.getView().getModel("getDocTree").getProperty("/currentItems");
                                        var resultNodes = result.nodes;

                                        that.getView().getModel("getDocTree").setProperty("/currentItems", resultNodes);

                                        // Get currentItems from the model
                                        var getDocTreeData = that.getView().getModel("getDocTree");

                                        function updateNavigationStackAtPath(navigationStack, currentItems, path) {

                                            // Convert current items to a simplified format for easier comparison
                                            const currentItemTexts = currentItems.map(item => item.text);

                                            // Recursive function to locate the node at the specified path
                                            function updateNodeAtPath(nodes, path, pathIndex) {
                                                if (pathIndex >= path.length) return; // Exit if path is fully traversed

                                                // Get the current path text to match
                                                const currentPathText = path[pathIndex];
                                                let targetNode = nodes.find(node => node.text === currentPathText);

                                                if (!targetNode) return; // Exit if path segment not found

                                                if (pathIndex === path.length - 1) {
                                                    // We've reached the final node in the path, so update its `nodes` with `currentItems`
                                                    targetNode.nodes = currentItems;
                                                } else if (targetNode.nodes) {
                                                    // Continue deeper along the path
                                                    updateNodeAtPath(targetNode.nodes, path, pathIndex + 1);
                                                }
                                            }

                                            // Start the recursive update
                                            navigationStack.forEach((stackLevel) => {
                                                updateNodeAtPath(stackLevel, path, 0);
                                            });

                                            return navigationStack;
                                        }

                                        // Example usage:
                                        let navigationStack = that.getView().getModel("getDocTree").getProperty("/navigationStack");
                                        var currentItems = that.getView().getModel("getDocTree").getProperty("/currentItems");


                                        const updatedNavigationStack = updateNavigationStackAtPath(navigationStack, currentItems, path);

                                        // Update model and refresh to reflect changes in the UI
                                        that.getView().getModel("getDocTree").setProperty("/navigationStack", updatedNavigationStack);
                                        that.getView().getModel("getDocTree").refresh(true);
                                        // getDocTreeData.setProperty("/currentItems", currentItems);


                                        // Refresh the model to reflect changes in the UI
                                        getDocTreeData.refresh(true);



                                    } catch (error) {
                                        // Log or handle any error that might occur during execution
                                        console.error("Error deleting file: ", error);
                                        MessageToast.show("An error occurred while deleting the file.");
                                    }
                                }
                                else {
                                    let error = MessageBox.error("Select a File not a Folder", {
                                        title: "Error"
                                    });
                                }
                            }
                            // Your press event logic here
                            console.log("Message box closed. Perform further actions if needed.");
                        },
                        onOk: function () {
                            debugger
                        }
                    })
                }
            },
            onCreatePress: async function (oEvent) {
                debugger;
                var that = this;

                // Busy Dialog instance
                var oBusyDialog = new sap.m.BusyDialog({
                    text: "Loading data, please wait..."
                });

                try {
                    // Show Busy Dialog before starting the AJAX call
                    oBusyDialog.open();

                    if (path.length != 0) {
                        await $.ajax({
                            url: oBaseUri + 'odata/v4/vob/vendorsearchhelp',
                            method: 'GET',
                            success: function (data) {
                                debugger;
                                var oModel = new sap.ui.model.json.JSONModel();
                                oModel.setData(data.value);
                                that.getView().setModel(oModel, "headerVHData");

                                // Open the dialog
                                if (!that.pDialogVendorDetails) {
                                    that.pDialogVendorDetails = sap.ui.xmlfragment("folderstructureapp.view.VHVendorDetails", that);
                                    that.getView().addDependent(that.pDialogVendorDetails);
                                }
                                that.pDialogVendorDetails.open();
                            },
                            error: function (error) {
                                debugger;
                                sap.m.MessageToast.show("Failed to load F4 values.");
                            }
                        });
                    } else {
                        await $.ajax({
                            url: oBaseUri + 'odata/v4/vob/materialsearchhelp',
                            method: 'GET',
                            dataType: "json",
                            success: function (data) {
                                debugger;
                                var oModel = new sap.ui.model.json.JSONModel();
                                oModel.setData(data.value);
                                that.getView().setModel(oModel, "headerMData");

                                // Open the dialog
                                if (!that.pDialogMaterialNo) {
                                    that.pDialogMaterialNo = sap.ui.xmlfragment("folderstructureapp.view.VHMaterialNo", that);
                                    that.getView().addDependent(that.pDialogMaterialNo);
                                }
                                that.pDialogMaterialNo.open();
                            },
                            error: function (error) {
                                debugger;
                                sap.m.MessageToast.show("Failed to load F4 values.");
                            }
                        });
                    }
                } catch (e) {
                    // Error handling
                    oBusyDialog.close();
                    sap.m.MessageToast.show("An error occurred while loading data.");
                } finally {
                    // Close Busy Dialog regardless of success or failure
                    oBusyDialog.close();
                }
            },
            onSelectionChange: function (oEvent) {
                debugger;
                let currentName = oEvent.getSource().getSelectedItem().getTitle();
                console.log(currentName);

            },
            fnHandleMaterialNoConfirm: async function (oEvents) {
                debugger;
                // Busy Dialog instance
                var oBusyDialog = new sap.m.BusyDialog({
                    text: "Processing your request, please wait..."
                });
                try {
                    oBusyDialog.open();
                    var oModel = this.getView().getModel();
                    var Material = oEvents.mParameters.selectedItem.mProperties.label;

                    // Call the Function Import
                    var Materialapi = this.getView().getModel().bindContext("/create_folder(...)");
                    Materialapi.setParameter("path", Material);
                    await Materialapi.execute();
                    window.location.reload();
                } catch (error) {
                    oBusyDialog.close();
                    console.log(error);
                    MessageToast.show("Error Occurred");
                } finally {
                    oBusyDialog.close();
                }

            },
            fnHandleMaterialNoSearch: async function (oEvent) {
                debugger;
                var headerMData = oEvent.getSource().getModel("headerMData");
                var materialNo = oEvent.getParameters().value;
                try {
                    // Perform the AJAX GET call
                    var response = await $.ajax({
                        url: oBaseUri + `odata/v4/vob/materialsearchhelp?$filter=contains(materialname,'${materialNo}')`,
                        method: 'GET',
                        dataType: "json"
                    });

                    // Check if response data exists and update the model
                    if (response) {
                        debugger
                        headerMData.setData(response.value); // Set the new data to the model
                        headerMData.refresh(true);     // Refresh the model to reflect changes on the UI
                        sap.m.MessageToast.show("Material search data loaded successfully.");
                    }
                } catch (error) {
                    // Handle errors in the AJAX call
                    debugger;
                    sap.m.MessageToast.show("Failed to load material search values.");
                }
            },

            fnHandleVendorConfirm: async function (oEvents) {
                debugger;
                // Busy Dialog instance
                var oBusyDialog = new sap.m.BusyDialog({
                    text: "Processing your request, please wait..."
                });
                try {
                    oBusyDialog.open();
                    var oModel = this.getView().getModel();
                    var Vendor = oEvents.mParameters.selectedItem.mProperties.title;

                    // Call the Function Import
                    var Vendorapi = this.getView().getModel().bindContext("/create_folder(...)");
                    const vendorName = path + '/' + Vendor;
                    Vendorapi.setParameter("path", vendorName);
                    await Vendorapi.execute();
                    debugger
                    let linksformodel = `/${path.join('/')}`;
                    let oFunc = this.getView().getModel().bindContext("/getFilesList(...)");
                    oFunc.setParameter("fileName", linksformodel);
                    await oFunc.execute();

                    let result = JSON.parse(oFunc.getBoundContext().getValue().value);
                    let resultNodes = result.nodes;

                    // Update the `currentItems` in the model with the fetched file list
                    let docTreeModel = this.getView().getModel("getDocTree");
                    docTreeModel.setProperty("/currentItems", resultNodes);
                    docTreeModel.refresh(true);

                    // Function to update the navigation stack with the current path
                    function updateNavigationStackAtPath(navigationStack, currentItems, path) {
                        const currentItemTexts = currentItems.map(item => item.text);

                        // Recursive function to locate and update the target node
                        function updateNodeAtPath(nodes, path, pathIndex) {
                            if (pathIndex >= path.length) return;

                            const currentPathText = path[pathIndex];
                            let targetNode = nodes.find(node => node.text === currentPathText);

                            if (!targetNode) return;

                            if (pathIndex === path.length - 1) {
                                // Update `nodes` of the final path node
                                targetNode.nodes = currentItems;
                            } else if (targetNode.nodes) {
                                // Traverse deeper into the path
                                updateNodeAtPath(targetNode.nodes, path, pathIndex + 1);
                            }
                        }

                        // Start the recursive update for each level in the navigation stack
                        navigationStack.forEach(stackLevel => {
                            updateNodeAtPath(stackLevel, path, 0);
                        });

                        return navigationStack;
                    }

                    // Step 5: Update the navigation stack and refresh the model
                    let navigationStack = docTreeModel.getProperty("/navigationStack");
                    const updatedNavigationStack = updateNavigationStackAtPath(navigationStack, resultNodes, path);
                    docTreeModel.setProperty("/navigationStack", updatedNavigationStack);
                    docTreeModel.refresh(true);

                    console.log("Updated Navigation Stack:", updatedNavigationStack);
                } catch (error) {
                    oBusyDialog.close();
                    console.log(error);
                    MessageToast.show("Error Occurred");
                } finally {
                    oBusyDialog.close();
                }
            },
            fnHandleVendorSearch: async function (oEvent) {
                debugger
                var headerVHData = oEvent.getSource().getModel("headerVHData");
                var vendorValue = oEvent.getParameters().value;
                try {
                    // Perform the AJAX GET call
                    var response = await $.ajax({
                        url: oBaseUri + `odata/v4/vob/vendorsearchhelp?$filter=contains(lifnr,'${vendorValue}') or contains(name,'${vendorValue}')`,
                        method: 'GET',
                        dataType: "json"
                    });

                    // Check if response data exists and update the model
                    if (response) {
                        debugger
                        headerVHData.setData(response.value); // Set the new data to the model
                        headerVHData.refresh(true);     // Refresh the model to reflect changes on the UI
                        sap.m.MessageToast.show("Vendor search data loaded successfully.");
                    }
                } catch (error) {
                    // Handle errors in the AJAX call
                    debugger;
                    sap.m.MessageToast.show("Failed to load material search values.");
                }
            }
        });
    });
