sap.ui.define([
    "sap/m/MessageToast"
], function (MessageToast) {
    'use strict';

    return {
        onsaveclick: async function (oEvent) {
            debugger
            var busy = new sap.m.BusyDialog({ text: "Please Wait..!" });
            try {
                busy.open();
                /**
                 * Retrieves the comment values and formats them with labels.
                 * @returns {Array} An array of formatted comment strings.
                */
                function getFormattedComments() {
                    const commentIds = {
                        cashflowcmt: "Cash Flow",
                        riskcomment: "Risk Analysis",
                        investmentcomment: "Investment Breakup"
                    };

                    return Object.entries(commentIds).reduce((comments, [idSuffix, label]) => {
                        const inputField = sap.ui.getCore().byId(jQuery(`[id$='${idSuffix}']`).attr("id"));
                        if (inputField) {
                            const value = inputField.getValue();
                            if (value) comments.push(`${label}: ${value}`);
                        }
                        return comments;
                    }, []);
                }
                /**
                 * Extracts the UUID from the current URL.
                 * @returns {string|null} The extracted UUID or null if not found.
                */
                function extractUuidFromUrl() {
                    const url = window.location.hash;
                    const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                    const matches = url.match(regex);
                    return matches?.[1] || null;
                }
                /**
                 * Calls the backend function to save comments.
                 * @param {string} uuid The unique identifier for the request.
                 * @param {Array} comments An array of formatted comments.
                 * @param {Object} model The model instance to bind the function.
                 * @returns {Promise<void>}
                */
                async function saveComments(vobId, comments, model) {
                    if (!vobId || comments.length === 0) {
                        console.warn("No UUID or comments to save.");
                        return;
                    }

                    const payload = {
                        id: vobId,
                        comment_value: comments,
                        status: "screen2commentview"
                    };

                    try {
                        const oFunctionComment = model.bindContext("/commentadd(...)");
                        oFunctionComment.setParameter("status", JSON.stringify(payload));
                        await oFunctionComment.execute();
                        console.log("Comments saved successfully.");
                    } catch (error) {
                        console.error("Error saving comments:", error);
                    }
                }
                const comments = getFormattedComments();
                const vobId = extractUuidFromUrl();
                const model = this.getModel();
                var old_supp = 0;

                await saveComments(vobId, comments, model);

             
                // Arrays to store old supplier details and part details

                var supplier_details_old = [];
                var partdetails = [];

                /**
                 * Function to save cashflow details.
                 */
                function cashflowSave() {
                    // Retrieve UI elements by their IDs
                    var supplierHBox = sap.ui.getCore().byId(jQuery("[id$='HboxSupplier']").attr("id"));
                    var parttable = sap.ui.getCore().byId(jQuery("[id$='parentTable']").attr("id"));
                    var itemparttable_part = sap.ui.getCore().byId(jQuery("[id$='parentTableitem']").attr("id"));

                    // Loop through the rows of the part table starting from the second row (index 1)
                    for (let i = 1; i < parttable.getItems().length; i++) {
                        var rowid = parttable.mAggregations.items[i].oModels.rowid ?? ''; // Retrieve row ID
                        var length = parttable.mAggregations.items[i]?.mAggregations?.cells[0]?.mAggregations?.items?.length ?? ''; // Check if cells have items

                        // If the row contains valid data, extract and store it in partdetails
                        if (length) {
                            var rowdetails = {
                                "id": `${rowid.oData.rowid}`, // Row ID
                                "msgp_supplier_name": `${parttable.mAggregations.items[i].mAggregations.cells[0].mAggregations.items[1].mProperties.value}`, // Supplier name
                                "mgsp_vendor_inco_term": `${parttable.mAggregations.items[i].mAggregations.cells[0].mAggregations.items[2].mProperties.value}`, // Inco term
                                "existing_mgsp_po_price": `${parttable.mAggregations.items[i].mAggregations.cells[0].mAggregations.items[3].mProperties.value}`, // PO price
                                "target_price": `${parttable.mAggregations.items[i].mAggregations.cells[0].mAggregations.items[4].mProperties.value}`, // Target price
                                "supplierid": `${parttable.mAggregations.items[i].oModels?.supplierid?.oData?.supplierid ?? ''}`, // Supplier ID
                                "finished_weight_of_part": `${itemparttable_part.mAggregations.items[i - 1].mAggregations.cells[1].mProperties.value ?? ''}` // Finished weight
                            };
                            partdetails.push(rowdetails); // Add row details to partdetails array
                        } else {
                            break; // Exit loop if no valid data is found
                        }
                    }

                    // Loop through the items in the supplier HBox
                    for (let supplier of supplierHBox.getItems()) {
                        var supplier_details = [];

                        // Add base supplier details for the first item
                        supplier_details.push({
                            "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                            "value_key": `${parttable.mAggregations.items[0].oModels.rowid.oData.rowid}`, // Key from the first part table row
                            "value": `${supplier.mAggregations.items[0].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from the first supplier item
                        });

                        // Loop through partdetails and map corresponding supplier details
                        for (let i = 1; i < partdetails.length + 1; i++) {
                            var supplier_detail = {
                                "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                "value_key": `${parttable.mAggregations.items[i].oModels.rowid.oData.rowid}`, // Part table row ID
                                "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from supplier item
                            };
                            supplier_details.push(supplier_detail);
                        }

                        // Handle additional rows beyond partdetails
                        for (let i = partdetails.length + 1; i < supplier.getItems().length; i++) {
                            var supplier_detail;
                            if (parttable.getItems()[i].getCells()[0].mAggregations.items) {
                                supplier_detail = {
                                    "id_supplier": ``, // No supplier ID
                                    "value_key": `${parttable.mAggregations.items[i].mAggregations.cells[0].getItems()[1].getValue()}`, // Key from additional row
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value
                                };
                            } else {
                                supplier_detail = {
                                    "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                    "value_key": `${parttable.mAggregations.items[i].mAggregations.cells[0].mProperties.value}`, // Key from part table
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value
                                };
                            }
                            supplier_details.push(supplier_detail); // Add details
                        }
                            supplier_details_old.push(supplier_details); // Add to old supplier details
                     
                    }
                }

                // Call the cashflowSave function
                cashflowSave();





                /**
                 * Function to save investment breakup details.
                 */
                function investmentbreakupSave() {
                    // Retrieve the supplier HBox element for investment breakup
                    var invsupplierHBox = sap.ui.getCore().byId(jQuery("[id$='HboxSupplierinvestment']").attr("id"));

                    // Retrieve the part table element for investment breakup
                    var invparttable = sap.ui.getCore().byId(jQuery("[id$='parentTableinvestment']").attr("id"));

                    // Loop through each supplier in the HBox
                    for (let supplier of invsupplierHBox.getItems()) {
                      

                        var supplier_details = []; // Array to hold the details of the current supplier

                        // Loop through the items of the current supplier
                        for (let i = 0; i < supplier.getItems().length; i++) {
                            var supplier_detail; // Variable to hold individual supplier detail

                            // Check if the part table cell contains aggregated items
                            if (invparttable.getItems()[i].getCells()[0].mAggregations.items) {
                                // If aggregated items are present, retrieve values dynamically
                                supplier_detail = {
                                    "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                    "value_key": `${invparttable.mAggregations.items[i].mAggregations.cells[0].getItems()[1].getValue()}`, // Key from the aggregated cell
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from the supplier item
                                };
                            } else {
                                // If no aggregated items, retrieve values from the cell properties
                                supplier_detail = {
                                    "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                    "value_key": `${invparttable.mAggregations.items[i].mAggregations.cells[0].mProperties.value}`, // Key from the cell properties
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from the supplier item
                                };
                            }

                            supplier_details.push(supplier_detail); // Add the supplier detail to the array
                        }

                        // Append the current supplier details to the old supplier details array
                        Array.prototype.push.apply(supplier_details_old[old_supp], supplier_details);

                        old_supp++; // Increment the index for old suppliers
                    }
                }

                // Call the investmentbreakupSave function
                investmentbreakupSave();



                /**
                 * Function to save item data details.
                 */
                function itemDataSave() {
                    // Retrieve the supplier HBox element for item data
                    var itemsupplierHBox = sap.ui.getCore().byId(jQuery("[id$='HboxSupplieritem']").attr("id"));

                    // Retrieve the part table element for item data
                    var itemparttable = sap.ui.getCore().byId(jQuery("[id$='parentTableitem']").attr("id"));

                    old_supp = 0; // Counter to keep track of old supplier details index

                    // Loop through each supplier in the HBox
                    for (let supplier of itemsupplierHBox.getItems()) {

                        var supplier_details = []; // Array to hold the details of the current supplier

                        // Loop through the items of the current supplier
                        for (let i = 0; i < supplier.getItems().length; i++) {
                            var supplier_detail; // Variable to hold individual supplier detail

                            // Check if the item part table cell contains aggregated items
                            if (itemparttable.getItems()[i].getCells()[0].mAggregations.items) {
                                // If aggregated items are present, retrieve values dynamically
                                supplier_detail = {
                                    "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                    "value_key": `${itemparttable.mAggregations.items[i].mAggregations.cells[0].getItems()[1].getValue()}`, // Key from aggregated cell
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from supplier item
                                };
                            } else {
                                // If no aggregated items, retrieve values from cell properties
                                supplier_detail = {
                                    "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                    "value_key": `${itemparttable.getItems()[i].oModels.rowid.oData.rowid}`, // Key from row ID
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from supplier item
                                };
                            }
                            supplier_details.push(supplier_detail); // Add the supplier detail to the array
                        }

                            // Append details to the existing supplier details array
                            Array.prototype.push.apply(supplier_details_old[old_supp], supplier_details);
                            old_supp++; // Increment the index for old suppliers
                      
                    }
                }

                // Call the itemDataSave function
                itemDataSave();




                // Risk Analysis Save Function
                /**
                * Function to save Risk Analysis details.
                */
                function riskAnalysisSave() {
                    // Retrieve the risk table element
                    var risktable = sap.ui.getCore().byId(jQuery("[id$='parentTablerisk']").attr("id"));

                    // Retrieve the supplier HBox element for risk analysis
                    var risksupplierHbox = sap.ui.getCore().byId(jQuery("[id$='HboxSupplierrisk']").attr("id"));

                    old_supp = 0; // Counter to track the index for old suppliers

                    // Loop through each supplier in the HBox
                    for (let supplier of risksupplierHbox.getItems()) {
                       
                        var supplier_details = []; // Array to store details for the current supplier

                        // Loop through the items of the current supplier
                        for (let i = 0; i < supplier.getItems().length; i++) {
                            var supplier_detail; // Variable to hold individual supplier detail

                            // Check if the risk table cell contains aggregated items
                            if (risktable.getItems()[i].getCells()[0].mAggregations.items) {
                                // If aggregated items exist, retrieve values dynamically
                                supplier_detail = {
                                    "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                    "value_key": `${risktable.mAggregations.items[i].mAggregations.cells[0].getItems()[1].getValue()}`, // Key from aggregated cell
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from supplier item
                                };
                            } else {
                                // If no aggregated items, retrieve values from cell properties
                                supplier_detail = {
                                    "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                    "value_key": `${risktable.getItems()[i].oModels.rowid.oData.rowid}`, // Key from row ID
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from supplier item
                                };
                            }

                            supplier_details.push(supplier_detail); // Add the supplier detail to the array
                        }

                        // Append supplier details to the old supplier details array
                        Array.prototype.push.apply(supplier_details_old[old_supp], supplier_details);

                        old_supp++; // Increment the index for old suppliers
                    }
                }

                // Call the riskAnalysisSave function
                riskAnalysisSave();







                // DTB Save Function under item data for all parts
                function dtbSave() {
                    // Retrieve the DTB table element
                    var dtbtable = sap.ui.getCore().byId(jQuery("[id$='dtbtable']").attr("id"));

                    // Retrieve the HBox containing suppliers for DTB
                    var dtbhbox = sap.ui.getCore().byId(jQuery("[id$='dtbhbox']").attr("id"));

                    old_supp = 0; // Counter to track the index for old suppliers

                    // Loop through each supplier in the DTB HBox
                    for (let supplier of dtbhbox.getItems()) {
                       
                        var supplier_details = []; // Array to store details for the current supplier

                        // Loop through the items of the current supplier
                        for (let i = 0; i < supplier.getItems().length; i++) {
                            var supplier_detail; // Variable to hold individual supplier detail

                            // Check if the DTB table cell contains aggregated items
                            if (dtbtable.getItems()[i].getCells()[0].mAggregations.items) {
                                // If aggregated items exist, retrieve values dynamically
                                supplier_detail = {
                                    "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                    "value_key": `${dtbtable.mAggregations.items[i].mAggregations.cells[0].getItems()[1].getValue()}`, // Key from aggregated cell
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from supplier item
                                };
                            } else {
                                // If no aggregated items, retrieve values from cell properties
                                supplier_detail = {
                                    "id_supplier": `${supplier.oModels.supplier_id?.oData?.supplierid ?? ''}`, // Supplier ID
                                    "value_key": `${dtbtable.getItems()[i].oModels.rowid.oData.rowid}`, // Key from row ID
                                    "value": `${supplier.mAggregations.items[i].mAggregations.cells[0].mProperties?.value ?? ''}` // Value from supplier item
                                };
                            }

                            supplier_details.push(supplier_detail); // Add the supplier detail to the array
                        }
                            // Append details to the old supplier details array
                            Array.prototype.push.apply(supplier_details_old[old_supp], supplier_details);
                            old_supp++; // Increment the index for old suppliers
                    }
                }

                // Call the dtbSave function
                dtbSave();





                console.log(supplier_details_old);
              

                let oFunction1 = this.getModel().bindContext("/onSubmitFunc(...)");
                var statusval1 = JSON.stringify({ id: vobId, status: "submitsecondscreen", partdetails: partdetails, supplier_details_old: supplier_details_old })
                oFunction1.setParameter("status", statusval1)
                await oFunction1.execute()

                MessageToast.show("Data Saved");
            }
            catch (error) {
                debugger
                // Handle the error (you can add a MessageToast or error handling here)
                console.log("Error", error);
                MessageToast.show("An error occurred while saving.");
            } finally {
                // Hide the busy indicator after the actions are completed
                busy.close();
            }
        }
    };
});
