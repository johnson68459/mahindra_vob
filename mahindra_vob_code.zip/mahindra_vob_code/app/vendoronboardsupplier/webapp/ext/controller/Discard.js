sap.ui.define([
	'sap/m/HBox',
	"sap/m/Table",
	"sap/m/Column",
	"sap/m/ColumnListItem",
	"sap/m/Text",
	"sap/m/Input",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/CheckBox",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/m/library",
], function (HBox, Table, Column, ColumnListItem, Text, Input, Button, Dialog, CheckBox, MessageToast, JSONModel, mobileLibrary) {
	'use strict';
	function generateXmlValidId(suffix = "id") {
		// Ensure the suffix is valid by removing any invalid characters
		const validSuffix = suffix.replace(/[^A-Za-z0-9_.-]/g, "");

		// Generate a random part using alphanumeric characters
		const randomPart = Math.random().toString(36).substring(2, 10);

		// Ensure the ID starts with a letter or underscore, as required by XML rules
		const validStart = "x"; // Default starting letter to ensure validity

		// Combine the random part and suffix to form the ID
		return `${validStart}-${randomPart}-${validSuffix}`;
	}



	return {
		discard: async function (oEvent) {
			debugger
			var busy = new sap.m.BusyDialog({ text: "Discarding changes, please wait..." });
			try {
				busy.open();
				var validator = [];
				function validateSubmit() {
					if (validator.length === 0) {
						sap.ui.getCore().byId("vendoronboardsupplier::vobSupplierObjectPage--fe::FooterBar::_fc").setVisible(true);
					} else {
						sap.ui.getCore().byId("vendoronboardsupplier::vobSupplierObjectPage--fe::FooterBar::_fc").setVisible(false);
					}
				}


				function removeSubSection(sectionid) {
					var objectPagecashflow = sap.ui.getCore().byId(sectionid);

					// Get the second SubSection (index 1)
					var subSectioncashflow = objectPagecashflow.getSubSections()[1];

					// Destroy the blocks in the subsection
					subSectioncashflow.destroyBlocks();

					// Remove the subsection from the ObjectPage
					objectPagecashflow.removeSubSection(subSectioncashflow);

				}
				//global varible;
				var that = this;
				var statuscheckval;
				var result_searchhelp;
				var finalsupp;
				var comments;
				var result;
				async function allfunctioncall() {
					var url = window.location.hash;
					const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
					const matches = url.match(regex);
					var id = matches[1];

					//for status
					let oFunction = that._view.getModel().bindContext("/getStatus(...)");
					oFunction.setParameter("vobid", id);
					await oFunction.execute()
					result = oFunction.getBoundContext().getValue().value;
					if (result != "New" && result != "Rejected") {
						//DEBUGGER
						statuscheckval = false;
						//input read
					} else {
						//input false
						statuscheckval = true;
					}
					//for search_help data
					let oFunction_getsearchhelp = that._view.getModel().bindContext("/getsearchhelpdata(...)");
					var statusval1 = JSON.stringify({ id: id, status: "getsearchhelp" })
					oFunction_getsearchhelp.setParameter("status", statusval1)
					await oFunction_getsearchhelp.execute()

					result_searchhelp = oFunction_getsearchhelp.getBoundContext().getValue().value;
					result_searchhelp = JSON.parse(result_searchhelp);

					//for vendordetails
					let oFunction1 = that._view.getModel().bindContext("/vendordetails(...)");
					var statusval1 = JSON.stringify({ id: id, status: "vobsupplier" })
					oFunction1.setParameter("status", statusval1)
					await oFunction1.execute()

					var result1 = oFunction1.getBoundContext().getValue().value;
					finalsupp = JSON.parse(result1);


					let oFunc = that._view.getModel().bindContext("/commentfunction(...)");
					var statusval1 = JSON.stringify({ id: id, status: "screen2commentview" })
					oFunc.setParameter("status", statusval1)
					await oFunc.execute()
					debugger
					var result1 = oFunc.getBoundContext().getValue()?.value;
					comments = JSON.parse(result1);
				}
				await allfunctioncall()

				// Mapping of selected section IDs to functions
				var sectionMapping = {
					"vendoronboardsupplier::vobSupplierObjectPage--fe::CustomSection::VendoronBoard": cashflow,
					"vendoronboardsupplier::vobSupplierObjectPage--fe::CustomSection::Itemdata": itemdatasection,
					"vendoronboardsupplier::vobSupplierObjectPage--fe::CustomSection::Investmentbreakup": investmentbreakupsection,
					"vendoronboardsupplier::vobSupplierObjectPage--fe::CustomSection::Riskanalysis": riskanalysissection
				};

				// Get the selected section
				var selectedsection = this._view.getContent()[0].getSelectedSection();

				// Call the corresponding function if the section exists in the mapping
				if (sectionMapping[selectedsection]) {
					await sectionMapping[selectedsection](selectedsection);
					MessageToast.show("Discarded successfully");
				}

				function inputbasedonstatus(value, width, styleClass) {
					if (result != "New" && result != "Rejected") {
						//DEBUGGER
						return new Input({ value: value, width: width, tooltip: value, editable: false }).addStyleClass(styleClass)
						//input read

					} else {
						//input false
						return new Input({
							value: value, width: width, tooltip: value, editable: true, liveChange: function (oEvent) {
								//DEBUGGER

								var oInput = oEvent.getSource();
								var sValue = oEvent.getParameter("value");

								// Regular expression to match a decimal number with up to 10 digits before the decimal point and up to 2 digits after
								if (!/^\d{1,10}(\.\d{1,2})?$/.test(sValue) && sValue !== "") {
									// Set input as invalid if the value doesn't conform to DECIMAL(10,2)
									oInput.setValueState("Error");
									oInput.setValueStateText("Please enter a valid decimal number (up to 10 digits before and 2 digits after the decimal)");
									validator.push(oInput.sId);
									validateSubmit();
								} else {
									// Set input as valid
									oInput.setValueState("None");
									validator = validator.filter(item => item !== oInput.sId);
									validateSubmit();
								}


							}
						}).addStyleClass(styleClass)

					}

				}
				async function cashflow(sectionId) {
					var fields = [
						"Total Landed Investment - Settled (Rs. lacs)",
						"Total Buying value (Rs. Lac) 1st 12months",
						"Sourcing Partner commission to be paid ( Rs. Lac) 1st 12 months",
						"Sourcing Partner commission to be paid (Rs. Lac)  2nd + 3rd Year",
						"YOY Reduction for 3 yrs (After SOP + 1 year) - If Any",
						"FX Base Rate",
						"Inco Terms",
						"Payment Terms",
						"Transport Cost"
					]
					removeSubSection(sectionId);

					var mainVbox = that._view.getContent()[0].getSections()[0].getSubSections()[0].mAggregations._grid.mAggregations.content[0].getContent();
					mainVbox.getItems()[0].setWidth("40vw")

					mainVbox.getItems()[0].getItems()[0].destroyColumns();
					mainVbox.getItems()[0].getItems()[0].destroyItems();
					mainVbox.getItems()[1].destroyItems();

					var oHboxSupplier = mainVbox.getItems()[1];
					var otable = mainVbox.getItems()[0].getItems()[0];

					var firstColumn = new sap.m.Column({
						// width: "500px",
						header: new HBox({
							justifyContent: "SpaceBetween",
							items: [
								new Text({ text: "MGSP Part No", width: "8vw", tooltip: "MGSP Part No" }),
								new Text({ text: "MGSP Supplier Name", width: "8vw", tooltip: "MGSP Supplier Name" }),
								new Text({ text: "MGSP Vendor Inco Term", width: "8vw", tooltip: "MGSP Vendor Inco Term" }),
								new Text({ text: "Existing MGSP PO Price", width: "8vw", tooltip: "Existing MGSP PO Price" }),
								new Text({ text: "Target Price", width: "8vw", tooltip: "Target Price" })

							],
							// class: "coulmnwidth"
						}).addStyleClass("hboxHeaderClass"),
						// styleClass: "colunm1style"
					});
					otable.addColumn(firstColumn);
					var firstItem = new ColumnListItem({
						cells: [
							new Input({ value: `Remarks`, editable: false }).addStyleClass("InputToTextClass"),
						]
					})
					var modelrowfisrtcol = new JSONModel({
						rowid: `Remarks`
					});
					firstItem.setModel(modelrowfisrtcol, `rowid`);
					otable.addItem(firstItem);
					for (let i = 0; i < finalsupp.yoy_details.length; i++) {
						let partdetails = finalsupp.yoy_details[i];
						var oComboBox = new sap.m.ComboBox({
							width: "8vw",
							enabled: statuscheckval,
							value: partdetails.mgsp_vendor_inco_term, // Set the initial value if available
							tooltip: partdetails.mgsp_vendor_inco_term, // Tooltip for the field
							items: result_searchhelp.incotermsearchhelp_data.map(function (incoterm) {
								return new sap.ui.core.Item({
									text: `${incoterm.description}`, // Display incoterm with description
									key: incoterm.incoterm_searchhelp_id   // Set the key for the item
								});
							}),
							change: function (oEvent) {
								var oComboBox = oEvent.getSource();
								var selectedKey = oComboBox.getSelectedKey();  // Get the selected key
								var selectedValue = oComboBox.getValue();  // Get the current value
								// Check if the selected value is from the list of available options
								var isValidSelection = oComboBox.getItems().some(function (item) {
									return item.getText() === selectedValue;
								});
								if (isValidSelection) {
									oComboBox.setTooltip(selectedValue); // Update the tooltip with the selected value
									oEvent.oSource.setValueState(sap.ui.core.ValueState.None);
								} else {
									oEvent.oSource.setValueStateText("Invalid selection. Please select a valid option from the dropdown.");
									oEvent.oSource.setValueState("Error");
									oComboBox.setValue(null); // Reset the value if the input is invalid
									oComboBox.setTooltip(null); // Reset the tooltip
								}

							}
						});
						var oComboBox_suppliername = new sap.m.ComboBox({
							width: "8vw",
							showSecondaryValues: true,
							enabled: statuscheckval,
							value: partdetails.msgp_supplier_name, // Set the initial value if available
							tooltip: partdetails.msgp_supplier_name, // Tooltip for the field
							items: (result_searchhelp.vendorData && result_searchhelp.vendorData.length > 0) ?
								result_searchhelp.vendorData.map(function (vendor) {
									return new sap.ui.core.ListItem({
										key: `${vendor.vid}`,
										text: `${vendor.name}`,
										additionalText: `${vendor.lifnr}`
									});
								}) : [
									new sap.ui.core.ListItem({
										key: "", // Default key
										text: "No vendors available", // Display message when no data
										enabled: false // Make this item non-selectable
									})
								],
							change: function (oEvent) {
								//DEBUGGER
								var oComboBox = oEvent.getSource();
								var selectedKey = oComboBox.getSelectedKey();  // Get the selected key
								var selectedValue = oComboBox.getValue();  // Get the current value
								// Check if the selected value is from the list of available options
								var isValidSelection = oComboBox.getItems().some(function (item) {
									return item.getText() === selectedValue;
								});
								if (isValidSelection) {
									oComboBox.setTooltip(selectedValue); // Update the tooltip with the selected value
									oEvent.oSource.setValueState(sap.ui.core.ValueState.None);
								} else {
									oEvent.oSource.setValueStateText("Invalid selection. Please select a valid option from the dropdown.");
									oEvent.oSource.setValueState("Error");
									oComboBox.setValue(null); // Reset the value if the input is invalid
									oComboBox.setTooltip(null); // Reset the tooltip
								}
							}
						})

						var oComboBox_existing_mgsp_po_price = new sap.m.ComboBox({
							width: "8vw",
							enabled: statuscheckval,
							value: partdetails.existing_mgsp_po_price, // Set the initial value if available
							tooltip: partdetails.existing_mgsp_po_price, // Tooltip for the field
							// Initialize with no items, will be populated dynamically
							items: [],
							change: function (oEvent) {
								var oComboBox = oEvent.getSource();
								var selectedKey = oComboBox.getSelectedKey();  // Get the selected key
								var selectedValue = oComboBox.getValue();  // Get the current value
								// Check if the selected value is from the list of available options
								var isValidSelection = oComboBox.getItems().some(function (item) {
									return item.getText() === selectedValue;
								});
								if (isValidSelection) {
									oComboBox.setTooltip(selectedValue); // Update the tooltip with the selected value
									oEvent.oSource.setValueState(sap.ui.core.ValueState.None);
								} else {
									oEvent.oSource.setValueStateText("Invalid selection. Please select a valid option from the dropdown.");
									oEvent.oSource.setValueState("Error");
									oComboBox.setValue(null); // Reset the value if the input is invalid
									oComboBox.setTooltip(null); // Reset the tooltip
								}         // Update the partdetails object with the selected value
							}
						});

						var oColumnListItem = new ColumnListItem({
							cells: [
								new HBox({
									justifyContent: "SpaceBetween",
									items: [
										new Text({ text: partdetails.mgsp_part_nos, width: "8vw", tooltip: partdetails.mgsp_part_nos }),
										// inputbasedonstatus(partdetails.msgp_supplier_name, "8vw", ""),
										// oComboBox_suppliername,
										new Input({ value: partdetails.msgp_supplier_name, width: "8vw", editable: statuscheckval, tooltip: partdetails.msgp_supplier_name }),


										oComboBox,
										new Input({ value: partdetails.existing_mgsp_po_price, width: "8vw", editable: statuscheckval, tooltip: partdetails.existing_mgsp_po_price }),
										// oComboBox_existing_mgsp_po_price,
										// new Input({ value: partdetails.mgsp_vendor_inco_term, width: "8vw", tooltip: partdetails.mgsp_vendor_inco_term }),
										// inputbasedonstatus(partdetails.mgsp_vendor_inco_term, "8vw", ""),

										// inputbasedonstatus(partdetails.existing_mgsp_po_price, "8vw", ""),
										inputbasedonstatus(partdetails.target_price, "8vw", ""),

										// new Input({ value: partdetails.msgp_supplier_name, width: "14vw", tooltip: partdetails.msgp_supplier_name }).addStyleClass("paddingItems"),
										// new Input({ value: partdetails.existing_mgsp_po_price, width: "14vw", tooltip: partdetails.existing_mgsp_po_price }).addStyleClass("paddingItems"),
										// new Input({ value: partdetails.target_price, width: "14vw", tooltip: partdetails.target_price }).addStyleClass("paddingItems"),
									]
								}).addStyleClass("hboxRowClass"),
							]
						});

						// Set the model directly to the ColumnListItem
						var modelrow = new JSONModel({
							rowid: partdetails.id
						});
						oColumnListItem.setModel(modelrow, 'rowid');

						//If Yoy table has supplierid then set model

						if (partdetails.supplierid) {

							var supplierid = new JSONModel({
								supplierid: partdetails.supplierid
							});
							oColumnListItem.setModel(supplierid, `supplierid`);
						}

						// Add the ColumnListItem to the table
						otable.addItem(oColumnListItem);

					}

					for (let field of fields) {
						var oColumnListItem1 = new ColumnListItem({
							cells: [
								new Input({ value: `${field}`, editable: false }).addStyleClass("InputToTextClass"),
							]
						})
						var modelrow = new JSONModel({
							rowid: field
						});
						oColumnListItem1.setModel(modelrow, `rowid`);
						otable.addItem(oColumnListItem1);

					}
					var classIndex = 1;

					for (let supplier of finalsupp.suplier_detail_together) {
						var newSupplier = new Table({
							width: "20vw",
							columns: new Column({
								// styleClass:"colorClassSupplier1",
								header: [
									new HBox({
										width: "100%",
										items: [
											new sap.ui.core.Icon({
												// src: 'sap-icon://color-fill',
												src: 'sap-icon://circle-task',
												height: "10px",
												press: function (oEvent) {
													//DEBUGGER;

													// Function to add or toggle the event handler
													function toggleClickHandler(eventControl, mValue) {
														// Store the handler reference on the control for later use
														eventControl._clickHandler = function (event) {
															//DEBUGGER;
															const colorclass = sap.ui.getCore().byId(event.currentTarget.id).oParent.mAggregations.columns[0].mAggregations.header.mAggregations.items[0].aCustomStyleClasses[0];
															const control = sap.ui.getCore().byId(event.currentTarget.id);
															var parentTable = sap.ui.getCore().byId(jQuery("[id$='parentTable']").attr("id"))
															// Check if the control already has the class
															if (control.hasStyleClass(`input` + colorclass)) {
																// If the class is present, remove it
																control.removeStyleClass(`input` + colorclass);
																parentTable.getItems()[mValue].setModel(null, `supplierid`);
															} else {
																// Otherwise, add the class
																if (!parentTable.getItems()[mValue].oModels || !parentTable.getItems()[mValue].oModels.supplierid) {
																	control.addStyleClass(`input` + colorclass);
																	var supplierid = new JSONModel({
																		supplierid: control.getParent().oModels.supplier_id.oData.supplierid
																	});
																	parentTable.getItems()[mValue].setModel(supplierid, `supplierid`);
																}
																else {
																	MessageToast.show("Supplier already selected for this part")
																}

															}

															// Access the m value here
															console.log("Input field clicked", event, "m value:", mValue);
														};

														// Attach the click event handler
														eventControl.attachBrowserEvent("click", eventControl._clickHandler);
													}

													// Function to remove the event handler
													function removeClickHandler(eventControl) {
														if (eventControl._clickHandler) {
															// Detach the click event handler
															eventControl.detachBrowserEvent("click", eventControl._clickHandler);
															delete eventControl._clickHandler; // Clean up the handler
														}
													}

													var oIcon = oEvent.getSource();

													// Toggling logic
													if (oEvent.getSource().getSrc() === "sap-icon://circle-task") {
														oEvent.getSource().setSrc("sap-icon://bo-strategy-management");

														for (var m = 1; m < finalsupp.yoy_details.length + 1; m++) {
															let events = oEvent.getSource().getParent().getParent().getParent().mAggregations.items;
															toggleClickHandler(events[m], m); // Pass m value to the handler
														}
													} else {
														oEvent.getSource().setSrc("sap-icon://circle-task");
														for (var m = 1; m < finalsupp.yoy_details.length + 1; m++) {
															let events = oEvent.getSource().getParent().getParent().getParent().mAggregations.items;
															removeClickHandler(events[m]); // Detach handler from each item
														}
													}
												}

											}).addStyleClass(`colorClassSupplier` + `${classIndex}`),
											new Text({ text: `${supplier.supplier}`, tooltip: `${supplier.supplier}`, })
										]
									})
								]
							})
						}).addStyleClass("tableClass");

						var model = new JSONModel({
							supplierid: `${supplier.id_main}`
						})
						newSupplier.setModel(model, 'supplier_id');

						for (let i = 0; i < otable.getItems().length; i++) {

							let rowid = otable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
							let itemFound = supplier.rel.find(item => item.value_key == rowid);
							if (itemFound) {
								if (rowid == "Inco Terms") {
									var oComboBox = new sap.m.ComboBox({
										width: "100%",
										value: itemFound.value, // Set the initial value if available
										tooltip: itemFound.value,
										enabled: statuscheckval, // Tooltip for the field
										items: result_searchhelp.incotermsearchhelp_data.map(function (incoterm) {
											return new sap.ui.core.Item({
												text: `${incoterm.description}`, // Display incoterm with description
												key: incoterm.incoterm_searchhelp_id   // Set the key for the item
											});
										}),
										change: function (oEvent) {
											//DEBUGGER
											var selectedKey = oEvent.getSource().getSelectedKey();  // Get the selected key
											var enteredValue = oEvent.getSource().getValue();       // Get the entered value

											// Check if the entered value is valid (exists in ComboBox items)
											var isValid = result_searchhelp.incotermsearchhelp_data.some(function (incoterm) {
												return incoterm.description === enteredValue;
											});

											// If invalid, show a message and reset the ComboBox value
											if (!isValid) {
												// sap.m.MessageBox.error("Invalid data. Please select a valid option from the dropdown.");
												oEvent.oSource.setValueStateText("Invalid data. Please select a valid option from the dropdown.")
												oEvent.oSource.setValueState("Error");
												oEvent.getSource().setValue(null);
											}
											else {
												oComboBox.setTooltip(enteredValue); // Update the tooltip with the selected value
												oEvent.oSource.setValueState(sap.ui.core.ValueState.None);
											}

										}
									});
									var oColumnListItem6 = new ColumnListItem({
										cells: [
											// inputbasedonstatusforsuppliers(itemFound.value)
											// new Input({ value: `${itemFound.value}`, editable: statuscheckval }).attachBrowserEvent("click", function (event) {
											// 	//DEBUGGER
											// 	// Event handler logic for the click event
											// 	console.log("Input field clicked", event);
											// })
											oComboBox

											// .attachBrowserEvent()
										]
									})
									newSupplier.addItem(oColumnListItem6);
								}
								else if (rowid == "Payment Terms") {
									var oComboBox = new sap.m.ComboBox({
										width: "100%",
										value: itemFound.value,
										// Set the initial value if available
										// Tooltip for the field
										enabled: statuscheckval,
										items: result_searchhelp.PaymentTerm_searchhelp_data.map(function (paymentterm) {
											return new sap.ui.core.Item({
												text: `${paymentterm.description}`, // Display incoterm with description
												key: paymentterm.paymentterm_searchhelp   // Set the key for the item
											});
										}),
										change: function (oEvent) {
											//DEBUGGER
											var selectedKey = oEvent.getSource().getSelectedKey();  // Get the selected key
											// Update the partdetails object with the selected value
											var enteredValue = oEvent.getSource().getValue();       // Get the entered value

											// Check if the entered value is valid (exists in ComboBox items)
											var isValid = result_searchhelp.PaymentTerm_searchhelp_data.some(function (paymentterm) {
												return paymentterm.description === enteredValue;
											});

											// If invalid, show a message and reset the ComboBox value
											if (!isValid) {
												oEvent.oSource.setValueStateText("Invalid data. Please select a valid payment term from the dropdown.");
												oEvent.oSource.setValueState("Error");
												oEvent.getSource().setValue(null);  // Reset the value to null
											}
											else {
												oComboBox.setTooltip(enteredValue); // Update the tooltip with the selected value
												oEvent.oSource.setValueState(sap.ui.core.ValueState.None);
											}
										}
									});
									var oColumnListItem6 = new ColumnListItem({
										cells: [
											// inputbasedonstatusforsuppliers(itemFound.value)
											// new Input({ value: `${itemFound.value}`, editable: statuscheckval }).attachBrowserEvent("click", function (event) {
											// 	//DEBUGGER
											// 	// Event handler logic for the click event
											// 	console.log("Input field clicked", event);
											// })
											oComboBox

											// .attachBrowserEvent()
										]
									})
									newSupplier.addItem(oColumnListItem6);
								}

								else {
									var oColumnListItem6 = new ColumnListItem({
										cells: [
											// inputbasedonstatusforsuppliers(itemFound.value)
											new Input({
												value: `${itemFound.value}`, editable: statuscheckval,
												liveChange: function (oEvent) {
													//DEBUGGER

													var oInput = oEvent.getSource();


													var oRow = oInput.getParent();  // Assuming oInput -> Cell -> Row (ColumnListItem)


													var oTable = oRow.getParent();  // Assuming oRow -> Table


													var iRowIndex = oTable.indexOfItem(oRow);

													var indexMax = 4 + finalsupp.yoy_details.length;

													var sValue = oEvent.getParameter("value");
													if (statuscheckval) {
														// debugger
														switch (true) {
															// For numbers between 1 and 10
															case (iRowIndex > 0 && iRowIndex <= finalsupp.yoy_details.length):
																if (!/^[^a-zA-Z0-9]{0,4}\d{1,10}(\.\d{1,2})?[^a-zA-Z0-9]{0,4}$/.test(sValue) && sValue != "") {  // Regular expression to check if the value is numeric
																	// Set input as invalid
																	this.setValueState("Error");
																	this.setValueStateText("Please enter a valid decimal number (up to 10 digits before and 2 digits after the decimal)");
																	validator.push(oInput.sId);
																	validateSubmit();

																} else {
																	// Set input as valid
																	this.setValueState("None");
																	validator = validator.filter(item => item !== oInput.sId);
																	validateSubmit();
																}
																break;
															case ((iRowIndex >= finalsupp.yoy_details.length + 1 && iRowIndex <= indexMax)):// || iRowIndex == indexMax + 4):
																if (!/^\d{1,10}(\.\d{1,2})?$/.test(sValue) && sValue != "") {
																	// Set input as invalid
																	this.setValueState("Error");
																	this.setValueStateText("Please enter a valid decimal number (up to 10 digits before and 2 digits after the decimal)");
																	validator.push(oInput.sId);
																	validateSubmit();
																}
																else {
																	// Set input as valid
																	this.setValueState("None");
																	validator = validator.filter(item => item !== oInput.sId);
																	validateSubmit();
																}
																break;
															// case (iRowIndex == indexMax + 1 || iRowIndex == 0):
															// 	if (!/^[a-zA-Z0-9]+$/.test(sValue) && sValue != "") {
															// 		// Set input as invalid
															// 		this.setValueState("Error");
															// 		this.setValueStateText("Please enter a alphanumeric");
															// 		validator.push(oInput.sId);
															// 		validateSubmit();
															// 	}
															// 	else {
															// 		// Set input as valid
															// 		this.setValueState("None");
															// 		validator = validator.filter(item => item !== oInput.sId);
															// 		validateSubmit();
															// 	}
															// 	break;


														}
														validateSubmit();
													}

												}
											})
											// .attachBrowserEvent()
										]
									})

									newSupplier.addItem(oColumnListItem6);
								}
							}
							else {
								if (rowid == "Inco Terms") {
									var oComboBox = new sap.m.ComboBox({
										width: "100%",
										value: null, // Set the initial value if available
										// tooltip: itemFound.value,
										enabled: statuscheckval, // Tooltip for the field
										items: result_searchhelp.incotermsearchhelp_data.map(function (incoterm) {
											return new sap.ui.core.Item({
												text: `${incoterm.description}`, // Display incoterm with description
												key: incoterm.incoterm_searchhelp_id   // Set the key for the item
											});
										}),
										change: function (oEvent) {
											//DEBUGGER
											var selectedKey = oEvent.getSource().getSelectedKey();  // Get the selected key
											var enteredValue = oEvent.getSource().getValue();       // Get the entered value

											// Check if the entered value is valid (exists in ComboBox items)
											var isValid = result_searchhelp.incotermsearchhelp_data.some(function (incoterm) {
												return incoterm.description === enteredValue;
											});

											// If invalid, show a message and reset the ComboBox value
											if (!isValid) {
												// sap.m.MessageBox.error("Invalid data. Please select a valid option from the dropdown.");
												oEvent.oSource.setValueStateText("Invalid data. Please select a valid option from the dropdown.")
												oEvent.oSource.setValueState("Error");
												oEvent.getSource().setValue(null);
											}
											else {
												oComboBox.setTooltip(enteredValue); // Update the tooltip with the selected value
												oEvent.oSource.setValueState(sap.ui.core.ValueState.None);
											}
										}
									});
									var oColumnListItem6 = new ColumnListItem({
										cells: [
											// inputbasedonstatusforsuppliers(itemFound.value)
											// new Input({ value: `${itemFound.value}`, editable: statuscheckval }).attachBrowserEvent("click", function (event) {
											// 	//DEBUGGER
											// 	// Event handler logic for the click event
											// 	console.log("Input field clicked", event);
											// })
											oComboBox

											// .attachBrowserEvent()
										]
									})
									newSupplier.addItem(oColumnListItem6);
								}
								else if (rowid == "Payment Terms") {
									var oComboBox = new sap.m.ComboBox({
										width: "100%",
										value: null,
										enabled: statuscheckval,
										// Set the initial value if available
										// Tooltip for the field
										items: result_searchhelp.PaymentTerm_searchhelp_data.map(function (paymentterm) {
											return new sap.ui.core.Item({
												text: `${paymentterm.description}`, // Display incoterm with description
												key: paymentterm.paymentterm_searchhelp   // Set the key for the item
											});
										}),
										change: function (oEvent) {
											//DEBUGGER
											var selectedKey = oEvent.getSource().getSelectedKey();  // Get the selected key
											// Update the partdetails object with the selected value
											var enteredValue = oEvent.getSource().getValue();       // Get the entered value

											// Check if the entered value is valid (exists in ComboBox items)
											var isValid = result_searchhelp.PaymentTerm_searchhelp_data.some(function (paymentterm) {
												return paymentterm.description === enteredValue;
											});

											// If invalid, show a message and reset the ComboBox value
											if (!isValid) {
												oEvent.oSource.setValueStateText("Invalid data. Please select a valid payment term from the dropdown.");
												oEvent.oSource.setValueState("Error");
												oEvent.getSource().setValue(null);  // Reset the value to null
											}
											else {
												oComboBox.setTooltip(enteredValue); // Update the tooltip with the selected value
												oEvent.oSource.setValueState(sap.ui.core.ValueState.None);
											}
										}
									});
									var oColumnListItem6 = new ColumnListItem({
										cells: [
											// inputbasedonstatusforsuppliers(itemFound.value)
											// new Input({ value: `${itemFound.value}`, editable: statuscheckval }).attachBrowserEvent("click", function (event) {
											// 	//DEBUGGER
											// 	// Event handler logic for the click event
											// 	console.log("Input field clicked", event);
											// })
											oComboBox

											// .attachBrowserEvent()
										]
									})
									newSupplier.addItem(oColumnListItem6);
								}
								else {
									var oColumnListItem6 = new ColumnListItem({
										cells: [
											new Input({
												value: null,
												editable: statuscheckval,
												liveChange: function (oEvent) {
													//DEBUGGER

													var oInput = oEvent.getSource();


													var oRow = oInput.getParent();  // Assuming oInput -> Cell -> Row (ColumnListItem)


													var oTable = oRow.getParent();  // Assuming oRow -> Table


													var iRowIndex = oTable.indexOfItem(oRow);

													var indexMax = 4 + finalsupp.yoy_details.length;

													var sValue = oEvent.getParameter("value");
													if (statuscheckval) {
														switch (true) {
															// For numbers between 1 and 10
															case (iRowIndex > 0 && iRowIndex <= finalsupp.yoy_details.length):
																if (!/^[^a-zA-Z0-9]{0,4}\d{1,10}(\.\d{1,2})?[^a-zA-Z0-9]{0,4}$/.test(sValue) && sValue != "") {  // Regular expression to check if the value is numeric
																	// Set input as invalid
																	this.setValueState("Error");
																	this.setValueStateText("Please enter a valid decimal number (up to 10 digits before and 2 digits after the decimal)");
																	validator.push(oInput.sId);
																	validateSubmit();

																} else {
																	// Set input as valid
																	this.setValueState("None");
																	validator = validator.filter(item => item !== oInput.sId);
																	validateSubmit();
																}
																break;
															case ((iRowIndex >= finalsupp.yoy_details.length + 1 && iRowIndex <= indexMax)):// || iRowIndex == indexMax + 4):
																if (!/^\d{1,10}(\.\d{1,2})?$/.test(sValue) && sValue != "") {
																	// Set input as invalid
																	this.setValueState("Error");
																	this.setValueStateText("Please enter a valid decimal number (up to 10 digits before and 2 digits after the decimal)");
																	validator.push(oInput.sId);
																	validateSubmit();
																}
																else {
																	// Set input as valid
																	this.setValueState("None");
																	validator = validator.filter(item => item !== oInput.sId);
																	validateSubmit();
																}
																break;
															// case (iRowIndex == indexMax + 1 || iRowIndex == 0):
															// 	if (!/^[a-zA-Z0-9]+$/.test(sValue) && sValue != "") {
															// 		// Set input as invalid
															// 		this.setValueState("Error");
															// 		this.setValueStateText("Please enter a alphanumeric");
															// 		validator.push(oInput.sId);
															// 		validateSubmit();
															// 	}
															// 	else {
															// 		// Set input as valid
															// 		this.setValueState("None");
															// 		validator = validator.filter(item => item !== oInput.sId);
															// 		validateSubmit();
															// 	}
															// 	break;


														}
														validateSubmit();
													}

												}
											})
										]
									});
								}
								newSupplier.addItem(oColumnListItem6);
							}
						}




						for (var m = 0; m < finalsupp.yoy_details.length; m++) {
							if (finalsupp.yoy_details[m].supplierid == supplier.id_main) {
								//DEBUGGER
								newSupplier.getItems()[m + 1].addStyleClass(`input` + `colorClassSupplier` + `${classIndex}`)
							}
						}
						classIndex = classIndex + 1;
						// Add the newly created column to the table
						oHboxSupplier.addItem(newSupplier);
					}


					let cashflowcmt = comments.filter(item => item.comment && item.comment.startsWith("Cash Flow: "));;



					if (cashflowcmt.length > 0) {
						// Sort comments by the 'createdAt' field to get the latest one
						let latestcashComment = cashflowcmt
							.filter(item => item.createdAt) // Only consider items with a valid 'createdAt'
							.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0]; // Sort by latest

						console.log("Latest Investment_Screen3 comment:", latestcashComment);

						let chasflowcmtid = generateXmlValidId("cashflowcmt");

						// Create a sap.m.HBox containing a TextArea for the latest comment
						var contentContainercashflowcomment = new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								// Add a Table
								new sap.m.TextArea({
									id: chasflowcmtid,
									editable: statuscheckval,
									value: (latestcashComment?.comment && latestcashComment.comment.startsWith("Cash Flow: "))
										? latestcashComment.comment.replace("Cash Flow: ", "") : '',
									width: "70vw",
									rows: 3,
									// cols: 500
								}),
								new sap.m.Button({
									text: "Comment History",
									press: function (oEvent) {
										debugger
										onCommenthistoryPress.call(this, oEvent);
									}
								})
							]
						})

						// Add contentContainerinvestmentcomment to your layout or page here if necessary

					} else {
						console.log("No comments starting with 'Investment_Screen3' found.");

						let cashflowcmtid = generateXmlValidId("cashflowcmt");

						// Handle the case where no comments are found (optional):
						var contentContainercashflowcomment = new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								// Add a Table
								new sap.m.TextArea({
									id: cashflowcmtid,
									editable: statuscheckval,
									width: "70vw",
									rows: 3,
									cols: 800
								}),
								new sap.m.Button({
									text: "Comment History",
									press: function (oEvent) {
										debugger
										onCommenthistoryPress.call(this, oEvent);
									}
								})
							]
						})

						// Add the empty container to your layout if necessary
					}


					sap.ui.getCore().byId("vendoronboardsupplier::vobSupplierObjectPage--fe::CustomSection::VendoronBoard").addSubSection(
						new sap.uxap.ObjectPageSubSection({
							title: "Comment",
							blocks: [
								contentContainercashflowcomment // Use the variable here
							]
						})
					);
				}
				async function itemdatasection(sectionId) {
					removeSubSection(sectionId);

					var docmainHboc = sap.ui.getCore().byId(jQuery("[id$='mainhoxitem']").attr("id"))
					docmainHboc.getItems()[0].setWidth("40vw")
					docmainHboc.getItems()[0].getItems()[0].destroyColumns();
					docmainHboc.getItems()[0].getItems()[0].destroyItems();
					docmainHboc.getItems()[1].destroyItems();
					var itemsupplierHBox = sap.ui.getCore().byId(jQuery("[id$='HboxSupplieritem']").attr("id"))
					var itemparttable = sap.ui.getCore().byId(jQuery("[id$='parentTableitem']").attr("id"))
					var datafirstColumn = new sap.m.Column({
						header: [
							new Text({ text: "MGSP Part No", tooltip: "MGSP Part No", textAlign: "End" }),
						]
					});
					var datasecondcolumn = new sap.m.Column({
						header: [
							new Text({ text: "Finished Weight of Part / System (kg)", tooltip: "Finished Weight of Part / System (kg)", textAlign: "End" })
						]
					});
					itemparttable.addColumn(datafirstColumn);
					itemparttable.addColumn(datasecondcolumn);

					for (let i = 0; i < finalsupp.yoy_details.length; i++) {
						let partdetails = finalsupp.yoy_details[i];
						var oColumnListItem = new ColumnListItem({
							cells: [
								new Input({ value: partdetails.mgsp_part_nos, tooltip: partdetails.mgsp_part_nos, editable: false }),
								new Input({
									value: partdetails.finished_weight_of_part ? `${partdetails.finished_weight_of_part}` : "",
									tooltip: partdetails.finished_weight_of_part ? `${partdetails.finished_weight_of_part}` : "",
									editable: statuscheckval,
									liveChange: function (oEvent) {
										//DEBUGGER

										var oInput = oEvent.getSource();

										// Step 2: Get the parent row (ColumnListItem)
										var oRow = oInput.getParent();  // Assuming oInput -> Cell -> Row (ColumnListItem)

										// Step 3: Get the parent table (assuming the row is inside a table)
										var oTable = oRow.getParent();  // Assuming oRow -> Table

										// Step 4: Get the index of the row in the table
										var iRowIndex = oTable.indexOfItem(oRow);
										// var leftparenttable =  sap.ui.getCore().byId(jQuery("[id$='parentTable']").attr("id"))



										var sValue = oEvent.getParameter("value");
										if (statuscheckval) {
											switch (true) {
												// For numbers between 1 and 10
												case (iRowIndex >= 0 && iRowIndex <= 6):
													if (!/^\d{1,10}(\.\d{1,2})?$/.test(sValue) && sValue != "") {  // Regular expression to check if the value is numeric
														// Set input as invalid
														this.setValueState("Error");
														this.setValueStateText("Please enter a valid decimal number (up to 10 digits before and 2 digits after the decimal)");
														validator.push(oInput.sId);
														validateSubmit();
													}
													else {
														// Set input as valid
														this.setValueState("None");
														validator = validator.filter(item => item !== oInput.sId);
														validateSubmit();
													}
													break;
											}
											validateSubmit();
										}
									}
								}),
								// inputbasedonstatusitemleft(partdetails.finished_weight_of_part),
								// new Input({ value: " " }),
							]
						});

						// Set the model directly to the ColumnListItem
						var modelrow = new JSONModel({
							rowid: partdetails.id + `DTB Packaging Cost Rs. (Included in above Offer prices)`
						});
						oColumnListItem.setModel(modelrow, 'rowid');

						// Add the ColumnListItem to the table
						itemparttable.addItem(oColumnListItem);
					}


					// Generate unique IDs for the table and HBox
					let dtbTableId = generateXmlValidId("dtbtable");
					let dtbHBoxId = generateXmlValidId("dtbhbox");

					// ITEM DATA SUBSECTION
					var contentContainerDTB = new sap.m.HBox({
						items: [
							// Add a Table
							new sap.m.Table({
								id: dtbTableId
							}),
							// Add an HBox
							new sap.m.HBox({
								id: dtbHBoxId
							})
						]
					});
					//DEBUGGER
					var dtbtable = contentContainerDTB.getItems()[0]
					var dtbleftsidesection = contentContainerDTB.getItems()[1]
					dtbtable.addStyleClass("tableClass");
					dtbtable.setWidth("40vw")
					dtbleftsidesection.addStyleClass("rightHboxClass")
					var dtbfirstColumn = new sap.m.Column({
						width: "500px",
						header:
							new Text({ text: "MGSP Part No", tooltip: "MGSP Part No" }),

					});
					dtbtable.addColumn(dtbfirstColumn);
					for (let i = 0; i < finalsupp.yoy_details.length; i++) {
						let partdetails = finalsupp.yoy_details[i];

						var oColumnListItem = new ColumnListItem({
							cells: [
								new Input({ value: `${partdetails.mgsp_part_nos}`, tooltip: `${partdetails.mgsp_part_nos}`, editable: false }).addStyleClass("InputToTextClass"),
							]

						});
						// Set the model directly to the ColumnListItem
						var modelrow = new JSONModel({
							rowid: partdetails.id + "DTB Packaging Cost Rs. (Included in above Offer prices)"
						});
						oColumnListItem.setModel(modelrow, 'rowid');

						//If Yoy table has supplierid then set model

						if (partdetails.supplierid) {

							var supplierid = new JSONModel({
								supplierid: partdetails.supplierid
							});
							oColumnListItem.setModel(supplierid, `supplierid`);
						}

						// Add the ColumnListItem to the table
						dtbtable.addItem(oColumnListItem);

					}
					for (let supplier of finalsupp.suplier_detail_together) {
						var newSupplier = new Table({
							width: "20vw",
							columns: new Column({
								header: [
									// new HBox({
									// items: [
									new Text({
										text: `${supplier.supplier}`
									})
									// ]
									// })
								]
							})
						}).addStyleClass("tableClass");
						var model = new JSONModel({
							supplierid: `${supplier.id_main}`
						})
						newSupplier.setModel(model, 'supplier_id');

						for (let i = 0; i < dtbtable.getItems().length; i++) {

							let rowid = dtbtable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
							let itemFound = supplier.rel.find(item => item.value_key == rowid);
							if (itemFound) {
								var oColumnListItem6 = new ColumnListItem({
									cells: [
										new Input({
											value: `${itemFound.value}`, editable: statuscheckval,
											liveChange: function (oEvent) {
												//DEBUGGER

												var oInput = oEvent.getSource();

												// Step 2: Get the parent row (ColumnListItem)
												var oRow = oInput.getParent();  // Assuming oInput -> Cell -> Row (ColumnListItem)

												// Step 3: Get the parent table (assuming the row is inside a table)
												var oTable = oRow.getParent();  // Assuming oRow -> Table

												// Step 4: Get the index of the row in the table
												var iRowIndex = oTable.indexOfItem(oRow);
												// var leftparenttable =  sap.ui.getCore().byId(jQuery("[id$='parentTable']").attr("id"))



												var sValue = oEvent.getParameter("value");
												if (statuscheckval) {
													if (!/^\d{1,10}(\.\d{1,2})?$/.test(sValue) && sValue != "") {  // Regular expression to check if the value is numeric
														// Set input as invalid
														this.setValueState("Error");
														this.setValueStateText("Please enter a valid decimal number (up to 10 digits before and 2 digits after the decimal)");
														validator.push(oInput.sId);
														validateSubmit();
													}
													else {
														// Set input as valid
														this.setValueState("None");
														validator = validator.filter(item => item !== oInput.sId);
														validateSubmit();
													}
													validateSubmit();
												}
											}
										})
									]
								})
								newSupplier.addItem(oColumnListItem6);
							}
							else {
								var oColumnListItem6 = new ColumnListItem({
									cells: [
										new Input({
											value: null, editable: statuscheckval,
											liveChange: function (oEvent) {
												//DEBUGGER

												var oInput = oEvent.getSource();

												// Step 2: Get the parent row (ColumnListItem)
												var oRow = oInput.getParent();  // Assuming oInput -> Cell -> Row (ColumnListItem)

												// Step 3: Get the parent table (assuming the row is inside a table)
												var oTable = oRow.getParent();  // Assuming oRow -> Table

												// Step 4: Get the index of the row in the table
												var iRowIndex = oTable.indexOfItem(oRow);
												// var leftparenttable =  sap.ui.getCore().byId(jQuery("[id$='parentTable']").attr("id"))



												var sValue = oEvent.getParameter("value");
												if (statuscheckval) {
													if (!/^\d{1,10}(\.\d{1,2})?$/.test(sValue) && sValue != "") {  // Regular expression to check if the value is numeric
														// Set input as invalid
														this.setValueState("Error");
														this.setValueStateText("Please enter a valid decimal number (up to 10 digits before and 2 digits after the decimal)");
														validator.push(oInput.sId);
														validateSubmit();
													}
													else {
														// Set input as valid
														this.setValueState("None");
														validator = validator.filter(item => item !== oInput.sId);
														validateSubmit();
													}
													validateSubmit();
												}
											}
										})
									]
								})
								newSupplier.addItem(oColumnListItem6);
							}
						}
						// Add the newly created column to the table
						dtbleftsidesection.addItem(newSupplier);
					}

					sap.ui.getCore().byId("vendoronboardsupplier::vobSupplierObjectPage--fe::CustomSection::Itemdata").addSubSection(
						new sap.uxap.ObjectPageSubSection({
							title: "DTB Packing Cost",
							blocks: [
								contentContainerDTB // Use the variable here
							]
						})
					);
				}
				async function investmentbreakupsection(sectionId) {
					removeSubSection(sectionId);

					var invmainVbox = sap.ui.getCore().byId(jQuery("[id$='mainhboxinv']").attr("id"))
					invmainVbox.getItems()[0].setWidth("40vw")
					invmainVbox.getItems()[0].getItems()[0].destroyColumns();
					invmainVbox.getItems()[0].getItems()[0].destroyItems();
					invmainVbox.getItems()[1].destroyItems();
					var invoHboxSupplier = sap.ui.getCore().byId(jQuery("[id$='HboxSupplierinvestment']").attr("id"))
					var invotable = sap.ui.getCore().byId(jQuery("[id$='parentTableinvestment']").attr("id"))
					//DEBUGGER;
					var invfirstColumn = new sap.m.Column({
						width: "500px",
						header:
							new Text({ text: "All figures in Rs.Lacs", tooltip: "All figures in Rs.Lacs", textAlign: "End" }),

					});
					invotable.addColumn(invfirstColumn);
					function createColumnListItem(leftValue, rightValue, myborder) {
						var oColumnListItem = new ColumnListItem({
							cells: [
								new HBox({
									justifyContent: "SpaceBetween",
									items: [
										new Input({ value: leftValue, tooltip: leftValue, editable: false }).addStyleClass("InputToTextClass customBorder"),
										new Input({ value: rightValue, tooltip: rightValue, editable: false }).addStyleClass("InputToTextClass")
									]
								})
							]
						});
						var modelrow = new JSONModel({
							rowid: rightValue
						});
						if (myborder) {
							oColumnListItem.addStyleClass("BottomBorder");
						} else {
							oColumnListItem.addStyleClass("capexUpperSectionClass");
						}

						oColumnListItem.setModel(modelrow, `rowid`);
						return oColumnListItem;

					}

					const items = [
						["Capex", "Tooling / Dies / Moulds / Fixtures"],
						[" ", "Inspection Gauges"],
						["Revenue", "Testing / Validation"],
						[" ", "Engg Fees"],
						[" ", "Proto Tooling"],
						[" ", "Logistics Trollies"],
						[" ", "Total Landed Investment Settled"]
					];
					var count = 0;
					items.forEach(([left, right]) => {
						count++;
						invotable.addItem(createColumnListItem(left, right, (count == 2 || count == 6 || count == 7)));

					});


					for (let supplier of finalsupp.suplier_detail_together) {
						var newSupplier = new Table({
							width: "20vw",
							columns: new Column({
								header: [
									new Text({
										text: `${supplier.supplier}`
									})


								]
							})
						}).addStyleClass("tableClass");
						var model = new JSONModel({
							supplierid: `${supplier.id_main}`
						})
						newSupplier.setModel(model, 'supplier_id');

						for (let i = 0; i < invotable.getItems().length; i++) {

							let rowid = invotable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
							let itemFound = supplier.rel.find(item => item.value_key == rowid);
							let valueToInsert = itemFound ? itemFound.value : null;
							var oColumnListItem6 = new ColumnListItem({
								cells: [
									new Input({
										value: valueToInsert, editable: statuscheckval,
										liveChange: function (oEvent) {
											//DEBUGGER

											var oInput = oEvent.getSource();

											// Step 2: Get the parent row (ColumnListItem)
											var oRow = oInput.getParent();  // Assuming oInput -> Cell -> Row (ColumnListItem)

											// Step 3: Get the parent table (assuming the row is inside a table)
											var oTable = oRow.getParent();  // Assuming oRow -> Table

											// Step 4: Get the index of the row in the table
											var iRowIndex = oTable.indexOfItem(oRow);
											// var leftparenttable =  sap.ui.getCore().byId(jQuery("[id$='parentTable']").attr("id"))



											var sValue = oEvent.getParameter("value");
											if (statuscheckval) {
												switch (true) {
													// For numbers between 1 and 10
													case (iRowIndex >= 0 && iRowIndex <= 6):
														if (!/^\d{1,10}(\.\d{1,2})?$/.test(sValue) && sValue != "") {  // Regular expression to check if the value is numeric
															// Set input as invalid
															this.setValueState("Error");
															this.setValueStateText("Please enter a valid decimal number (up to 10 digits before and 2 digits after the decimal)");
															validator.push(oInput.sId);
															validateSubmit();
														}
														else {
															// Set input as valid
															this.setValueState("None");
															validator = validator.filter(item => item !== oInput.sId);
															validateSubmit();
														}
														break;
												}
												validateSubmit();
											}
										}
									})
								]
							})
							newSupplier.addItem(oColumnListItem6);

						}
						// Add the newly created column to the table
						invoHboxSupplier.addItem(newSupplier);
					}
					debugger

					// Find all comments that start with "Investment_Screen3"
					let investmentComments = comments.filter(item => item.comment && item.comment.startsWith("Investment Breakup"));

					if (investmentComments.length > 0) {
						// Sort comments by the 'createdAt' field to get the latest one
						let latestInvestmentComment = investmentComments
							.filter(item => item.createdAt) // Only consider items with a valid 'createdAt'
							.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0]; // Sort by latest

						console.log("Latest Investment_Screen3 comment:", latestInvestmentComment);

						// Generate a unique ID for the TextArea
						let investmentCommentId = generateXmlValidId("investmentcomment");
						// Create a sap.m.HBox containing a TextArea for the latest comment
						var contentContainerinvestmentcomment = new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.TextArea({
									id: investmentCommentId,
									width: "70vw",
									editable: statuscheckval,
									value: (latestInvestmentComment?.comment && latestInvestmentComment.comment.startsWith("Investment Breakup: "))
										? latestInvestmentComment.comment.replace("Investment Breakup: ", "") // Remove prefix if exists
										: '', // If no valid comment, use an empty string
									rows: 3,
									cols: 800
								}),
								new sap.m.Button({
									text: "Comment History",
									press: function (oEvent) {
										debugger
										onCommenthistoryPress.call(this, oEvent);
									}
								})
							]
						});

						// Add contentContainerinvestmentcomment to your layout or page here if necessary

					} else {
						console.log("No comments starting with 'Investment_Screen3' found.");

						// Generate a unique ID for the TextArea
						let investmentCommentId = generateXmlValidId("investmentcomment");

						// Handle the case where no comments are found (optional):
						var contentContainerinvestmentcomment = new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.TextArea({
									id: investmentCommentId,
									width: "70vw",
									editable: statuscheckval,
									value: '', // No comments available, so show an empty text area
									rows: 3,
									cols: 800
								}),
								new sap.m.Button({
									text: "Comment History",
									press: function (oEvent) {
										debugger
										onCommenthistoryPress.call(this, oEvent);
									}
								})
							]
						});

						// Add the empty container to your layout if necessary
					}



					sap.ui.getCore().byId("vendoronboardsupplier::vobSupplierObjectPage--fe::CustomSection::Investmentbreakup").addSubSection(
						new sap.uxap.ObjectPageSubSection({
							title: "Comment",
							blocks: [
								contentContainerinvestmentcomment // Use the variable here
							]
						})
					);
				}
				async function riskanalysissection(sectionId) {
					removeSubSection(sectionId);
					var riskmainHbox = sap.ui.getCore().byId(jQuery("[id$='mainhboxrisk']").attr("id"))
					riskmainHbox.getItems()[0].setWidth("40vw")
					riskmainHbox.getItems()[0].getItems()[0].destroyColumns();
					riskmainHbox.getItems()[0].getItems()[0].destroyItems();
					riskmainHbox.getItems()[1].destroyItems();
					var risktable = sap.ui.getCore().byId(jQuery("[id$='parentTablerisk']").attr("id"))
					var riskleftsidesection = sap.ui.getCore().byId(jQuery("[id$='HboxSupplierrisk']").attr("id"))
					risktable.addStyleClass("tableClass");
					risktable.setWidth("40vw")
					riskleftsidesection.addStyleClass("rightHboxClass")
					var btbfirstColumn = new sap.m.Column({
						width: "500px",
						header:
							new Text({ text: "Risk Analysis" }),

					});
					risktable.addColumn(btbfirstColumn);
					const agreementsAndRatings = [
						"Development Supply Agreement (DSA) - Whether Signed? (If No: LoBA will share after DSA agreement)",
						"Tooling Agreement - Is it signed? (If applicable)",
						"Supplier Code of Conduct Declaration - Submitted? (If No: Must be signed before start of development)",
						"SRMM Score - Completed? (If Not Done: To be done before start of development)",
						"Financial Rating - Completed? (If Not Done: To be done before start of development)",
						"IPR Undertaking - Submitted? (If Not Done: To be done before start of development)"
					];

					for (let field of agreementsAndRatings) {
						var oColumnListItemrisk = new ColumnListItem({
							cells: [
								new Input({ value: `${field}`, tooltip: `${field}`, editable: false }).addStyleClass("InputToTextClass"),
							]
						})
						var modelrow = new JSONModel({
							rowid: field
						});
						oColumnListItemrisk.setModel(modelrow, `rowid`);
						risktable.addItem(oColumnListItemrisk);
					}
					for (let supplier of finalsupp.suplier_detail_together) {
						debugger
						var supplier_id = supplier.supplier_id;
						// var supplier_id = "35010365"

						// Check if supplier_id exists in vendorData
						var supplierFound = result_searchhelp.vendorData.find(vendor => vendor.lifnr == supplier_id);
						console.log("supplierfffff" + `${supplierFound}`)

						var supplierText = supplierFound ? `*${supplier.supplier}` : `${supplier.supplier}`;
						// var supplierText =


						var newSupplier = new Table({
							width: "20vw",
							columns: new Column({
								header: [
									new Text({
										text: supplierText
									})
								]
							})
						}).addStyleClass("tableClass");
						var model = new JSONModel({
							supplierid: `${supplier.id_main}`
						})
						newSupplier.setModel(model, 'supplier_id');

						for (let i = 0; i < risktable.getItems().length; i++) {

							let rowid = risktable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
							let itemFound = supplier.rel.find(item => item.value_key == rowid);
							let valueToInsert = itemFound ? itemFound.value : null;

							var oColumnListItem6 = new ColumnListItem({
								cells: [
									new Input({
										value: valueToInsert, editable: statuscheckval,
										liveChange: function (oEvent) {
											//////DEBUGGER
											validateSubmit();
										}
									})
								]
							})
							newSupplier.addItem(oColumnListItem6);

						}
						// Add the newly created column to the table
						riskleftsidesection.addItem(newSupplier);
					}
					debugger
					let riskcmt = comments.filter(item => item.comment && item.comment.startsWith("Risk Analysis: "));;
					console.log("Risk Analysis_Screen3", riskcmt);


					if (riskcmt.length > 0) {
						// Sort comments by the 'createdAt' field to get the latest one
						let latestRiskComment = riskcmt
							.filter(item => item.createdAt) // Only consider items with a valid 'createdAt'
							.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0]; // Sort by latest

						console.log("Latest Investment_Screen3 comment:", latestRiskComment);

						// Generate a unique ID for the risk comment TextArea
						let riskCommentId = generateXmlValidId("riskcomment");

						// Create a sap.m.HBox containing a TextArea for the latest comment
						var contentContainerRiskcomment = new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								// Add a Table
								new sap.m.TextArea({
									id: riskCommentId,
									editable: statuscheckval,
									value: (latestRiskComment?.comment && latestRiskComment.comment.startsWith("Risk Analysis: "))
										? latestRiskComment.comment.replace("Risk Analysis: ", "") : '',
									width: "70vw",
									rows: 3,
									cols: 800
								}),
								new sap.m.Button({
									text: "Comment History",
									press: function (oEvent) {
										debugger
										onCommenthistoryPress.call(this, oEvent);
									}
								})
							]
						})

						// Add contentContainerinvestmentcomment to your layout or page here if necessary

					} else {
						console.log("No comments starting with 'Investment_Screen3' found.");
						// Generate a unique ID for the risk comment TextArea
						let riskCommentId = generateXmlValidId("riskcomment");

						// Handle the case where no comments are found (optional):
						var contentContainerRiskcomment = new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								// Add a Table
								new sap.m.TextArea({
									id: riskCommentId,
									editable: statuscheckval,
									width: "70vw",
									rows: 3,
									cols: 800
								}),
								new sap.m.Button({
									text: "Comment History",
									press: function (oEvent) {
										debugger
										onCommenthistoryPress.call(this, oEvent);
									}
								})
							]
						})

						// Add the empty container to your layout if necessary
					}


					sap.ui.getCore().byId("vendoronboardsupplier::vobSupplierObjectPage--fe::CustomSection::Riskanalysis").addSubSection(
						new sap.uxap.ObjectPageSubSection({
							title: "Comment",
							blocks: [
								contentContainerRiskcomment // Use the variable here
							]
						})
					);
				}
			}
			catch {
				MessageToast.show("An error occurred while Discarding.");
			}
			finally {
				busy.close();
			}
		}
	};
});
