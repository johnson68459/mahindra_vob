sap.ui.define([
    "sap/m/MessageToast",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Text",
    "sap/m/VBox",
    "sap/suite/ui/commons/TimelineItem"
], function (MessageToast, Dialog, Button, Text, VBox, TimelineItem) {
    'use strict';

    return {
        onPress: async function (oEvent) {
            debugger

            // var str = this.getBindingContext().sPath;
            // // Regular expression to match the UUID pattern within parentheses
            // var uuidRegex = /\(([^)]+)\)/;

            // // Extracting the UUID from the string using match function and regex
            // var match = str.match(uuidRegex);

            // // Check if match is found and extract the UUID
            // var extractedUuid = match ? match[1] : null;

            var url = window.location.hash;
            const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
            const matches = url.match(regex);
            var extractedUuid = matches[1];
            // var extractedUuid = "70ac0c95-4022-4da3-b6e6-4aea987d03f7";

            var cdialog = new sap.m.Dialog({
                title: "Comments",
                endButton: new sap.m.Button({
                    text: "Close",
                    press: async function () {
                        cdialog.close();
                    },
                    layoutData: new sap.m.FlexItemData({
                        // Add layoutData for flexible item behavior
                        growFactor: 5,
                        alignSelf: "End" // Align the button to the end (right)
                    })
                })
            });
            cdialog.addContent(new sap.m.VBox({
                width: "60vw"
            }));

            debugger
            // var comment_value = sap.ui.getCore().byId("vobmah::VOBObjectPage--fe::CustomSection::Comments-innerGrid").mAggregations.content[0].mAggregations._grid.mAggregations.content[0].mAggregations.content.mAggregations.items[0].mAggregations.items[0].mProperties.value
            let oFunction1 = this.getModel().bindContext("/commentfunction(...)");
            var statusval1 = JSON.stringify({ id: extractedUuid, status: "screen2commentview" })
            oFunction1.setParameter("status", statusval1)
            await oFunction1.execute()
            debugger
            var result1 = oFunction1.getBoundContext().getValue()?.value;
            var comments = JSON.parse(result1);
            comments.forEach(function (entry) {
                if (entry.comment.startsWith("Risk Analysis_Screen3") || entry.comment.startsWith("Investment_Screen3")) {
                    console.log("Comments Ignored:", entry.comment)
                }
                else {
                    var oTimelineItem = new sap.suite.ui.commons.TimelineItem({
                        dateTime: entry.createdAt, // Comment timestamp
                        text: entry.comment, // Comment text
                        userName: entry.createdBy // Comment creator
                    });
                    cdialog.addContent(oTimelineItem);
                }

            });


            cdialog.open(); // Open the dialog
            debugger

        },
        oncommentpresssupplier: async function (oEvent) {
            debugger
            var dialogcomment = new Dialog({
                title: "Comments",
                beginButton: new Button({
                    text: "Close",
                    press: function (oEvent) {
                        dialogcomment.close();
                    }
                })

            });

            // var currentUrl = window.location.href;
            // var uuidRegex = /id=([0-9a-fA-F-]+),/;
            // var extractedUuid = currentUrl.match(uuidRegex)[1];
            // var extractedUuid = "70ac0c95-4022-4da3-b6e6-4aea987d03f7";
            var url = window.location.hash;
            const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
            const matches = url.match(regex);
            var extractedUuid = matches[1];


            let oFunction1 = this.getModel().bindContext("/commentfunction(...)");
            var statusval1 = JSON.stringify({ id: extractedUuid, status: "screen2commentview" })
            oFunction1.setParameter("status", statusval1)
            await oFunction1.execute()
            debugger
            var result1 = oFunction1.getBoundContext().getValue()?.value;
            var comments = JSON.parse(result1);
            comments.forEach(function (entry) {
                if (entry.comment.startsWith("Risk Analysis_Screen3") || entry.comment.startsWith("Investment_Screen3")) {
                    console.log("Comments Ignored:", entry.comment)
                }
                else {
                    var oTimelineItem = new sap.suite.ui.commons.TimelineItem({
                        dateTime: entry.createdAt, // Comment timestamp
                        text: entry.comment, // Comment text
                        userName: entry.createdBy // Comment creator
                    });
                    dialogcomment.addContent(oTimelineItem);
                }
                debugger
            });
            dialogcomment.open();
        }
    };
});
