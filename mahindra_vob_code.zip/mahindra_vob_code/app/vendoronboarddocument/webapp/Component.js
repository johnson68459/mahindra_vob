sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("vendoronboarddocument.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);