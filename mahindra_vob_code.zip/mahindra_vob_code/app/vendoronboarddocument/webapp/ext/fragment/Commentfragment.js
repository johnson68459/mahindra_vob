sap.ui.define([
    "sap/m/MessageToast",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Text",
    "sap/m/VBox",
    "sap/suite/ui/commons/TimelineItem"
], function (MessageToast, Dialog, Button, Text, VBox, TimelineItem) {
    'use strict';

    return {

        onpresscommentdoc: async function (oEvent) {
            debugger
            var dialogcomment = new Dialog({
                title: "Comments",
                beginButton: new Button({
                    text: "Close",
                    press: function (oEvent) {
                        dialogcomment.close();
                    }
                })

            });
            var url = window.location.hash;
            const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
            const matches = url.match(regex);
            var extractedUuid = matches[1];
            // var extractedUuid = "70ac0c95-4022-4da3-b6e6-4aea987d03f7";

            let oFunction1 = this.getModel().bindContext("/commentfunction(...)");
            var statusval1 = JSON.stringify({ id: extractedUuid, status: "vendoronboarddocument" })
            oFunction1.setParameter("status", statusval1)
            await oFunction1.execute()
            debugger
            var result1 = oFunction1.getBoundContext().getValue()?.value;
            var comments = JSON.parse(result1);
            comments.forEach(function (entry) {

                var oTimelineItem = new sap.suite.ui.commons.TimelineItem({
                    dateTime: entry.createdAt, // Comment timestamp
                    text: entry.comment, // Comment text
                    userName: entry.createdBy // Comment creator
                });
                dialogcomment.addContent(oTimelineItem);


            });
            dialogcomment.open();
        }
    };
});
