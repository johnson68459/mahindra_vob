sap.ui.define([
    "sap/m/MessageToast",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/library",
    "sap/m/List",
    "sap/m/StandardListItem",
    "sap/m/Text",
    "sap/ui/unified/FileUploader",
    "sap/ui/core/BusyIndicator"
], function (MessageToast, Dialog, Button, mobileLibrary, List, StandardListItem, Text, FileUploader, BusyIndicator) {
    'use strict';

    // shortcut for sap.m.ButtonType
    var ButtonType = mobileLibrary.ButtonType;

    // shortcut for sap.m.DialogType
    var DialogType = mobileLibrary.DialogType;
    var Base64Data;

    var vobid;
    var oBaseUri;
    // var that = this;
    var onOpenPressed = async (oEvent) => {
        debugger
        BusyIndicator.show(); // Show the busy indicator before starting the process
        try {
            oEvent.preventDefault();
            let filename = oEvent.getSource().getBindingContext().getObject().fileName;
            let path = oEvent.getSource().getBindingContext().getObject().folder;

            // Get the signed URL from the backend
            let oFunction = oEvent.getSource().getModel().bindContext("/getFileForVOB(...)");
            oFunction.setParameter("fileName", path); // 
            await oFunction.execute();

            // Retrieve the signed URL directly
            let fileUrl = oFunction.getBoundContext().getValue().value;
            let fileExtension = filename.split('.').pop().toLowerCase(); // Extract file extension

            // Check the file type to determine whether to open in a new window or download
            if (["pdf", "png", "jpeg", "jpg"].includes(fileExtension)) {
                // For PDF and image files, open them in a new window
                let newWindow = window.open(fileUrl, '_blank');
                if (!newWindow) {
                    sap.m.MessageToast.show("Please allow pop-ups to view the file.");
                }
            } else {
                // For other file types, initiate download
                let link = document.createElement("a");
                link.href = fileUrl;
                link.download = filename; // Set the file name for download
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link); // Clean up
            }
        } catch (error) {
            // Log the error and show a toast message or handle the error
            console.error("An error occurred:", error);
            sap.m.MessageToast.show("An error occurred while opening the file.");
        } finally {
            // Hide the busy indicator after the process is complete (success or failure)
            BusyIndicator.hide();
        }
    };
    var onRemovePressed = async (oEvent) => {
        debugger
        oEvent.preventDefault();
        BusyIndicator.show();
        let path = oEvent.getSource().data("fileData").folder;
        let filename = oEvent.getSource().data("fileData").fileName;

        let oFunction = oEvent.getSource().getModel().bindContext("/deleteFileForVOB(...)");
        oFunction.setParameter("fileName", `${path}`);
        await oFunction.execute();
        let returnValue = oFunction.getBoundContext().getValue().value;

        var oUploadSet = sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Uploadset--uploadtest");

        // Refresh the UploadSet after the file is uploaded
        if (oUploadSet) {
            debugger;
            await $.ajax({
                url: oBaseUri + `odata/v4/vob/vobMain(${vobid})/vob_files`,
                method: 'GET',
                success: function (response) {
                    debugger;

                    // Clear any existing items in the UploadSet
                    oUploadSet.removeAllItems();

                    // Assuming the response contains an array of files in response.value
                    if (response && response.value) {
                        response.value.forEach(function (file) {
                            // Create a new UploadSetItem for each file
                            var oUploadSetItem = new sap.m.upload.UploadSetItem({
                                fileName: file.fileName, // Assuming file object has fileName property
                                // Add other properties if needed, like url, mimeType, etc.
                                url: file.url, // Adjust based on your response structure
                                mimeType: file.mimeType,// Adjust based on your response structure,
                                enabledEdit: false,
                                visibleEdit: false,
                                openPressed: function (oEvent) {
                                    onOpenPressed.call(this, oEvent);
                                },
                                removePressed: function (oEvent) {
                                    onRemovePressed.call(this, oEvent);
                                }
                            });

                            // Bind additional attributes
                            oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                title: "Uploaded By",
                                text: file.createdBy // Assuming file object has createdBy property
                            }));
                            oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                title: "Uploaded on",
                                text: file.createdAt // Assuming file object has createdAt property
                            }));
                            oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                title: "File Type",
                                text: file.mediaType // Assuming file object has mediaType property
                            }));
                            oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                title: "Path",
                                text: file.folder // Assuming file object has folder property
                            }));

                            oUploadSetItem.data("fileData", file);
                            // Add the UploadSetItem to the UploadSet
                            oUploadSet.addItem(oUploadSetItem);
                        });
                    }
                },
                error: function (error) {
                    debugger;
                    BusyIndicator.hide();
                    console.error("Error retrieving files:", error);
                    // Handle error (e.g., show a message to the user)
                }
            });
        }
        BusyIndicator.hide();
        MessageToast.show(`${returnValue}`);
    }

    return {
        onPress: function (oEvent) {

        },
        onAfterItemAdded: function (oEvent) {
            debugger
            var url = window.location.href;
            const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
            const matches = url.match(regex);

            // let vobId = '';
            // let IsActiveEntity = '';
            if (matches) {
                id = matches[1];
                // IsActiveEntity = matches[2];
            }
            var item = oEvent.getParameter("item")
            let uploadset = item.getParent();

            let _uploadContent = async function (uploadset, item, id) {
                debugger;
                var url = `/odata/v4/vob/Files(${id})/content`
                item.setUploadUrl(url);
                item.setUrl(url);
                // var oUploadSet = item.getParent();
                // uploadset.setHttpRequestMethod("PUT");
                debugger;
                await uploadset.uploadItem(item);
            };

            let _createEntity = function (uploadset, item) {
                debugger;
                var data = {
                    mediaType: item.getMediaType(),
                    fileName: item.getFileName(),
                    // size: item.getFileObject().size,
                    vob_id: id
                };

                var settings = {
                    // url: "/odata/v4/vob/Files",
                    url: oBaseUri + "odata/v4/vob/Files",
                    method: "POST",
                    headers: {
                        "Content-type": "application/json"
                    },
                    data: JSON.stringify(data)
                }

                return new Promise((resolve, reject) => {
                    $.ajax(settings)
                        .done((results, textStatus, request) => {
                            resolve(results.ID);
                        })
                        .fail((err) => {
                            reject(err);
                        })
                })
            }


            _createEntity(uploadset, item)
                .then((id) => {
                    debugger
                    _uploadContent(uploadset, item, id);
                })
                .catch((err) => {
                    console.log(err);
                })

        },

        onUploadCompleted: async function (oEvent) {
            debugger;
            var oUploadSet = this.byId("uploadtest");
            oUploadSet.removeAllIncompleteItems();
            oUploadSet.getBinding("items").refresh();
        },

        onOpenPressed: async function (oEvent) {
            BusyIndicator.show(); // Show the busy indicator before starting the process
            try {
                oEvent.preventDefault();
                let filename = oEvent.getSource().getBindingContext().getObject().fileName;
                let path = oEvent.getSource().getBindingContext().getObject().folder;

                // Get the signed URL from the backend
                let oFunction = oEvent.getSource().getModel().bindContext("/getFileForVOB(...)");
                oFunction.setParameter("fileName", path); // 
                await oFunction.execute();

                // Retrieve the signed URL directly
                let fileUrl = oFunction.getBoundContext().getValue().value;
                let fileExtension = filename.split('.').pop().toLowerCase(); // Extract file extension

                // Check the file type to determine whether to open in a new window or download
                if (["pdf", "png", "jpeg", "jpg"].includes(fileExtension)) {
                    // For PDF and image files, open them in a new window
                    let newWindow = window.open(fileUrl, '_blank');
                    if (!newWindow) {
                        sap.m.MessageToast.show("Please allow pop-ups to view the file.");
                    }
                } else {
                    // For other file types, initiate download
                    let link = document.createElement("a");
                    link.href = fileUrl;
                    link.download = filename; // Set the file name for download
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link); // Clean up
                }
            } catch (error) {
                // Log the error and show a toast message or handle the error
                console.error("An error occurred:", error);
                sap.m.MessageToast.show("An error occurred while opening the file.");
            } finally {
                // Hide the busy indicator after the process is complete (success or failure)
                BusyIndicator.hide();
            }
        },
        onRemovePressed: async function (oEvent) {
            debugger

            var url = window.location.href;
            const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
            const matches = url.match(regex);

            // Get the base URI from the manifest object
            oBaseUri = this._view.getParent().getAppComponent().getManifestObject()._oBaseUri._string;
            // oBaseUri = "/"

            if (matches) {
                vobid = matches[1];
            }
            BusyIndicator.show();
            oEvent.preventDefault();
            let path = oEvent.getSource().getBindingContext().getObject().folder;
            let filename = oEvent.getSource().getBindingContext().getObject().fileName;

            let oFunction = oEvent.getSource().getModel().bindContext("/deleteFileForVOB(...)");
            oFunction.setParameter("fileName", `${path}`);
            await oFunction.execute();
            let returnValue = oFunction.getBoundContext().getValue().value;

            var oUploadSet = sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Uploadset--uploadtest");

            // Refresh the UploadSet after the file is uploaded
            if (oUploadSet) {
                debugger;
                // Make the AJAX call to retrieve files
                await $.ajax({
                    url: oBaseUri + `odata/v4/vob/vobMain(${vobid})/vob_files`,
                    method: 'GET',
                    success: function (response) {
                        debugger;

                        // Clear any existing items in the UploadSet
                        oUploadSet.removeAllItems();

                        // Assuming the response contains an array of files in response.value
                        if (response && response.value) {
                            response.value.forEach(function (file) {
                                // Create a new UploadSetItem for each file
                                var oUploadSetItem = new sap.m.upload.UploadSetItem({
                                    fileName: file.fileName, // Assuming file object has fileName property
                                    // Add other properties if needed, like url, mimeType, etc.
                                    url: file.url, // Adjust based on your response structure
                                    mimeType: file.mimeType,// Adjust based on your response structure,
                                    enabledEdit: false,
                                    visibleEdit: false,
                                    openPressed: function (oEvent) {
                                        onOpenPressed.call(this, oEvent);
                                    },
                                    removePressed: function (oEvent) {
                                        onRemovePressed.call(this, oEvent);
                                    }
                                });

                                // Bind additional attributes
                                oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                    title: "Uploaded By",
                                    text: file.createdBy // Assuming file object has createdBy property
                                }));
                                oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                    title: "Uploaded on",
                                    text: file.createdAt // Assuming file object has createdAt property
                                }));
                                oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                    title: "File Type",
                                    text: file.mediaType // Assuming file object has mediaType property
                                }));
                                oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                    title: "Path",
                                    text: file.folder // Assuming file object has folder property
                                }));

                                oUploadSetItem.data("fileData", file);
                                // Add the UploadSetItem to the UploadSet
                                oUploadSet.addItem(oUploadSetItem);
                            });
                            BusyIndicator.hide();
                        }
                    },
                    error: function (error) {
                        debugger;
                        BusyIndicator.hide();
                        console.error("Error retrieving files:", error);
                        // Handle error (e.g., show a message to the user)
                    }
                });
                BusyIndicator.hide();
            }
            BusyIndicator.hide();
            MessageToast.show(`${returnValue}`);
        },

        formatThumbnailUrl: function (mediaType) {
            var iconUrl;
            switch (mediaType) {
                case "image/png":
                    iconUrl = "sap-icon://card";
                    break;
                case "text/plain":
                    iconUrl = "sap-icon://document-text";
                    break;
                case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                    iconUrl = "sap-icon://excel-attachment";
                    break;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                    iconUrl = "sap-icon://doc-attachment";
                    break;
                case "application/pdf":
                    iconUrl = "sap-icon://pdf-attachment";
                    break;
                default:
                    iconUrl = "sap-icon://attachment";
            }
        },
        onFileUploadPress: function (oEvent) {
            debugger;

            var url = window.location.href;
            const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
            const matches = url.match(regex);

            // Get the base URI from the manifest object
            oBaseUri = this._view.getParent().getAppComponent().getManifestObject()._oBaseUri._string;
            // oBaseUri = "/"

            if (matches) {
                vobid = matches[1];
            }
            debugger
            var oFunctionForSignedUrl = this.getModel().bindContext("/getSignedURLForDocUpload(...)");
            var notifyBackendForGCS = this.getModel().bindContext("/notifyBackendForGCS(...)");
            var fileSizeInMb = oEvent.oSource.oModels.fileButtonModel.oData.fileSize;
            var fileTypeInString = oEvent.oSource.oModels.fileButtonModel.oData.fileTypeInString;
            console.log(typeof fileSizeInMb);

            var SelectedFile;
            var oDialog;
            if (!oDialog) {
                oDialog = new Dialog({
                    title: "Upload File",
                    type: sap.m.DialogType.Message,
                    content: new FileUploader({
                        maximumFileSize: fileSizeInMb,
                        fileType: fileTypeInString,
                        fileSizeExceed: function (oEvent) {
                            debugger
                            MessageToast.show(`The file size exceeds the allowed limit of ${fileSizeInMb} MB. Please upload a smaller file.`)
                        },
                        change: function (oEvent) {
                            debugger;
                            var oFileUploader = oEvent.getSource();
                            var aFiles = oEvent.getParameter("files"); // Get the uploaded file(s)
                            if (aFiles && aFiles.length > 0) {
                                var oFile = aFiles[0]; // Get the first file (handle multiple files if needed)
                                SelectedFile = aFiles[0];
                                function readFileAsBase64(oFile) {
                                    return new Promise((resolve, reject) => {
                                        var reader = new FileReader();

                                        reader.onload = function (e) {
                                            var sBase64 = e.target.result.split(',')[1]; // Extract base64
                                            resolve(sBase64);
                                        };

                                        reader.onerror = function (error) {
                                            reject(error);
                                        };

                                        reader.readAsDataURL(oFile); // Start reading the file
                                    });
                                }

                                readFileAsBase64(oFile)
                                    .then((sBase64) => {
                                        debugger;
                                        Base64Data = sBase64; // Set base64 data for later use
                                        SelectedFile = oFile; // Store the selected file
                                    })
                                    .catch((error) => {
                                        console.error("Error reading file: ", error);
                                    });
                            }
                        }
                    }),
                    beginButton: new Button({
                        type: ButtonType.Emphasized,
                        text: "OK",
                        press: async function (oEvent) {
                            BusyIndicator.show();

                            if (SelectedFile) {
                                function sanitizeFileName(fileName) {
                                    // Define allowed characters (letters, numbers, dashes, underscores, and dots)
                                    const sanitizedFileName = fileName.replace(/[^a-zA-Z0-9_\-\.]/g, "_");

                                    // Optionally, limit the length of the file name to a specific number of characters
                                    return sanitizedFileName.substring(0, 255); // Max length of 255 characters
                                }
                                let sanitizedFileName = sanitizeFileName(SelectedFile.name);
                                const fileName = sanitizedFileName;
                                const mediaType = SelectedFile.type || "application/octet-stream";
                                var malwareDetected; 

                                try {

                                    await $.ajax({
                                        url: oBaseUri + `odata/v4/vob/scanMalwareFile`,
                                        type: "POST",
                                        contentType: "application/json",
                                        data: JSON.stringify({
                                            filedata: Base64Data
                                        }),
                                        success: function (response) {
                                            var response = response;
                                            malwareDetected = response.value.malwareDetected
                                        },
                                        error: function (error) {
                                            debugger;
                                            BusyIndicator.hide();
                                            console.error("Error retrieving files:", error);
                                            // Handle error (e.g., show a message to the user)
                                        }
                                    });
                                    if (malwareDetected == false) {

                                        // Step 1: Request signed URL from backend
                                        oFunctionForSignedUrl.setParameter("fileName", fileName);
                                        oFunctionForSignedUrl.setParameter("contentType", mediaType);
                                        oFunctionForSignedUrl.setParameter("vobid", vobid);
                                        oFunctionForSignedUrl.setParameter("path", "Backup Document");
                                        await oFunctionForSignedUrl.execute();
                                        const signedUrlResponse = oFunctionForSignedUrl.getBoundContext().getValue();

                                        const signedUrl = signedUrlResponse.signedUrl;
                                        const filePath = signedUrlResponse.filePath;

                                        // Step 2: Upload the file to Google Cloud Storage
                                        await $.ajax({
                                            url: signedUrl,
                                            method: "PUT",
                                            contentType: mediaType,
                                            processData: false,
                                            data: SelectedFile
                                        });
                                        console.log("File uploaded successfully to path:", filePath);

                                        // Step 3: Notify backend about the uploaded file
                                        notifyBackendForGCS.setParameter("fileName", fileName);
                                        notifyBackendForGCS.setParameter("contentType", mediaType);
                                        notifyBackendForGCS.setParameter("vobid", vobid);
                                        notifyBackendForGCS.setParameter("path", filePath);
                                        await notifyBackendForGCS.execute();

                                        // Step 4: Refresh the UploadSet
                                        const oUploadSet = sap.ui.getCore().byId(
                                            "vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Uploadset--uploadtest"
                                        );

                                        oUploadSet.getBinding("items").refresh();
                                        // if (oUploadSet) {
                                        //     await $.ajax({
                                        //         url: oBaseUri + `odata/v4/vob/vobMain(${vobid})/vob_files`,
                                        //         method: "GET",
                                        //         success: function (response) {
                                        //             oUploadSet.removeAllItems(); // Clear existing items
                                        //             response.value.forEach(function (file) {
                                        //                 const oUploadSetItem = new sap.m.upload.UploadSetItem({
                                        //                     fileName: file.fileName,
                                        //                     url: file.url,
                                        //                     mimeType: file.mimeType,
                                        //                     enabledEdit: false,
                                        //                     visibleEdit: false,
                                        //                     openPressed: function (oEvent) {
                                        //                         onOpenPressed.call(this, oEvent);
                                        //                     },
                                        //                     removePressed: function (oEvent) {
                                        //                         onRemovePressed.call(this, oEvent);
                                        //                     }
                                        //                 });

                                        //                 // Add additional attributes
                                        //                 oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                        //                     title: "Uploaded By",
                                        //                     text: file.createdBy
                                        //                 }));
                                        //                 oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                        //                     title: "Uploaded on",
                                        //                     text: file.createdAt
                                        //                 }));
                                        //                 oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                        //                     title: "File Type",
                                        //                     text: file.mediaType
                                        //                 }));
                                        //                 oUploadSetItem.addAttribute(new sap.m.ObjectAttribute({
                                        //                     title: "Path",
                                        //                     text: file.folder
                                        //                 }));

                                        //                 oUploadSetItem.data("fileData", file);
                                        //                 oUploadSet.addItem(oUploadSetItem);
                                        //             });
                                        //         },
                                        //         error: function (error) {
                                        //             console.error("Error refreshing UploadSet:", error);
                                        //         }
                                        //     });
                                        // }
                                    }
                                    else {
                                        MessageToast.show("File contains Malware");
                                    }

                                    BusyIndicator.hide();
                                    oDialog.close();
                                } catch (error) {
                                    BusyIndicator.hide();
                                    console.error("Error during file upload process:", error);
                                }
                            } else {
                                BusyIndicator.hide();
                                MessageToast.show("Select a File !!!");
                            }
                        }
                    }),

                    endButton: new Button({
                        text: "Close",
                        press: function () {
                            oDialog.close();
                        }
                    })
                });
            }


            oDialog.open();
        }

    };
});
