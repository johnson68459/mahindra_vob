sap.ui.define(['sap/ui/core/mvc/ControllerExtension',
	'sap/m/HBox',
	"sap/m/Table",
	"sap/m/Column",
	"sap/m/ColumnListItem",
	"sap/m/Text",
	"sap/m/Input",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/CheckBox",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Icon",
	"sap/m/library",], function (ControllerExtension, HBox, Table, Column, ColumnListItem, Text, Input, Button, Dialog, CheckBox, MessageToast, JSONModel, Icon, mobileLibrary) {
		'use strict';

		function generateXmlValidId(suffix = "id") {
			// Ensure the suffix is valid by removing any invalid characters
			const validSuffix = suffix.replace(/[^A-Za-z0-9_.-]/g, "");

			// Generate a random part using alphanumeric characters
			const randomPart = Math.random().toString(36).substring(2, 10);

			// Ensure the ID starts with a letter or underscore, as required by XML rules
			const validStart = "x"; // Default starting letter to ensure validity

			// Combine the random part and suffix to form the ID
			return `${validStart}-${randomPart}-${validSuffix}`;
		}

		return ControllerExtension.extend('vendoronboarddocument.ext.controller.Objectpage', {
			// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
			override: {
				/**
				 * Called when a controller is instantiated and its View controls (if available) are already created.
				 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
				 * @memberOf vendoronboarddocument.ext.controller.Objectpage
				 */
				onInit: function () {

					// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
					var oModel = this.base.getExtensionAPI().getModel();
				},
				routing: {
					onAfterBinding: async function () {

						debugger
						// const username = "sbss_yfu6mqfqdbkpsrzdeuvd1dloelk9gz7dqx8acs3hxd2q0hsxqna8xouybg7wxf967ze="; // Replace with your username
						// const password = "aa_t9l4vg9fe+qJO6+9nBcb+Z1rwD4="; // Replace with your password

						// const credentials = btoa(`${username}:${password}`); // Encode credentials in Base64
						// const headers = {
						// 	"Authorization": `Basic ${credentials}`,
						// 	"Content-Type": "application/json", // Adjust content type if needed
						// };

						// $.ajax({
						// 	url: "https://malware-scanner.cf.eu10.hana.ondemand.com/info",
						// 	type: "GET", // Change to "POST" if required by the API
						// 	headers: headers, // Pass headers including Authorization
						// 	success: function (response) {
						// 		console.log("API response:", response);
						// 		// Handle response
						// 	},
						// 	error: function (error) {
						// 		console.error("API error:", error);
						// 		// Handle error
						// 	},
						// });




						var oBusyDialog = new sap.m.BusyDialog({
							title: "Loading",
							text: "Please wait..."
						});

						oBusyDialog.open();

						//Second Section
				


						var headerActions = this.base.getView().getContent()[0].getHeaderTitle();
						headerActions.destroyActions();

						var url = window.location.hash;
						const regex2 = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
						const matches2 = url.match(regex2);
						var id = matches2[1];
						var isVisible;
						var finalsupp;
						var workflowresp;
						var comments;

						async function allFunctionCall() {
							let oFunction = this.getView().getModel().bindContext("/getStatus(...)");
							oFunction.setParameter("vobid", id);
							await oFunction.execute();
							var result = oFunction.getBoundContext().getValue().value;
							isVisible = (result === "New" || result === "Rejected");


							let oFunction1 = this.getView().getModel().bindContext("/documentscreenfunc(...)");
							var statusval1 = JSON.stringify({ id: id, status: "getvendordetails" })
							oFunction1.setParameter("status", statusval1)
							await oFunction1.execute()
							var result1 = oFunction1.getBoundContext().getValue().value;
							finalsupp = JSON.parse(result1);



							let oFunction2 = this.getView().getModel().bindContext("/workflowdata(...)");

							oFunction2.setParameter("vobid", id);
							try {
								// Set parameter and execute the function
								oFunction2.setParameter("vobid", id);
								oFunction2.setParameter("status", "approverdata");
								await oFunction2.execute();
								console.log("Function executed successfully.");

								// Get the bound context
								const boundContext = oFunction2.getBoundContext();
								if (!boundContext) {
									// console.error("Bound context is null.");
									// return;
								}

								// Get the value from the bound context
								const contextValue = boundContext.getValue();
								if (!contextValue) {
									// console.error("Context value is null.");
									// return;
									workflowresp = []
								}
								else {
									var result1 = contextValue.value;
									workflowresp = JSON.parse(result1);
									// console.log(workflowresp);
								}

								// Access the value property


							} catch (error) {
								console.error("Error executing function:", error);
							}

						}
						await allFunctionCall.call(this);

						//To set size for the Attachments
						let fileUploaderbutton = sap.ui.getCore().byId(jQuery(`[id$='fileUploaderbutton']`).attr("id"));
						let oModel = new sap.ui.model.json.JSONModel({
							fileSize: finalsupp.fileSize,
							fileTypeInString:finalsupp.fileTypeInString
						});
						// Set the model for the button
						fileUploaderbutton.setModel(oModel, "fileButtonModel");


						// Define the async function for the cash flow section

						async function cashflow() {

							// Define the static fields that will appear in the Cash Flow section
							var fields = [
								"Total Landed Investment - Settled (Rs. lacs)",
								"Total Buying value (Rs. Lac) 1st 12months",
								"Sourcing Partner commission to be paid ( Rs. Lac) 1st 12 months",
								"Sourcing Partner commission to be paid (Rs. Lac)  2nd + 3rd Year",
								"YOY Reduction for 3 yrs (After SOP + 1 year) - If Any",
								"FX Base Rate",
								"Inco Terms",
								"Payment Terms",
								"Transport Cost"
							];

							// Get the reference for the main VBox where the content will be placed
							var mainVbox = this.base.getView().getContent()[0].getSections()[1].getSubSections()[0].mAggregations._grid.mAggregations.content[0].getContent();
							mainVbox.getItems()[0].setWidth("40vw");  // Set width for the first VBox item

							// Clear any existing columns and items from the VBox and Table
							mainVbox.getItems()[0].getItems()[0].destroyColumns();
							mainVbox.getItems()[0].getItems()[0].destroyItems();
							mainVbox.getItems()[1].destroyItems();

							// Get the HBox document and the table for cash flow details
							var oHboxDocument = mainVbox.getItems()[1];
							var otable = mainVbox.getItems()[0].getItems()[0];

							// Create the first column of the table
							var firstColumn = new sap.m.Column({
								header: new HBox({
									justifyContent: "SpaceBetween",
									items: [
										new Text({ text: "MGSP Part No", width: "8vw", tooltip: "MGSP Part No" }),
										new Text({ text: "MGSP Supplier Name", width: "8vw", tooltip: "MGSP Supplier Name" }),
										new Text({ text: "MGSP Vendor Inco Term", width: "8vw", tooltip: "MGSP Vendor Inco Term" }),
										new Text({ text: "Existing MGSP PO Price", width: "8vw", tooltip: "Existing MGSP PO Price" }),
										new Text({ text: "Target Price", width: "8vw", tooltip: "Target Price" })
									]
								}).addStyleClass("hboxHeaderClass")
							});
							otable.addColumn(firstColumn);

							// Add the first row with a "Remarks" column
							var firstItem = new ColumnListItem({
								cells: [new Text({ text: `Remarks` })]
							});
							var modelrowfisrtcol = new JSONModel({ rowid: `Remarks` });
							firstItem.setModel(modelrowfisrtcol, `rowid`);
							otable.addItem(firstItem);

							// Loop through the YOY details from the supplier data and populate the table rows
							for (let i = 0; i < finalsupp.yoy_details.length; i++) {
								let partdetails = finalsupp.yoy_details[i];
								var oColumnListItem = new ColumnListItem({
									cells: [
										new HBox({
											alignItems: "Center",
											justifyContent: "SpaceBetween",
											items: [
												new Text({ text: partdetails.mgsp_part_nos, tooltip: partdetails.mgsp_part_nos, width: "8vw" }),
												new Text({ text: partdetails.msgp_supplier_name, tooltip: partdetails.msgp_supplier_name, width: "8vw" }),
												new Text({ text: partdetails.mgsp_vendor_inco_term, tooltip: partdetails.msgp_supplier_name, width: "8vw" }),
												new Text({ text: partdetails.existing_mgsp_po_price, width: "8vw", tooltip: partdetails.existing_mgsp_po_price }),
												new Text({ text: partdetails.target_price, width: "8vw", tooltip: partdetails.target_price })
											]
										}).addStyleClass("hboxRowClass"),
									]
								});

								// Set the model directly to the ColumnListItem
								var modelrow = new JSONModel({ rowid: partdetails.id });
								oColumnListItem.setModel(modelrow, 'rowid');

								// Add the populated row to the table
								otable.addItem(oColumnListItem);
							}

							// Loop through the defined static fields and add them to the table
							for (let field of fields) {
								var oColumnListItem1 = new ColumnListItem({
									cells: [
										new Text({ text: `${field}` }).addStyleClass("CashFlowStaticFields")
									]
								});
								var modelrow = new JSONModel({ rowid: field });
								oColumnListItem1.setModel(modelrow, `rowid`);
								otable.addItem(oColumnListItem1);
							}

							// Initialize a classIndex to distinguish between suppliers
							var classIndex = 1;

							// Loop through supplier details and create new supplier tables
							for (let supplier of finalsupp.suplier_detail_together) {
								

								// Create a new table for the supplier with a dynamic header
								var newSupplier = new Table({
									width: "20vw",
									columns: new Column({
										header: [
											new HBox({
												items: [
													new Text({ text: `${supplier.supplier}`, tooltip: `${supplier.supplier}` }).addStyleClass(`colorClassDocument` + `${classIndex}`)
												]
											})
										]
									})
								}).addStyleClass("tableClass");

								// Add rows for each item in the main table (otable)
								for (let i = 0; i < otable.getItems().length; i++) {
									let rowid = otable.getItems()[i].oModels.rowid.oData.rowid;

									// Find the supplier-related data for the row
									let itemFound = supplier.rel.find(item => item.value_key == rowid);
									

									// Add a new column list item for the supplier data
									if (itemFound) {
										var oColumnListItem6 = new ColumnListItem({
											cells: [
												new Text({ text: `${itemFound.value}`, tooltip: `${itemFound.value}` })
											]
										});
										newSupplier.addItem(oColumnListItem6);
									} else {
										// If no data found for the supplier, add an empty column
										var oColumnListItem6 = new ColumnListItem({
											cells: [
												new Text({ text: ` ` })
											]
										});
										newSupplier.addItem(oColumnListItem6);
									}
								}

								// Style the specific columns of suppliers based on YOY details
								for (var m = 0; m < finalsupp.yoy_details.length; m++) {
									if (finalsupp.yoy_details[m].supplierid == supplier.id_main) {
										newSupplier.getItems()[m + 1].addStyleClass(`input` + `colorClassDocument` + `${classIndex}`);
									}
								}

								// Increment classIndex for the next supplier
								classIndex = classIndex + 1;

								// Add the newly created supplier table to the HBox
								oHboxDocument.addItem(newSupplier);
							}
						}

						// Call the cashflow function
						cashflow.call(this);





						////////// INVESTMENT BREAKUP SECTION START ///////////////////////

						// Define the async function for the Investment Breakup section
						async function investmentbreakupsection() {

							// Get the main HBox and its child elements
							var docmainHboc = sap.ui.getCore().byId(jQuery("[id$='docinvmainHbox']").attr("id"));
							docmainHboc.getItems()[0].setWidth("40vw"); // Set the width of the first item
							docmainHboc.getItems()[0].getItems()[0].destroyColumns(); // Clear any existing columns
							docmainHboc.getItems()[0].getItems()[0].destroyItems();   // Clear any existing items
							docmainHboc.getItems()[1].destroyItems();                // Clear additional items

							// Get references for the supplier HBox and parent table
							var docsupplierHBox = sap.ui.getCore().byId(jQuery("[id$='docHboxSupplierinvestment']").attr("id"));
							var docparttable = sap.ui.getCore().byId(jQuery("[id$='docparentTableinvestment']").attr("id"));

							// Add the first column to the investment breakup table
							var invfirstColumn = new sap.m.Column({
								header: new Text({ text: "All figures in Rs.Lacs", tooltip: "All figures in Rs.Lacs", textAlign: "End" }),
							});
							docparttable.addColumn(invfirstColumn);

							// Function to create a column list item with left and right values
							function createColumnListItem(leftValue, rightValue) {
								var oColumnListItem = new ColumnListItem({
									cells: [
										new HBox({
											justifyContent: "SpaceBetween",
											items: [
												new Text({ text: leftValue }), // Left-aligned text
												new Text({ text: rightValue }) // Right-aligned text
											]
										})
									]
								}).addStyleClass("capexUpperSectionClass"); // Add CSS class for styling
								var modelrow = new JSONModel({
									rowid: rightValue // Set row ID in the model
								});
								oColumnListItem.setModel(modelrow, `rowid`);
								return oColumnListItem;
							}

							// Define the table rows (investment categories)
							const items = [
								["Capex", "Tooling / Dies / Moulds / Fixtures"],
								[" ", "Inspection Gauges"],
								["Revenue", "Testing / Validation"],
								[" ", "Engg Fees"],
								[" ", "Proto Tooling"],
								[" ", "Logistics Trollies"],
								[" ", "Total Landed Investment Settled"]
							];

							// Add rows to the parent table using the defined items
							items.forEach(([left, right]) => {
								docparttable.addItem(createColumnListItem(left, right));
							});

							// Loop through supplier details to create corresponding columns
							for (let supplier of finalsupp.suplier_detail_together) {
							

								// Create a new supplier table
								var newSupplier = new Table({
									width: "20vw",
									columns: new Column({
										header: [
											new HBox({
												items: [
													new Text({ text: `${supplier.supplier}`, tooltip: `${supplier.supplier}` })
												]
											})
										]
									})
								}).addStyleClass("tableClass");

								// Add rows for each item in the parent table
								for (let i = 0; i < docparttable.getItems().length; i++) {
									let rowid = docparttable.getItems()[i].oModels.rowid.oData.rowid;

									// Find matching supplier data based on row ID
									let itemFound = supplier.rel.find(item => item.value_key == rowid);
							
									if (itemFound) {
										// Add a row with the matching value
										var oColumnListItem6 = new ColumnListItem({
											cells: [
												new Text({ text: `${itemFound.value}`, tooltip: `${itemFound.value}` })
											]
										});
										newSupplier.addItem(oColumnListItem6);
									} else {
										// Add an empty row if no match is found
										var oColumnListItem6 = new ColumnListItem({
											cells: [
												new Text({ text: ` ` })
											]
										});
										newSupplier.addItem(oColumnListItem6);
									}
								}

								// Add the supplier table to the HBox
								docsupplierHBox.addItem(newSupplier);
							}

							// Create the comment section with a TextArea
							var investmentbreakupcomment = new sap.m.HBox({
								items: [
									new sap.m.TextArea({
										value: "demo", // Placeholder text
										width: "70vw",
										rows: 8 // Number of rows for the TextArea
									}),
								]
							});

							// Add the comment subsection to the Investment Breakup section
							sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSection::InvestmentBreakup").addSubSection(
								new sap.uxap.ObjectPageSubSection({
									visible: false, // Initially hidden
									title: "Comment", // Title of the subsection
									blocks: [
										investmentbreakupcomment // Add the HBox containing the TextArea
									]
								})
							);
						}

						// Call the Investment Breakup section function
						investmentbreakupsection.call(this);

						////////// INVESTMENT BREAKUP SECTION END ///////////////////////





						/// ITEM DATA SECTION START ///

						// Define the item data section
						async function itemDataSection() {
							// Get references to main HBox and other UI elements
							var docmainHboc = sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Itemdata--mainhoxitem");
							docmainHboc.getItems()[0].setWidth("40vw");
							docmainHboc.getItems()[0].getItems()[0].destroyColumns(); // Clear existing columns
							docmainHboc.getItems()[0].getItems()[0].destroyItems();   // Clear existing items
							docmainHboc.getItems()[1].destroyItems();                // Clear other items

							// Get references to supplier HBox and parent table for item data
							var itemsupplierHBox = sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Itemdata--HboxSupplieritem");
							var itemparttable = sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Itemdata--parentTableitem");

							// Add columns to the item part table
							var datafirstColumn = new sap.m.Column({
								header: [new Text({ text: "MGSP Part No", tooltip: "MGSP Part No", textAlign: "End" })]
							});
							var datasecondcolumn = new sap.m.Column({
								header: [new Text({ text: "Finished Weight of Part / System (kg)", tooltip: "Finished Weight of Part / System (kg)", textAlign: "End" })]
							});
							itemparttable.addColumn(datafirstColumn);
							itemparttable.addColumn(datasecondcolumn);

							// Loop through the YOY details and populate the item part table
							for (let i = 0; i < finalsupp.yoy_details.length; i++) {
								let partdetails = finalsupp.yoy_details[i];
								var oColumnListItem = new ColumnListItem({
									cells: [
										new Text({ text: partdetails.mgsp_part_nos, tooltip: partdetails.mgsp_part_nos }),
										new Text({
											text: isNaN(partdetails.finished_weight_of_part) ? null : `${partdetails.finished_weight_of_part}`,
											tooltip: isNaN(partdetails.finished_weight_of_part) ? null : `${partdetails.finished_weight_of_part}`
										})
									]
								});
								itemparttable.addItem(oColumnListItem); // Add item to the table
							}

							/// ITEM DATA SUBSECTION CREATION ///
							var contentContainerDTB = new sap.m.HBox({
								items: [
									new sap.m.Table(), // Table for DTB
									new sap.m.HBox()   // HBox for left side section
								]
							});

							// Configure the DTB table
							var dtbtable = contentContainerDTB.getItems()[0];
							var dtbleftsidesection = contentContainerDTB.getItems()[1];
							dtbtable.addStyleClass("tableClass");
							dtbtable.setWidth("40vw");
							dtbleftsidesection.addStyleClass("rightHboxClass");

							// Add a column for MGSP Part No in DTB table
							var dtbfirstColumn = new sap.m.Column({
								width: "500px",
								header: new Text({ text: "MGSP Part No", tooltip: "MGSP Part No" })
							});
							dtbtable.addColumn(dtbfirstColumn);

							// Populate DTB table with YOY details
							for (let i = 0; i < finalsupp.yoy_details.length; i++) {
								let partdetails = finalsupp.yoy_details[i];
								var oColumnListItem = new ColumnListItem({
									cells: [new Text({ text: `${partdetails.mgsp_part_nos}`, tooltip: `${partdetails.mgsp_part_nos}` })]
								});

								// Set model to the ColumnListItem
								var modelrow = new JSONModel({
									rowid: partdetails.id + "DTB Packaging Cost Rs. (Included in above Offer prices)"
								});
								oColumnListItem.setModel(modelrow, 'rowid');

								// If supplier ID is available, set it to the model
								if (partdetails.supplierid) {
									var supplierid = new JSONModel({ supplierid: partdetails.supplierid });
									oColumnListItem.setModel(supplierid, `supplierid`);
								}

								dtbtable.addItem(oColumnListItem); // Add item to the DTB table
							}

							// Add supplier-specific columns to the left section
							for (let supplier of finalsupp.suplier_detail_together) {
								var newSupplier = new Table({
									width: "20vw",
									columns: new Column({
										header: [new Text({ text: `${supplier.supplier}` })]
									})
								}).addStyleClass("tableClass");

								var model = new JSONModel({ supplierid: `${supplier.id_main}` });
								newSupplier.setModel(model, 'supplier_id');

								// Populate supplier-specific table rows
								for (let i = 0; i < dtbtable.getItems().length; i++) {
									let rowid = dtbtable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
									let itemFound = supplier.rel.find(item => item.value_key == rowid);

									if (itemFound) {
										var oColumnListItem6 = new ColumnListItem({
											cells: [new Text({ text: `${itemFound.value}` })]
										});
										newSupplier.addItem(oColumnListItem6);
									} else {
										var oColumnListItem6 = new ColumnListItem({
											cells: [
												new Text({
													text: null
											
												})
											]
										});
										newSupplier.addItem(oColumnListItem6);
									}
								}
								dtbleftsidesection.addItem(newSupplier); // Add supplier-specific table to the section
							}

							// Add the DTB Packing Cost subsection
							sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSection::Itemdata").addSubSection(
								new sap.uxap.ObjectPageSubSection({
									title: "DTB Packing Cost",
									blocks: [contentContainerDTB] // Add the container as a block
								})
							);
						}

						// Call the item data section function
						itemDataSection.call(this);

						/// ITEM DATA SECTION END ///


						/// RISK ANALYSIS SECTION START ///

						// Define the risk analysis section
						async function riskanalysissection() {
							// Get references to the risk table and left-side section
							var risktable = sap.ui.getCore().byId(jQuery("[id$='parentTableriskdoc']").attr("id"));
							var riskleftsidesection = sap.ui.getCore().byId(jQuery("[id$='HboxSupplierriskdoc']").attr("id"));

							// Apply CSS classes to adjust styles
							risktable.addStyleClass("tableClass");
							risktable.setWidth("40vw");
							riskleftsidesection.addStyleClass("rightHboxClass");

							// Add the first column to the risk table with an empty header
							var btbfirstColumn = new sap.m.Column({
								width: "500px",
								header: new Text({ text: "   " })
							});
							risktable.addColumn(btbfirstColumn);

							// Define a list of risk-related fields for agreements and ratings
							const agreementsAndRatings = [
								"Development Supply Agreement (DSA) - Whether Signed? (If No: LoBA will share after DSA agreement)",
								"Tooling Agreement - Is it signed? (If applicable)",
								"Supplier Code of Conduct Declaration - Submitted? (If No: Must be signed before start of development)",
								"SRMM Score - Completed? (If Not Done: To be done before start of development)",
								"Financial Rating - Completed? (If Not Done: To be done before start of development)",
								"IPR Undertaking - Submitted? (If Not Done: To be done before start of development)"
							];

							// Add rows to the risk table based on the agreements and ratings
							for (let field of agreementsAndRatings) {
								var oColumnListItemrisk = new ColumnListItem({
									cells: [new Text({ text: `${field}`, tooltip: `${field}` })]
								});
								var modelrow = new JSONModel({ rowid: field });
								oColumnListItemrisk.setModel(modelrow, `rowid`);
								risktable.addItem(oColumnListItemrisk);
							}

							// Iterate through supplier details and create corresponding tables
							for (let supplier of finalsupp.suplier_detail_together) {
								var newSupplier = new Table({
									width: "20vw",
									columns: new Column({
										header: [
											new Text({ text: `${supplier.supplier}` })
										]
									})
								}).addStyleClass("tableClass");

								// Bind the supplier's ID to the table
								var model = new JSONModel({ supplierid: `${supplier.id_main}` });
								newSupplier.setModel(model, 'supplier_id');

								// Populate each supplier's table with data or placeholders
								for (let i = 0; i < risktable.getItems().length; i++) {
									let rowid = risktable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
									let itemFound = supplier.rel.find(item => item.value_key == rowid);

									if (itemFound) {
										// Add data row for matching fields
										var oColumnListItem6 = new ColumnListItem({
											cells: [new Text({ text: `${itemFound.value}` })]
										});
										newSupplier.addItem(oColumnListItem6);
									} else {
										// Add a placeholder row for unmatched fields
										var oColumnListItem6 = new ColumnListItem({
											cells: [
												new Text({
													text: null
												
												})
											]
										});
										newSupplier.addItem(oColumnListItem6);
									}
								}

								// Add the newly created supplier table to the left-side section
								riskleftsidesection.addItem(newSupplier);
							}

							// Add a comment box to the risk analysis section
							var contentContainerRiskcomment = new sap.m.HBox({
								items: [
									new sap.m.TextArea({
										value: "demo",
										width: "70vw",
										rows: 8
									})
								]
							});

							// Add a subsection for comments to the risk analysis section
							sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSection::Riskanalysisdocument").addSubSection(
								new sap.uxap.ObjectPageSubSection({
									visible: false,
									title: "Comment",
									blocks: [contentContainerRiskcomment] // Use the variable here
								})
							);
						}

						// Call the risk analysis section function
						riskanalysissection.call(this);

						/// RISK ANALYSIS SECTION END ///



						//Workflow
						async function approverSection() {

							let oFunction2 = this.getView().getModel().bindContext("/workflowdata(...)");

							oFunction2.setParameter("vobid", id);
							try {
								// Set parameter and execute the function
								oFunction2.setParameter("vobid", id);
								oFunction2.setParameter("status", "approverdata");
								await oFunction2.execute();
								console.log("Function executed successfully.");

								// Get the bound context
								const boundContext = oFunction2.getBoundContext();
								if (!boundContext) {
									// console.error("Bound context is null.");
									// return;
								}

								// Get the value from the bound context
								const contextValue = boundContext.getValue();
								if (!contextValue) {
									// console.error("Context value is null.");
									// return;
									workflowresp = []
								}
								else {
									var result1 = contextValue.value;
									var workflowresp = JSON.parse(result1);
									// console.log(workflowresp);
								}

								// Access the value property


							} catch (error) {
								console.error("Error executing function:", error);
							}

							var vboxworkflow = sap.ui.getCore().byId(jQuery("[id$='vboxworkflow']").attr("id"))
							// var workflowtabledoc = sap.ui.getCore().byId(jQuery("[id$='workflowtable']").attr("id"))
							// Generate a unique ID for the workflow table
							let workflowTableId = generateXmlValidId("workflowtable");

							// Create the Table with the dynamically generated ID
							var workflowtabledoc = new Table(workflowTableId, {
								mode: "MultiSelect"
							});
							vboxworkflow.addItem(workflowtabledoc);
							// Define new columns
							var column1 = new sap.m.Column({
								header: new sap.m.Label({ text: "Employee Id" })
							});

							var column2 = new sap.m.Column({
								header: new sap.m.Label({ text: "Employee Name" })
							});

							var column3 = new sap.m.Column({
								header: new sap.m.Label({ text: "Level" })
							});

							// Add new columns to the table
							workflowtabledoc.addColumn(column1);
							workflowtabledoc.addColumn(column2);
							workflowtabledoc.addColumn(column3);
							var searchehelpdatamaster = finalsupp.masterSearchHelp;


							// Loop through the workflow data and add items directly
							if (workflowresp.length > 1) {
								workflowresp.forEach(function (item) {
									var employeeIdComboBox = new sap.m.ComboBox({
										value: item.employee_id,
										width: "100%",
										editable: isVisible,
										showSecondaryValues: true,
										change: function (oEvent) {
											debugger
											var employeeIdComboBox = oEvent.getSource();
											var selectedKey = employeeIdComboBox.getSelectedKey(); // Get the selected key
											var selectedValue = employeeIdComboBox.getValue(); // Get the current value

											// Check if the selected value is from the list of available options
											var isValidSelection = employeeIdComboBox.getItems().some(function (listItem) {
												return listItem.getText() === selectedValue;
											});

											if (isValidSelection) {
												employeeIdComboBox.setTooltip(selectedValue); // Update the tooltip with the selected value
												oEvent.oSource.setValueState(sap.ui.core.ValueState.None);

												// Get the additional text (employee name) based on the selected key
												var selectedItem = employeeIdComboBox.getItems().find(function (item) {
													return item.getKey() === selectedKey;
												});

												if (selectedItem) {
													// Assuming you have a reference to the input field for employee_name
													employeeNameInput.setValue(selectedItem.getAdditionalText()); // Update employee name input
												}
											} else {
												oEvent.oSource.setValueStateText("Invalid selection. Please select a valid option from the dropdown.");
												oEvent.oSource.setValueState("Error");
												employeeIdComboBox.setValue(null); // Reset the value if the input is invalid
												employeeIdComboBox.setTooltip(null); // Reset the tooltip
											}
										},
										items: searchehelpdatamaster.map(function (emp) {
											return new sap.ui.core.ListItem({
												key: emp.employee_id,
												text: emp.employee_id,
												additionalText: emp.employee_name
											}); // Adjust based on your data structure
										})
									});
									var levelComboBox = new sap.m.ComboBox({
										value: item.level,
										width: "100%",
										editable: isVisible,
										change: function (oEvent) {
											var oComboBox = oEvent.getSource();
											var selectedKey = oComboBox.getSelectedKey();  // Get the selected key
											var selectedValue = oComboBox.getValue();  // Get the current value
											// Check if the selected value is from the list of available options
											var isValidSelection = oComboBox.getItems().some(function (item) {
												return item.getText() === selectedValue;
											});
											if (isValidSelection) {
												oComboBox.setTooltip(selectedValue); // Update the tooltip with the selected value
												oEvent.oSource.setValueState(sap.ui.core.ValueState.None);
											} else {
												oEvent.oSource.setValueStateText("Invalid selection. Please select a valid option from the dropdown.");
												oEvent.oSource.setValueState("Error");
												oComboBox.setValue(null); // Reset the value if the input is invalid
												oComboBox.setTooltip(null); // Reset the tooltip
											}

										}
										,
										items: [
											new sap.ui.core.ListItem({ key: "R1", text: "R1" }),
											new sap.ui.core.ListItem({ key: "R2", text: "R2" }),
											new sap.ui.core.ListItem({ key: "R3", text: "R3" }),
											new sap.ui.core.ListItem({ key: "R4", text: "R4" }),
											new sap.ui.core.ListItem({ key: "R5", text: "R5" })
										]
									});

									if (item.level !== "0") {
										// Create a reference to the employee name input field
										var employeeNameInput = new sap.m.Input({ value: item.employee_name, editable: isVisible });

										var listItem = new sap.m.ColumnListItem({
											cells: [
												employeeIdComboBox,
												employeeNameInput, // Use the reference here
												levelComboBox// For Level column
											]
										});

										// Add the created item to the table
										workflowtabledoc.addItem(listItem);
									}
								});
							}
							// Generate a unique ID for the Create button
							let createButtonId = generateXmlValidId("createapprover");
							// Create the Create button
							var oCreateButton = new Button({
								text: "Create",
								id: createButtonId,
								enabled: isVisible,
								press: function (oEvent) {

									// Check the current number of rows in the workflow table
									var currentItemCount = workflowtabledoc.getItems().length;

									// Define the maximum number of rows allowed (for example, 5)
									var maxRowsAllowed = 5;

									// Prevent creation if the maximum is reached
									if (currentItemCount >= maxRowsAllowed) {
										sap.m.MessageToast.show("Maximum " + maxRowsAllowed + " approvers allowed.");
										return; // Exit the function if the limit is reached
									}
									var employeeNameInput = new sap.m.Input({ value: "" });

									// Create ComboBox for Employee ID
									var employeeIdComboBox = new sap.m.ComboBox({
										width: "100%",
										showSecondaryValues: true,
										items: searchehelpdatamaster.map(function (emp) {
											return new sap.ui.core.ListItem({
												key: emp.employee_id,
												text: emp.employee_id,
												additionalText: emp.employee_name
											});
										}),
										change: function (oEvent) {
											debugger
											var employeeIdComboBox = oEvent.getSource();
											var selectedKey = employeeIdComboBox.getSelectedKey(); // Get the selected key
											var selectedValue = employeeIdComboBox.getValue(); // Get the current value

											// Check if the selected value is from the list of available options
											var isValidSelection = employeeIdComboBox.getItems().some(function (listItem) {
												return listItem.getText() === selectedValue;
											});

											if (isValidSelection) {
												employeeIdComboBox.setTooltip(selectedValue); // Update the tooltip with the selected value
												oEvent.oSource.setValueState(sap.ui.core.ValueState.None);

												// Get the additional text (employee name) based on the selected key
												var selectedItem = employeeIdComboBox.getItems().find(function (item) {
													return item.getKey() === selectedKey;
												});

												if (selectedItem) {
													// Assuming you have a reference to the input field for employee_name
													employeeNameInput.setValue(selectedItem.getAdditionalText()); // Update employee name input
												}
											} else {
												oEvent.oSource.setValueStateText("Invalid selection. Please select a valid option from the dropdown.");
												oEvent.oSource.setValueState("Error");
												employeeIdComboBox.setValue(null); // Reset the value if the input is invalid
												employeeIdComboBox.setTooltip(null); // Reset the tooltip
											}
										},
									});

									// Create ComboBox for Level
									var levelComboBox = new sap.m.ComboBox({
										width: "100%",
										items: [
											new sap.ui.core.ListItem({ key: "R1", text: "R1" }),
											new sap.ui.core.ListItem({ key: "R2", text: "R2" }),
											new sap.ui.core.ListItem({ key: "R3", text: "R3" }),
											new sap.ui.core.ListItem({ key: "R4", text: "R4" }),
											new sap.ui.core.ListItem({ key: "R5", text: "R5" })
										],
										change: function (oEvent) {
											var oComboBox = oEvent.getSource();
											var selectedKey = oComboBox.getSelectedKey();
											var selectedValue = oComboBox.getValue();
											var isValidSelection = oComboBox.getItems().some(function (item) {
												return item.getText() === selectedValue;
											});
											if (isValidSelection) {
												oComboBox.setTooltip(selectedValue);
												oEvent.oSource.setValueState(sap.ui.core.ValueState.None);
											} else {
												oEvent.oSource.setValueStateText("Invalid selection. Please select a valid option from the dropdown.");
												oEvent.oSource.setValueState("Error");
												oComboBox.setValue(null);
												oComboBox.setTooltip(null);
											}
										}
									});

									// Create a new row in the table with the new ComboBoxes
									var newRow = new sap.m.ColumnListItem({
										cells: [
											employeeIdComboBox,
											employeeNameInput, // Placeholder for Employee Name
											levelComboBox
										]
									});

									workflowtabledoc.addItem(newRow);
									MessageToast.show("New row added.");
								}
							});
							oCreateButton.addStyleClass("paddingforcreate")

							// Generate a unique ID for the Delete button
							let deleteButtonId = generateXmlValidId("deleteapprover");

							// Create the Delete button
							var oDeleteButton = new Button({
								text: "Delete",
								id: deleteButtonId,
								enabled: isVisible,
								press: function (oEvent) {
									debugger
									var selectedItems = workflowtabledoc.getSelectedItems();
									if (selectedItems.length > 0) {
										selectedItems.forEach(function (item) {
											workflowtabledoc.removeItem(item);
										});
										MessageToast.show("Selected Approvers deleted.");
										workflowtabledoc.removeSelections()
									} else {
										MessageToast.show("Please select at least one Approver to delete.");
									}
								}
							});
							var hboxworkflow = new sap.m.HBox({
								justifyContent: "End", // Align items to the end (right side)
								width: "100%"
							});

							hboxworkflow.addItem(oCreateButton);
							hboxworkflow.addItem(oDeleteButton);

							vboxworkflow.addItem(hboxworkflow);
							vboxworkflow.addItem(workflowtabledoc);
						}
						approverSection.call(this);







						//Workflow End



















						async function visibilitySet() {
							var teamrecommendationdoccomment = sap.ui.getCore().byId(jQuery(`[id$='teamrecommendationdoccomment']`).attr("id"));
							teamrecommendationdoccomment.setEditable(isVisible);
							var decisionAndMomFormdoccomment = sap.ui.getCore().byId(jQuery(`[id$='decisionAndMomFormdoccomment']`).attr("id"));
							decisionAndMomFormdoccomment.setEditable(isVisible);


							var oPageTitle = sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage").getContent()[0].getHeaderTitle();
							oPageTitle.destroyContent();
							oPageTitle.addContent(new sap.m.Title({ text: "{sequentialvobid}", titleStyle: "H1" }));

							// Retrieve the IDs of the file uploader button and footer bar
							var fileUploaderButtonId = jQuery("[id$='fileUploaderbutton']").attr("id");
							var footerBarId = "vendoronboarddocument::vobDocumentObjectPage--fe::FooterBar::_fc";
							var oUploadSetId = "vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Uploadset--uploadtest";

							// Set visibility of file uploader button and footer bar based on the `isVisible` condition
							if (sap.ui.getCore().byId(fileUploaderButtonId) && sap.ui.getCore().byId(footerBarId)) {
								sap.ui.getCore().byId(fileUploaderButtonId).setVisible(isVisible); // Update visibility of file uploader button
								sap.ui.getCore().byId(footerBarId).setVisible(isVisible); // Update visibility of footer bar
							}

							// Retrieve the UploadSet control using its ID
							const oUploadSet = sap.ui.getCore().byId(
								"vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Uploadset--uploadtest"
							);

							// Define the filter using `vob_id` to filter items in the UploadSet
							const vobid = id; // Replace `id` with the dynamic value representing `vobid`
							const oFilter = new sap.ui.model.Filter("vob_id", sap.ui.model.FilterOperator.EQ, vobid);
							oUploadSet.getBinding("items").filter([oFilter]); // Apply the filter to the binding of the UploadSet

							// Attach a section change event listener to the ObjectPage
							sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::ObjectPage").attachSectionChange(function (oEvent) {
								debugger; // Debugger statement for troubleshooting during section change

								// Retrieve the visibility model bound to the UploadSet
								const myModel = sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Uploadset--uploadtest").getModel("myVisModel");

								let visibleFlag; // Variable to hold the visibility flag

								if (myModel) {
									// Retrieve the `visibilityFlag` property from the model
									let visibilityFlagValue = myModel.getProperty("/visibilityFlag");
									visibleFlag = visibilityFlagValue; // Assign the value to the visibility flag
								} else {
									// Fallback to the `isVisible` variable if the model is not available
									visibleFlag = isVisible; // Ensure `isVisible` is boolean
								}

								// Check if `oUploadSetId` is defined
								if (oUploadSetId) {
									// Retrieve the UploadSet using its ID
									let oUploadSet = sap.ui.getCore().byId(oUploadSetId);
									if (oUploadSet) {
										// Update the visibility of the remove action for each item in the UploadSet
										oUploadSet.getItems().forEach(item => {
											item.setVisibleRemove(visibleFlag); // Set visibility based on the flag
										});
									} else {
										// Log a warning if the UploadSet is not found
										console.warn("UploadSet not found for ID:", oUploadSetId);
									}
								} else {
									// Log an error if `oUploadSetId` is not defined
									console.error("oUploadSetId is not defined.");
								}
							});
						}

						// Call the visibilitySet function
						visibilitySet.call(this);



						oBusyDialog.close();




					}
				}


			}
		});
	});
