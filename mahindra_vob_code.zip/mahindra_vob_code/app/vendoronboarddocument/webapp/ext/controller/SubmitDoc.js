sap.ui.define([
    "sap/m/MessageToast",
    "sap/m/library",
], function (MessageToast, mobileLibrary) {
    'use strict';
    var DialogType = mobileLibrary.DialogType;
    return {
        submitDoc: function (oEvent) {
            var dialogId = sap.ui.core.Fragment.createId("dialogid");
            var labelId = sap.ui.core.Fragment.createId("labelid");
            var label = new sap.m.Label(labelId, {
                text: "Are you sure you want to save and send for approval?",
            })
            label.addStyleClass("labeldialogsave")
            this.oDialog = new sap.m.Dialog(dialogId, {
                title: "Submit",
                type: DialogType.Message,
                content: [label],
                beginButton: new sap.m.Button({
                    text: "OK",
                    press: async function (oBindingContext, oEvent) {
                        var busy = new sap.m.BusyDialog({ text: "Submitting Please Wait..!" });
                    
                        try {
                            busy.open();
                            
                            // Inner function to extract document ID from URL
                            function extractIdFromUrl(url) {
                                const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                                const matches = url.match(regex);
                                return matches ? matches[1] : null;
                            }
                    
                            async function getWorkflowData() {
                                const worflowTable = sap.ui.getCore().byId(jQuery("[id$='workflowtable']").attr("id"));
                                const items = worflowTable.getItems();
                                const cellValuesArray = [];
                            
                                for (let item of items) {
                                    const cells = item.getCells();
                                    if (cells.length >= 3) {
                                        const employeeId = cells[0].getValue();
                                        const employeeName = cells[1].getValue();
                                        const level = cells[2].getValue();
                            
                                        // Validation checks
                                        if (!employeeId) {
                                            return { isValid: false, errorMessage: "Employee ID cannot be empty." };
                                        }
                                        if (!level) {
                                            return { isValid: false, errorMessage: "Level cannot be empty." };
                                        }
                            
                                        cellValuesArray.push({ employeeId, employeeName, level });
                                    }
                                }
                            
                                // Further validations
                                if (cellValuesArray.length < 2) return { isValid: false, errorMessage: "Minimum Two Approvers Needed" };
                            
                                const employeeIds = cellValuesArray.map(entry => entry.employeeId);
                                const uniqueEmployeeIds = [...new Set(employeeIds)];
                                if (employeeIds.length !== uniqueEmployeeIds.length) return { isValid: false, errorMessage: "Employee ID already assigned to another level" };
                            
                                const levels = cellValuesArray.map(entry => entry.level);
                                const uniqueLevels = [...new Set(levels)];
                                if (levels.length !== uniqueLevels.length) return { isValid: false, errorMessage: "Level values must be unique." };
                                const validLevels = ["R1", "R2", "R3", "R4", "R5"];
                                const highestLevelIndex = Math.max(...uniqueLevels.map(level => validLevels.indexOf(level)));
                                for (let i = 0; i <= highestLevelIndex; i++) {
                                    if (!uniqueLevels.includes(validLevels[i])) {
                                        const missingLevelMessage = `Please include all levels up to ${validLevels[highestLevelIndex]} before saving.`;
                                        return { isValid: false, errorMessage: missingLevelMessage};
                                    }
                                }
                                return { isValid: true, data: cellValuesArray };


                                
                            }
                            
                    
                            // Inner function to save workflow data
                            async function saveWorkflowData(id, workflowData) {
                                let oFunction = this._view.getModel().bindContext("/documentscreenfunc(...)");
                                const statusval = JSON.stringify({ id: id, status: "addworkflowdata", workflowdata: workflowData });
                                oFunction.setParameter("status", statusval);
                                await oFunction.execute();
                            }
                    
                            // Inner function to retrieve and format comments
                            function getComments() {
                                const teamRecommendation = sap.ui.getCore().byId(jQuery("[id$='teamrecommendationdoccomment']").attr("id")).getValue();
                                const decisionAndMomFormComment = sap.ui.getCore().byId(jQuery("[id$='decisionAndMomFormdoccomment']").attr("id")).getValue();
                                const allComments = [];
                                if (teamRecommendation) allComments.push(`Team Recommendation with Rationale: ${teamRecommendation}`);
                                if (decisionAndMomFormComment) allComments.push(`Decision and MOM of Forum: ${decisionAndMomFormComment}`);
                                return allComments.join("\n");
                            }
                    
                            // Inner function to save comments
                            async function saveComments(id, comments) {
                                let oFunctionComment = this.getModel().bindContext("/documentscreenfunc(...)");
                                const statusval = JSON.stringify({
                                    id: id,
                                    status: "screen4commentview",
                                    comment_value: comments
                                });
                                oFunctionComment.setParameter("status", statusval);
                                await oFunctionComment.execute();
                            }
                    
                            // Inner function to trigger workflow
                            async function triggerWorkflow(id, comments) {
                                let oFunction = this.getModel().bindContext("/documentscreenfunc(...)");
                                const statusval = JSON.stringify({
                                    id: id,
                                    status: "triggerworkflow",
                                    submitteduser: new sap.ushell.services.UserInfo().getEmail(),
                                    submittedusername: new sap.ushell.services.UserInfo().getFullName(),
                                    comment_value: comments
                                });
                                oFunction.setParameter("status", statusval);
                                await oFunction.execute();
                            }
                    
                            // Inner function to update UI after submission
                            function updateUIAfterSubmission() {
                                this.oDialog.close();
                                sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::FooterBar::_fc").setVisible(false);
                                sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Uploadset--fileUploaderbutton").setVisible(false);
                    
                                visibility_remove.call(this);
                            }
                    
                            // Inner function to remove visibility for certain UI elements
                            function visibility_remove() {
                                var oUploadSetId = "vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Uploadset--uploadtest";
                                let oUploadSet = sap.ui.getCore().byId(oUploadSetId);
                                if (oUploadSet) {
                                    oUploadSet.getItems().forEach(item => item.setVisibleRemove(false));
                                }
                    
                                var commentFragment = sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Commentfragment");
                                var content_frag = commentFragment.getBlocks()[0].getContent();
                                content_frag.getItems()[1].getItems()[1].setEditable(false);
                                content_frag.getItems()[2].getItems()[1].setEditable(false);
                    
                                var table_workflow = sap.ui.getCore().byId("vendoronboarddocument::vobDocumentObjectPage--fe::CustomSubSection::Workflow")
                                    .getBlocks()[0].getContent();
                                table_workflow.getItems()[1].setMode("None");
                    
                                table_workflow.getItems()[1].getItems().forEach(function (item) {
                                    item.getCells().forEach(function (cell) {
                                        cell.setEditable(false);
                                    });
                                });
                    
                                sap.ui.getCore().byId(jQuery("[id$='createapprover']").attr("id")).setEnabled(false);
                                sap.ui.getCore().byId(jQuery("[id$='deleteapprover']").attr("id")).setEnabled(false);
                            }
                    
                            // Main execution starts here
                            debugger
                            const id = extractIdFromUrl(window.location.hash);
                            const workflowData = await getWorkflowData();
                            this.oDialog.close();
                            if (!workflowData.isValid) throw new Error(workflowData.errorMessage);
                    
                            await saveWorkflowData.call(this, id, workflowData.data);
                    
                            const comments = getComments();
                            await saveComments.call(this,id, comments);
                    
                            await triggerWorkflow.call(this,id, comments);
                         
                    
                            updateUIAfterSubmission.call(this);
                    
                            sap.m.MessageToast.show("Saved successfully and sent for approval!");
                    
                        } catch (error) {
                            sap.m.MessageToast.show(error.message || "An error occurred while submitting.");
                        } finally {
                            busy.close();
                        }
                    }.bind(this)     
                }),
                endButton: new sap.m.Button({
                    text: "Close",
                    press: function () {
                        this.oDialog.close();
                    }.bind(this)
                })

            });
            this.oDialog.open();
        }
    };
});
