sap.ui.define([
    "sap/m/MessageToast"
], function (MessageToast) {
    'use strict';

    return {
        save: async function (oEvent) {

            var busy = new sap.m.BusyDialog({ text: "Please Wait..!" });
            busy.open();
            try {
                debugger
                var url = window.location.hash;
                const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                const matches = url.match(regex);
                var id = matches[1];

                var worflowtabledoc = sap.ui.getCore().byId(jQuery("[id$='workflowtable']").attr("id"))
                // Initialize an array to hold the cell values
                var cellValuesArrayworkflow = [];

                // Get all items in the workflow table
                var items = worflowtabledoc.getItems();

                // Loop through each item
                items.forEach(function (item) {
                    // Assuming the item has at least three cells
                    var cells = item.getCells();

                    // Check if the number of cells is as expected (for safety)
                    if (cells.length >= 3) {
                        const employeeId = cells[0].getValue(); // Employee ID
                        const employeeName = cells[1].getValue(); // Employee Name
                        const level = cells[2].getValue(); // Level

                        // Ensure Employee ID is always present
                        if (!employeeId) {
                            //     sap.m.MessageToast.show("Employee ID cannot be empty.");
                            //     return; // Stop execution if Employee ID is missing
                            throw new Error("Employee ID cannot be empty.");

                        }
                        // Ensure Level is always present
                        if (!level) {
                            throw new Error("Level cannot be empty.");
                        }
                        // Push the values of the first three cells (you can adjust this as needed)
                        cellValuesArrayworkflow.push({
                            employeeId: cells[0].getValue(), // Employee ID from the first cell
                            employeeName: cells[1].getValue(), // Employee Name from the second cell
                            level: cells[2].getValue() // Level from the third cell (ComboBox)
                        });
                    }
                });
                if (cellValuesArrayworkflow.length < 2) {
                    // sap.m.MessageToast.show("Please add at least two entries before saving.");
                    // return; // Exit the function if the condition is not met
                    throw new Error("Minimum Two Approvers Needed");
                }

                // Validate uniqueness of employee IDs
                const employeeIds = cellValuesArrayworkflow.map(entry => entry.employeeId);
                const uniqueEmployeeIds = [...new Set(employeeIds)]; // Remove duplicates
                if (employeeIds.length !== uniqueEmployeeIds.length) {
                    throw new Error("Employee ID already assigned to another level"); // Throw error if IDs are not unique
                }
                // Validate uniqueness of level values
                const levels = cellValuesArrayworkflow.map(entry => entry.level);
                const uniqueLevels = [...new Set(levels)]; // Remove duplicates
                if (levels.length !== uniqueLevels.length) {
                    throw new Error("Level values must be unique."); // Throw error if levels are not unique
                }

                const validLevels = ["R1", "R2", "R3", "R4", "R5"];
                const highestLevelIndex = Math.max(...uniqueLevels.map(level => validLevels.indexOf(level)));

                // Check if levels are in valid sequential order
                for (let i = 0; i <= highestLevelIndex; i++) {
                    if (!uniqueLevels.includes(validLevels[i])) {
                        sap.m.MessageToast.show(`Please include all levels up to ${validLevels[highestLevelIndex]} before saving.`);
                        throw new Error(`Please include all levels up to ${validLevels[highestLevelIndex]} before saving.`); // Throw error if the condition is not met // Exit if the condition is not met
                    }
                }

                // Now cellValuesArray contains the values from the cells of each item
                console.log(cellValuesArrayworkflow);
                let oFunction1 = this._view.getModel().bindContext("/documentscreenfunc(...)");
                const statusval1 = JSON.stringify({ id: id, status: "addworkflowdata", workflowdata: cellValuesArrayworkflow })
                oFunction1.setParameter("status", statusval1)
                await oFunction1.execute()

                //for comments
                var teamdecisionforum = sap.ui.getCore().byId(jQuery("[id$='teamrecommendationdoccomment']").attr("id")).getValue()
                var decisionAndMomFormdoccomment = sap.ui.getCore().byId(jQuery("[id$='decisionAndMomFormdoccomment']").attr("id")).getValue();
                var allComments = [];


                if (teamdecisionforum) {
                    allComments.push(`Team Recommendation with Rationale: ${teamdecisionforum}`);
                }
                if (decisionAndMomFormdoccomment) {
                    allComments.push(`Decision and MOM of Forum: ${decisionAndMomFormdoccomment}`);
                }

                var url = window.location.hash;
                // if (teamdecisionforum || decisionAndMomFormdoccomment) {
                //     let oFunctioncomment = this.getModel().bindContext("/commentadd(...)");
                //     var statusval3 = JSON.stringify({ id: id, comment_value: allComments, status: "screen4commentview" })
                //     oFunctioncomment.setParameter("status", statusval3)
                //     await oFunctioncomment.execute()
                // }

           

                // }

                sap.m.MessageToast.show("Saved")
            } catch (error) {
                sap.m.MessageToast.show(error.message);
            }
            finally {
                busy.close();

            }
        }
    };
});
