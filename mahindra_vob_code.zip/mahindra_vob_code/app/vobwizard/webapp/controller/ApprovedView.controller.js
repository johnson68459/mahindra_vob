sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/m/MessageBox",
        'sap/m/HBox',
        "sap/m/Table",
        "sap/m/Column",
        "sap/m/ColumnListItem",
        "sap/m/Text",
        "sap/m/Input",
        "sap/m/Button",
        "sap/m/Dialog",
        "sap/m/CheckBox",
        "sap/m/MessageToast",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Icon",
        "sap/m/library"
    ],
    function (BaseController, Filter, FilterOperator, MessageBox, HBox, Table, Column, ColumnListItem, Text, Input, Button, Dialog, CheckBox, MessageToast, JSONModel, Icon, mobileLibrary) {
        "use strict";

        var oDataApproval;

        async function loadImages(supplier, part, vobId) {

            const busyDialog = new sap.m.BusyDialog({ text: "Loading images..." });

            const updateImageContainers = async (filesArray) => {
                // Open the busy dialog before starting the process
                busyDialog.open();

                try {
                    // Filter files array just once
                    const supplierFiles = filesArray.filter(file => file.fileName.includes("/Supplier/"));
                    const partFiles = filesArray.filter(file => file.fileName.includes("/Parts/"));

                    // Parallel updates to reduce UI rendering time
                    await Promise.all([
                        updateContainer(supplierFiles, supplier, "No Supplier Data Found"),
                        updateContainer(partFiles, part, "No Part Data Found")
                    ]);

                } finally {
                    busyDialog.close(); // Close the busy dialog after loading all images
                }
            };

            const updateContainer = async (files, container, emptyMessage) => {
                // Cache items array to add all at once
                let items = [];
                if (files.length === 0) {
                    items.push(new sap.m.MessageStrip({ text: emptyMessage, type: "Information", showIcon: true, showCloseButton: false }));
                } else {
                    // Create image items and add them to items array
                    const promises = files.map(file => createImageItem.call(this, file));
                    const imageItems = await Promise.all(promises);
                    items = items.concat(imageItems);
                }

                // Update container with accumulated items
                container.removeAllItems();
                items.forEach(item => container.addItem(item));
            };

            const createImageItem = async (file) => {
                const fileName = file.fileName;
                const parts = fileName.split('/');
                const newFolder = parts[parts.length - 2];
                const fileBaseName = parts[parts.length - 1];
                const result = `${newFolder} (${fileBaseName})`;

                return new sap.m.VBox({
                    items: [
                        new sap.m.Image({
                            src: file.url,
                            width: "100%",
                            height: "auto",
                        }),
                        new sap.m.HBox({
                            items: [
                                new sap.ui.core.Icon({
                                    src: 'sap-icon://circle-task',
                                    visible: false,
                                    press: function (oEvent) {
                                        const oIcon = oEvent.getSource();
                                        oIcon.setSrc(oIcon.getSrc() === 'sap-icon://circle-task' ? "sap-icon://bo-strategy-management" : "sap-icon://circle-task");
                                    }
                                }),
                                new sap.m.Title({
                                    text: result,
                                    textAlign: "Center",
                                    wrapping: true,
                                    width: "100%"
                                })
                            ]
                        })
                    ],
                    alignItems: "Center",
                    justifyContent: "Center",
                    width: "100%"
                }).addStyleClass("eachImageelement");
            };

            // Bind and execute the function to fetch files
            let oFunction = this.getView().getModel().bindContext("/getFilesListVOBSupplierPart(...)");
            oFunction.setParameter("fileName", vobId);
            await oFunction.execute();

            // Get the array of files
            const filesArray = oFunction.getBoundContext().getValue()?.value ?? '';

            // Check if filesArray is empty or contains errors
            if (!filesArray || filesArray.length === 0 || typeof filesArray[0] === 'string' && filesArray[0].includes("Failed to")) {
                // Show "No data found" message strips if filesArray is empty or contains errors
                supplier.removeAllItems();
                part.removeAllItems();
                supplier.addItem(new sap.m.MessageStrip({
                    text: "No Supplier Data Found",
                    type: "Information",
                    showIcon: true,
                    showCloseButton: false
                }));
                part.addItem(new sap.m.MessageStrip({
                    text: "No Part Data Found",
                    type: "Information",
                    showIcon: true,
                    showCloseButton: false
                }));
            } else {
                // Update image containers in parallel if files are found
                await updateImageContainers(filesArray);
            }
        }

        async function loadImagespdf(supplier, part, vobId) {

            const busyDialog = new sap.m.BusyDialog({
                text: "Preparing your PDF. This might take a moment..."
            });

            const updateImageContainers = async (filesArray) => {
                // Open the busy dialog before starting the process
                busyDialog.open();

                try {
                    // Filter files array just once
                    const supplierFiles = filesArray.filter(file => file.fileName.includes("/Supplier/"));
                    const partFiles = filesArray.filter(file => file.fileName.includes("/Parts/"));

                    // Parallel updates to reduce UI rendering time
                    await Promise.all([
                        updateContainer(supplierFiles, supplier, "No Supplier Data Found"),
                        updateContainer(partFiles, part, "No Part Data Found")
                    ]);

                } finally {
                    busyDialog.close(); // Close the busy dialog after loading all images
                }
            };

            const updateContainer = async (files, container, emptyMessage) => {
                // Cache items array to add all at once
                let items = [];
                if (files.length === 0) {
                    items.push(new sap.m.MessageStrip({ text: emptyMessage, type: "Information", showIcon: true, showCloseButton: false }));
                } else {
                    // Create image items and add them to items array
                    const promises = files.map(file => createImageItem.call(this, file));
                    const imageItems = await Promise.all(promises);
                    items = items.concat(imageItems);
                }

                // Update container with accumulated items
                container.removeAllItems();
                items.forEach(item => container.addItem(item));
            };

            const createImageItem = async (file) => {
                const fileName = file.fileName;
                const parts = fileName.split('/');
                const newFolder = parts[parts.length - 2];
                const fileBaseName = parts[parts.length - 1];
                const result = `${newFolder} (${fileBaseName})`;

                return new sap.m.VBox({
                    items: [
                        new sap.m.Image({
                            src: `data:image/jpeg;base64,${file.content}`,
                            width: "100%",
                            height: "auto",
                        }),
                        new sap.m.HBox({
                            items: [
                                new sap.ui.core.Icon({
                                    src: 'sap-icon://circle-task',
                                    visible: false,
                                    press: function (oEvent) {
                                        const oIcon = oEvent.getSource();
                                        oIcon.setSrc(oIcon.getSrc() === 'sap-icon://circle-task' ? "sap-icon://bo-strategy-management" : "sap-icon://circle-task");
                                    }
                                }),
                                new sap.m.Title({
                                    text: result,
                                    textAlign: "Center",
                                    wrapping: true,
                                    width: "100%"
                                })
                            ]
                        })
                    ],
                    alignItems: "Center",
                    justifyContent: "Center",
                    width: "100%"
                }).addStyleClass("eachImageelement");
            };

            busyDialog.open();

            // Bind and execute the function to fetch files
            let oFunction = this.getView().getModel().bindContext("/getFilesListVOBSupplierPartPdf(...)");
            oFunction.setParameter("fileName", vobId);
            await oFunction.execute();

            // Get the array of files
            const filesArray = oFunction.getBoundContext().getValue()?.value ?? '';

            // Check if filesArray is empty or contains errors
            if (!filesArray || filesArray.length === 0 || typeof filesArray[0] === 'string' && filesArray[0].includes("Failed to")) {
                // Show "No data found" message strips if filesArray is empty or contains errors
                supplier.removeAllItems();
                part.removeAllItems();
                supplier.addItem(new sap.m.MessageStrip({
                    text: "No Supplier Data Found",
                    type: "Information",
                    showIcon: true,
                    showCloseButton: false
                }));
                part.addItem(new sap.m.MessageStrip({
                    text: "No Part Data Found",
                    type: "Information",
                    showIcon: true,
                    showCloseButton: false
                }));
                busyDialog.close()
            } else {
                // Update image containers in parallel if files are found
                await updateImageContainers(filesArray);
            }
        }

        return BaseController.extend("ApprovedView.controller.ApprovedView", {
            onInit: function () {
                debugger

            },
            onBeforeRendering: async function (oEvent) {
                const oBusyDialog = new sap.m.BusyDialog({
                    text: "Preparing your data, please hold on..."
                });
                try {
                    oBusyDialog.open();

                    var baseurl = this.getOwnerComponent().getManifestObject()._oBaseUri._string;
                    // var baseurl = "/";

                    var url = window.location.hash;
                    const regex = /vobApproval\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                    const matches = url.match(regex);
                    var approvalvobid = matches ? matches[1] : null;

                    // Validate that approvalvobid exists
                    if (!approvalvobid) {
                        throw new Error("VOB ID is missing or invalid.");
                    }

                    // Wrap the AJAX call in a Promise to ensure it completes before proceeding
                    const dataResponse = await new Promise((resolve, reject) => {
                        $.ajax({
                            url: baseurl + `odata/v4/vob/vobMain?$filter=id eq ${approvalvobid}&$expand=vob_yoy,vob_suplier($expand=*),vob_comments,vob_files,vob_to_workflow_history`,
                            method: 'GET',
                            dataType: "json",
                            success: resolve, // Resolve the Promise on success
                            error: reject     // Reject the Promise on error
                        });
                    });

                    // Process the data as needed
                    let oData = dataResponse.value[0];
                    console.log('Success:', dataResponse);
                    oDataApproval = oData

                    // Format createdAt if it exists
                    if (oData.createdAt) {
                        const date = new Date(oData.createdAt);
                        const options = {
                            timeZone: "Asia/Kolkata",
                            year: 'numeric',
                            month: '2-digit',
                            day: '2-digit',
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                            hour12: true
                        };
                        oData.createdAt = date.toLocaleString('en-IN', options);
                    }

                    var mainHBox = this.byId("mainHBox");

                    // Create a new JSON model and set the processed data to it
                    const oModel = new sap.ui.model.json.JSONModel();
                    oModel.setData(oData);

                    // Set the model to the ObjectPageLayout view component with the name "oCapData"
                    this.byId("ObjectPageLayoutApproval").setModel(oModel, "oCapData");

                    // Set the mode of the uploadSet to "None"
                    this.byId("uploadSet").setMode("None");

                    // Set financial year information
                    let oSelectedYear = oData.selected_year; // Assume oData.selected_year is 2023
                    let oFY1 = this.byId("financial_year_one");
                    let oFY2 = this.byId("financial_year_two");
                    let oFY3 = this.byId("financial_year_three");

                    // Set the financial years based on the selected year
                    oFY1.setText(`Financial Year ${oSelectedYear}`); // FY1 = Financial Year 2023
                    oFY2.setText(`Financial Year ${oSelectedYear + 1}`); // FY2 = Financial Year 2024
                    oFY3.setText(`Financial Year ${oSelectedYear + 2}`); // FY3 = Financial Year 2025

                    //Cashflow section
                    var id = matches[1];
                    // var id = '70ac0c95-4022-4da3-b6e6-4aea987d03f7'
                    let oFunction1 = this.getView().getModel().bindContext("/documentscreenfunc(...)");
                    var statusval1 = JSON.stringify({ id: id, status: "getvendordetails" })
                    oFunction1.setParameter("status", statusval1)
                    await oFunction1.execute();
                    var result1 = oFunction1.getBoundContext().getValue().value;
                    var finalsupp = JSON.parse(result1);

                    var fields = [
                        "Total Landed Investment - Settled (Rs. lacs)",
                        "Total Buying value (Rs. Lac) 1st 12months",
                        "Sourcing Partner commission to be paid ( Rs. Lac) 1st 12 months",
                        "Sourcing Partner commission to be paid (Rs. Lac)  2nd + 3rd Year",
                        "YOY Reduction for 3 yrs (After SOP + 1 year) - If Any",
                        "FX Base Rate",
                        "Inco Terms",
                        "Payment Terms",
                        "Transport Cost"
                    ]
                    var mainVbox = mainHBox;

                    //

                    var mainVbox = mainHBox;
                    mainVbox.getItems()[0].setWidth("40vw")
                    //breakpoint
                    mainVbox.getItems()[0].getItems()[0].destroyColumns();
                    mainVbox.getItems()[0].getItems()[0].destroyItems();
                    mainVbox.getItems()[1].destroyItems();

                    var oHboxSupplier = mainVbox.getItems()[1];
                    var otable = mainVbox.getItems()[0].getItems()[0];

                    var firstColumn = new sap.m.Column({
                        // width: "500px",
                        header: new HBox({
                            // alignItems: "Center",
                            justifyContent: "SpaceBetween",
                            items: [
                                new Text({ text: "MGSP Part No", width: "8vw", tooltip: "MGSP Part No" }),
                                new Text({ text: "MGSP Supplier Name", width: "8vw", tooltip: "MGSP Supplier Name" }),
                                new Text({ text: "MGSP Vendor Inco Term", width: "8vw", tooltip: "MGSP Vendor Inco Term" }),
                                new Text({ text: "Existing MGSP PO Price", width: "8vw", tooltip: "Existing MGSP PO Price" }),
                                new Text({ text: "Target Price", width: "8vw", tooltip: "Target Price" })
                                // new Text({ text: "IsApproved", width: "8vw", tooltip: "IsApproved" })

                            ]
                        }).addStyleClass("hboxHeaderClass"),
                        // styleClass: "colunm1style"
                    });
                    otable.addColumn(firstColumn);
                    var firstItem = new ColumnListItem({
                        cells: [
                            new Text({ text: `Remarks`, tooltip: `Remarks` }).addStyleClass("InputToTextClass"),
                        ]
                    })
                    var modelrowfisrtcol = new JSONModel({
                        rowid: `Remarks`
                    });
                    firstItem.setModel(modelrowfisrtcol, `rowid`);
                    otable.addItem(firstItem);
                    for (let i = 0; i < finalsupp.yoy_details.length; i++) {
                        let partdetails = finalsupp.yoy_details[i];
                        var oColumnListItem = new ColumnListItem({
                            cells: [
                                new HBox({
                                    justifyContent: "SpaceBetween",
                                    items: [
                                        new Text({ text: partdetails.mgsp_part_nos, width: "8vw", tooltip: partdetails.mgsp_part_nos }),
                                        new Text({ text: partdetails.msgp_supplier_name, width: "8vw", tooltip: partdetails.msgp_supplier_name }),
                                        new Text({ text: partdetails.mgsp_vendor_inco_term, width: "8vw", tooltip: partdetails.mgsp_vendor_inco_term }),
                                        new Text({ text: partdetails.existing_mgsp_po_price, width: "8vw", tooltip: partdetails.existing_mgsp_po_price }),
                                        new Text({ text: partdetails.target_price, width: "8vw", tooltip: partdetails.target_price }),

                                        // new sap.m.Link({
                                        //   text: `${partdetails.state === null ? "Pending" : partdetails.state ? "Approved" : "Rejected"}`,
                                        //   width: "8vw",
                                        //   press: function (oEvent) {
                                        //     //breakpoint;
                                        //     let state;
                                        //     let statusLink = oEvent.getSource();

                                        //     // Determine the current state and toggle accordingly
                                        //     if (statusLink.getText() === 'Rejected') {
                                        //       state = true; // Setting state to true for Approved
                                        //       statusLink.setText("Approved");
                                        //       statusLink.addStyleClass("approved");
                                        //       statusLink.removeStyleClass("rejected");
                                        //       statusLink.removeStyleClass("pending"); // Remove pending class if it exists
                                        //     } else if (statusLink.getText() === 'Approved') {
                                        //       state = null; // Setting state to null for Pending
                                        //       statusLink.setText("Pending");
                                        //       statusLink.addStyleClass("pending");
                                        //       statusLink.removeStyleClass("approved");
                                        //       statusLink.removeStyleClass("rejected");
                                        //     } else {
                                        //       state = false; // Setting state to false for Rejected
                                        //       statusLink.setText("Rejected");
                                        //       statusLink.addStyleClass("rejected");
                                        //       statusLink.removeStyleClass("approved");
                                        //       statusLink.removeStyleClass("pending"); // Remove pending class if it exists
                                        //     }

                                        //     var yoyLineItem = this.getModel("device").getProperty("/yoy_lineitem") || {};
                                        //     if (typeof (yoyLineItem) == 'string') {
                                        //       yoyLineItem = JSON.parse(yoyLineItem);
                                        //     }

                                        //     let rowid = oEvent.getSource().getModel("rowid").getData().rowid;
                                        //     yoyLineItem[rowid] = state;
                                        //     this.getModel("device").setProperty("/yoy_lineitem", JSON.stringify(yoyLineItem));
                                        //   }
                                        // })
                                        //   .addStyleClass("statusLinkClass")
                                        //   .addStyleClass(`${partdetails.state === null ? "pending" : partdetails.state ? "approved" : "rejected"}`)

                                    ]
                                }).addStyleClass("hboxRowClass"),
                            ]
                        });

                        // Set the model directly to the ColumnListItem
                        var modelrow = new JSONModel({
                            rowid: partdetails.id
                        });
                        oColumnListItem.setModel(modelrow, 'rowid');

                        // Add the ColumnListItem to the table
                        otable.addItem(oColumnListItem);
                    }

                    for (let field of fields) {
                        var oColumnListItem1 = new ColumnListItem({
                            cells: [
                                new Text({ text: `${field}`, tooltip: `${field}` }).addStyleClass("InputToTextClass"),
                            ]
                        })
                        var modelrow = new JSONModel({
                            rowid: field
                        });
                        oColumnListItem1.setModel(modelrow, `rowid`);
                        otable.addItem(oColumnListItem1);

                    }

                    var classIndex = 1;
                    for (let supplier of finalsupp.suplier_detail_together) {
                        var newSupplier = new Table({
                            width: "20vw",
                            columns: new Column({
                                header: [
                                    new HBox({
                                        items: [
                                            new Text({ text: `${supplier.supplier}` }).addStyleClass(`colorClassSupplier` + `${classIndex}`)
                                        ]
                                    })
                                ]
                            })
                        }).addStyleClass("tableClass");
                        var model = new JSONModel({
                            supplierid: `${supplier.id_main}`
                        })
                        newSupplier.setModel(model, 'supplier_id');

                        for (let i = 0; i < otable.getItems().length; i++) {
                            //breakpoint
                            let rowid = otable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
                            let itemFound = supplier.rel.find(item => item.value_key == rowid);
                            if (itemFound) {
                                var oColumnListItem6 = new ColumnListItem({
                                    cells: [
                                        new Text({ text: `${itemFound.value}`, tooltip: `${itemFound.value}` })
                                    ]
                                })
                                newSupplier.addItem(oColumnListItem6);
                            }
                            else {
                                var oColumnListItem6 = new ColumnListItem({
                                    cells: [
                                        new Text({ text: null })
                                    ]
                                })
                                newSupplier.addItem(oColumnListItem6);
                            }
                        }

                        for (var m = 0; m < finalsupp.yoy_details.length; m++) {
                            if (finalsupp.yoy_details[m].supplierid == supplier.id_main) {
                                //breakpoint
                                newSupplier.getItems()[m + 1].addStyleClass(`input` + `colorClassSupplier` + `${classIndex}`)
                            }
                        }
                        classIndex = classIndex + 1;

                        // Add the newly created column to the table
                        oHboxSupplier.addItem(newSupplier);
                    }

                    //Investment breakup
                    var invmainVbox = this.byId("mainHBox2");
                    invmainVbox.getItems()[0].setWidth("40vw")
                    ////breakpoint
                    invmainVbox.getItems()[0].getItems()[0].destroyColumns();
                    invmainVbox.getItems()[0].getItems()[0].destroyItems();
                    invmainVbox.getItems()[1].destroyItems();
                    var invoHboxSupplier = invmainVbox.getItems()[1];
                    var invotable = invmainVbox.getItems()[0].getItems()[0];
                    ////breakpoint;
                    var invfirstColumn = new sap.m.Column({
                        // width: "500px",
                        header:
                            new Text({ text: "All figures in Rs.Lacs", tooltip: "All figures in Rs.Lacs", textAlign: "End" }),

                    });
                    invotable.addColumn(invfirstColumn);
                    function createColumnListItem(leftValue, rightValue) {
                        var oColumnListItem = new ColumnListItem({
                            cells: [
                                new HBox({
                                    justifyContent: "SpaceBetween",
                                    items: [
                                        new Text({ text: leftValue, tooltip: leftValue }).addStyleClass("InputToTextClass"),
                                        new Text({ text: rightValue, tooltip: leftValue }).addStyleClass("InputToTextClass")
                                    ]
                                })
                            ]
                        }).addStyleClass("capexUpperSectionClass");
                        var modelrow = new JSONModel({
                            rowid: rightValue
                        });
                        oColumnListItem.setModel(modelrow, `rowid`);
                        return oColumnListItem;

                    }

                    const items = [
                        ["Capex", "Tooling / Dies / Moulds / Fixtures"],
                        [" ", "Inspection Gauges"],
                        ["Revenue", "Testing / Validation"],
                        [" ", "Engg Fees"],
                        [" ", "Proto Tooling"],
                        [" ", "Logistics Trollies"],
                        [" ", "Total Landed Investment Settled"]
                    ];
                    items.forEach(([left, right]) => {
                        invotable.addItem(createColumnListItem(left, right));
                    });


                    for (let supplier of finalsupp.suplier_detail_together) {
                        var newSupplier = new Table({
                            width: "20vw",
                            columns: new Column({
                                header: [
                                    new HBox({
                                        items: [
                                            new sap.ui.core.Icon({
                                                src: 'sap-icon://circle-task',
                                                height: "10px",
                                                visible: false,
                                                press: function (oEvent) {
                                                    ////breakpoint
                                                    if (oEvent.getSource().getSrc() == "sap-icon://circle-task") {
                                                        oEvent.getSource().setSrc("sap-icon://bo-strategy-management")
                                                    }
                                                    else {
                                                        oEvent.getSource().setSrc("sap-icon://circle-task")
                                                    }
                                                }
                                            }),
                                            new Text({ text: `${supplier.supplier}` })
                                        ]
                                    })
                                ]
                            })
                        }).addStyleClass("tableClass");
                        var model = new JSONModel({
                            supplierid: `${supplier.id_main}`
                        })
                        newSupplier.setModel(model, 'supplier_id');

                        for (let i = 0; i < invotable.getItems().length; i++) {
                            ////breakpoint
                            let rowid = invotable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
                            let itemFound = supplier.rel.find(item => item.value_key == rowid);
                            if (itemFound) {
                                var oColumnListItem6 = new ColumnListItem({
                                    cells: [
                                        new Text({ text: `${itemFound.value}`, tooltip: `${itemFound.value}` })
                                    ]
                                })
                                newSupplier.addItem(oColumnListItem6);
                            }
                            else {
                                var oColumnListItem6 = new ColumnListItem({
                                    cells: [
                                        new Text({ text: null })
                                    ]
                                })
                                newSupplier.addItem(oColumnListItem6);
                            }
                        }
                        // Add the newly created column to the table
                        invoHboxSupplier.addItem(newSupplier);
                    }
                    //Investment breakup end

                    //item data
                    var docmainHboc = this.byId("mainHBox3");
                    docmainHboc.getItems()[0].setWidth("40vw")
                    docmainHboc.getItems()[0].getItems()[0].destroyColumns();
                    docmainHboc.getItems()[0].getItems()[0].destroyItems();
                    docmainHboc.getItems()[1].destroyItems();
                    var itemsupplierHBox = this.byId("HboxSupplier3");
                    var itemparttable = this.byId("parentTable3");

                    var datafirstColumn = new sap.m.Column({
                        header: [
                            new Text({ text: "MGSP Part No", tooltip: "MGSP Part No", textAlign: "End" }),
                        ]
                    });
                    var datasecondcolumn = new sap.m.Column({
                        header: [
                            new Text({ text: "Finished Weight of Part / System (kg)", tooltip: "Finished Weight of Part / System (kg)", textAlign: "End" })
                        ]
                    });

                    itemparttable.addColumn(datafirstColumn);
                    itemparttable.addColumn(datasecondcolumn);


                    for (let i = 0; i < finalsupp.yoy_details.length; i++) {
                        let partdetails = finalsupp.yoy_details[i];
                        var oColumnListItem = new ColumnListItem({
                            cells: [
                                new Text({ text: partdetails.mgsp_part_nos, tooltip: partdetails.mgsp_part_nos }),
                                new Text({
                                    text: partdetails.finished_weight_of_part ? `${partdetails.finished_weight_of_part}` : "",
                                    tooltip: partdetails.finished_weight_of_part ? `${partdetails.finished_weight_of_part}` : "",
                                }),
                                new Text({ text: "DTB Packaging Cost Rs. (Included in above Offer prices)", tooltip: "DTB Packaging Cost Rs. (Included in above Offer prices)" }),
                            ]
                        });

                        // Set the model directly to the ColumnListItem
                        var modelrow = new JSONModel({
                            rowid: partdetails.id + `DTB Packaging Cost Rs. (Included in above Offer prices)`
                        });
                        oColumnListItem.setModel(modelrow, 'rowid');

                        // Add the ColumnListItem to the table
                        itemparttable.addItem(oColumnListItem);
                    }

                    ///ITEM DATA SUBSECTION
                    var contentContainerDTB = new sap.m.HBox({
                        items: [
                            // Add a Table
                            new sap.m.Table(),
                            // Add an HBox
                            new sap.m.HBox()
                        ]
                    });
                    //breakpoint
                    var dtbtable = contentContainerDTB.getItems()[0];
                    dtbtable.destroyColumns();
                    dtbtable.destroyItems();
                    var dtbleftsidesection = contentContainerDTB.getItems()[1]
                    dtbtable.addStyleClass("customtableClass");
                    dtbtable.setWidth("40vw")
                    dtbleftsidesection.addStyleClass("rightHboxClass")
                    var dtbfirstColumn = new sap.m.Column({
                        // width: "500px",
                        header:
                            new Text({ text: "MGSP Part No", tooltip: "MGSP Part No" }),

                    });
                    dtbtable.addColumn(dtbfirstColumn);
                    for (let i = 0; i < finalsupp.yoy_details.length; i++) {
                        let partdetails = finalsupp.yoy_details[i];

                        var oColumnListItem = new ColumnListItem({
                            cells: [
                                new Text({ text: `${partdetails.mgsp_part_nos}`, tooltip: `${partdetails.mgsp_part_nos}` })
                            ]

                        });
                        // Set the model directly to the ColumnListItem
                        var modelrow = new JSONModel({
                            rowid: partdetails.id + "DTB Packaging Cost Rs. (Included in above Offer prices)"
                        });
                        oColumnListItem.setModel(modelrow, 'rowid');

                        //If Yoy table has supplierid then set model

                        if (partdetails.supplierid) {

                            var supplierid = new JSONModel({
                                supplierid: partdetails.supplierid
                            });
                            oColumnListItem.setModel(supplierid, `supplierid`);
                        }

                        // Add the ColumnListItem to the table
                        dtbtable.addItem(oColumnListItem);

                    }
                    for (let supplier of finalsupp.suplier_detail_together) {
                        var newSupplier = new Table({
                            width: "20vw",
                            columns: new Column({
                                header: [
                                    // new HBox({
                                    // items: [
                                    new Text({
                                        text: `${supplier.supplier}`
                                    })
                                    // ]
                                    // })
                                ]
                            })
                        }).addStyleClass("tableClass");
                        var model = new JSONModel({
                            supplierid: `${supplier.id_main}`
                        })
                        newSupplier.setModel(model, 'supplier_id');

                        for (let i = 0; i < dtbtable.getItems().length; i++) {

                            let rowid = dtbtable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
                            let itemFound = supplier.rel.find(item => item.value_key == rowid);
                            if (itemFound) {
                                var oColumnListItem6 = new ColumnListItem({
                                    cells: [
                                        new Text({ text: `${itemFound.value}` })
                                    ]
                                })
                                newSupplier.addItem(oColumnListItem6);
                            }
                            else {
                                var oColumnListItem6 = new ColumnListItem({
                                    cells: [
                                        new Text({
                                            text: null,
                                            liveChange: function (oEvent) {
                                                //////breakpoint
                                                validateSubmit();
                                            }
                                        })
                                    ]
                                })
                                newSupplier.addItem(oColumnListItem6);
                            }
                        }
                        // Add the newly created column to the table
                        dtbleftsidesection.addItem(newSupplier);
                    }
                    this.byId("dtbpackingSection").destroyBlocks();
                    this.byId("dtbpackingSection").addBlock(contentContainerDTB)


                    //Item data subsection end

                    //Risk Analysis

                    var riskmainHbox = this.byId("mainhboxriskdoc");
                    riskmainHbox.getItems()[0].setWidth("40vw")
                    riskmainHbox.getItems()[0].getItems()[0].destroyColumns();
                    riskmainHbox.getItems()[0].getItems()[0].destroyItems();
                    riskmainHbox.getItems()[1].destroyItems();

                    var risktable = this.byId("parentTableriskdoc");
                    var riskleftsidesection = this.byId("HboxSupplierriskdoc");
                    risktable.removeStyleClass("tableClass");
                    risktable.addStyleClass("customtableClass");
                    risktable.setWidth("40vw")
                    riskleftsidesection.addStyleClass("rightHboxClass")
                    var btbfirstColumn = new sap.m.Column({
                        // width: "500px",
                        header:
                            new Text({ text: "   " }),

                    });
                    risktable.addColumn(btbfirstColumn);
                    const agreementsAndRatings = [
                        "Development Supply Agreement (DSA) - Whether Signed? (If No: LoBA will share after DSA agreement)",
                        "Tooling Agreement - Is it signed? (If applicable)",
                        "Supplier Code of Conduct Declaration - Submitted? (If No: Must be signed before start of development)",
                        "SRMM Score - Completed? (If Not Done: To be done before start of development)",
                        "Financial Rating - Completed? (If Not Done: To be done before start of development)",
                        "IPR Undertaking - Submitted? (If Not Done: To be done before start of development)"
                    ];

                    for (let field of agreementsAndRatings) {
                        var oColumnListItemrisk = new ColumnListItem({
                            cells: [
                                new Text({ text: `${field}`, tooltip: `${field}` })
                            ]
                        })
                        var modelrow = new JSONModel({
                            rowid: field
                        });
                        oColumnListItemrisk.setModel(modelrow, `rowid`);
                        risktable.addItem(oColumnListItemrisk);
                    }
                    for (let supplier of finalsupp.suplier_detail_together) {
                        var newSupplier = new Table({
                            width: "20vw",
                            columns: new Column({
                                header: [

                                    // new sap.ui.core.Icon({
                                    // 	src: 'sap-icon://circle-task',
                                    // 	height: "10px",
                                    // 	press: function (oEvent) {
                                    // 		////breakpoint
                                    // 		if (oEvent.getSource().getSrc() == "sap-icon://circle-task") {
                                    // 			oEvent.getSource().setSrc("sap-icon://bo-strategy-management")
                                    // 		}
                                    // 		else {
                                    // 			oEvent.getSource().setSrc("sap-icon://circle-task")
                                    // 		}
                                    // 	}
                                    // }),
                                    new Text({
                                        text: `${supplier.supplier}`
                                    })
                                ]
                            })
                        }).addStyleClass("tableClass");
                        var model = new JSONModel({
                            supplierid: `${supplier.id_main}`
                        })
                        newSupplier.setModel(model, 'supplier_id');

                        for (let i = 0; i < risktable.getItems().length; i++) {

                            let rowid = risktable.getItems()[i]?.oModels?.rowid?.oData?.rowid ?? null;
                            let itemFound = supplier.rel.find(item => item.value_key == rowid);
                            if (itemFound) {
                                var oColumnListItem6 = new ColumnListItem({
                                    cells: [
                                        new Text({ text: `${itemFound.value}` })
                                    ]
                                })
                                newSupplier.addItem(oColumnListItem6);
                            }
                            else {
                                var oColumnListItem6 = new ColumnListItem({
                                    cells: [
                                        new Text({
                                            value: null,
                                            liveChange: function (oEvent) {
                                                //////breakpoint
                                                validateSubmit();
                                            }
                                        })
                                    ]
                                })
                                newSupplier.addItem(oColumnListItem6);
                            }
                        }
                        // Add the newly created column to the table
                        riskleftsidesection.addItem(newSupplier);
                    }

                    ///RISK ANALYSIS END//


                    var workflowhistoryarray = oData.vob_to_workflow_history;

                    var comments = oData.vob_comments;
                    let cashflowcmt = comments.filter(item => item.comment && item.comment.startsWith("Cash Flow: "));
                    let trimmedCashFlow = cashflowcmt.length ? cashflowcmt[0].comment.replace("Cash Flow: ", "") : '';

                    this.byId("cashflowcomment").setText(trimmedCashFlow);

                    let investbreakupcmt = comments.filter(item => item.comment && item.comment.startsWith("Investment Breakup: "));
                    let trimmedInvestmentComment = investbreakupcmt.length ? investbreakupcmt[0].comment.replace("Investment Breakup: ", "") : '';

                    this.byId("approvalInvestmentSectionComments").setText(trimmedInvestmentComment);

                    let riskAnanlysisCmt = comments.filter(item => item.comment && item.comment.startsWith("Risk Analysis: "));
                    let trimmedriskAnanlysisCmt = riskAnanlysisCmt.length ? riskAnanlysisCmt[0].comment.replace("Risk Analysis: ", "") : '';

                    this.byId("approvalRiskSectionComments").setText(trimmedriskAnanlysisCmt);

                    workflowhistoryarray.sort(function (a, b) {
                        // Split date and time components
                        function parseCustomDate(dateTimeStr) {
                            // Example: "23/10/2024, 3:07:47 pm"
                            const [datePart, timePart] = dateTimeStr.split(", ");

                            // Split day, month, year
                            const [day, month, year] = datePart.split("/").map(Number);

                            // Construct a format that JavaScript can parse
                            return new Date(`${year}-${month}-${day} ${timePart}`);
                        }

                        const dateA = parseCustomDate(a.end_date_time);
                        const dateB = parseCustomDate(b.end_date_time);

                        return dateA - dateB; // Ascending order
                    });

                    var vBox = this.byId("v1");
                    vBox.destroyItems();
                    var groupedData = {};
                    vBox.addStyleClass("scrollvbox");

                    let oTable = new sap.m.Table({
                        fixedLayout: false,
                        width: "110vw"
                    });

                    oTable.addStyleClass("tableWithBorder");

                    // Define Table columns, including Level
                    oTable.addColumn(new sap.m.Column({ header: new sap.m.Text({ text: "Level" }) }));
                    oTable.addColumn(new sap.m.Column({ header: new sap.m.Text({ text: "Employee ID" }) }));
                    oTable.addColumn(new sap.m.Column({ header: new sap.m.Text({ text: "Employee Name" }) }));
                    oTable.addColumn(new sap.m.Column({ header: new sap.m.Text({ text: "Status" }) }));
                    oTable.addColumn(new sap.m.Column({ header: new sap.m.Text({ text: "Begin Date" }) }));
                    oTable.addColumn(new sap.m.Column({ header: new sap.m.Text({ text: "End Date" }) }));
                    oTable.addColumn(new sap.m.Column({ header: new sap.m.Text({ text: "Days Taken" }) }));
                    oTable.addColumn(new sap.m.Column({ header: new sap.m.Text({ text: "Comments" }) }));

                    // Iterate over workflow history and add rows
                    workflowhistoryarray.forEach(function (item) {
                        var oRow = new sap.m.ColumnListItem();

                        // Determine display level
                        let displayLevel;
                        if (item.level === '0') {
                            displayLevel = 0; // Keep it as is for level 0
                        } else {
                            displayLevel = item.level;
                        }

                        // Add cells to the row
                        oRow.addCell(new sap.m.Text({ text: displayLevel })); // Display the numeric level
                        oRow.addCell(new sap.m.Text({ text: item.employee_id }));
                        oRow.addCell(new sap.m.Text({ text: item.employee_name }));
                        oRow.addCell(new sap.m.Text({ text: item.status }));
                        oRow.addCell(new sap.m.Text({ text: item.begin_date_time }));
                        oRow.addCell(new sap.m.Text({ text: item.end_date_time }));
                        oRow.addCell(new sap.m.Text({ text: item.days_taken }));

                        // Enable wrapping for multiline comments
                        oRow.addCell(new sap.m.Text({ text: item.comments || "", wrapping: true }));

                        oTable.addItem(oRow);
                    });

                    // Add the table to the VBox
                    vBox.addItem(oTable);

                    //loading images
                    var url = window.location.hash;
                    let regexnewpdf = /vobApproval\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                    const matchesnewpdf = url.match(regexnewpdf);
                    var id = matchesnewpdf[1];

                    let imageSupplierContainer = this.byId("imageSupplierContainerApproval");
                    let imagePartContainer = this.byId("imagePartContainerApproval");

                    await loadImages.call(this, imageSupplierContainer, imagePartContainer, id);



                } catch (error) {
                    console.log("Error", error);
                    oBusyDialog.close();
                    sap.m.MessageBox.error("An error occurred while fetching the data. Please try again later.");
                } finally {
                    oBusyDialog.close();
                }
            },
            onAfterRendering: function (oEvent) {
                debugger

            },
            onFilePressed: async function (oEvent) {
                debugger
                var oBusyDialog = new sap.m.BusyDialog({
                    text: "Loading, please wait..."
                });
                oBusyDialog.open();
                try {
                    oEvent.preventDefault();
                    let path = oEvent.getSource().getBindingContext("oCapData").getObject().folder;
                    let filename = oEvent.getSource().getBindingContext("oCapData").getObject().fileName;

                    // Get the signed URL from the backend
                    let oFunction = oEvent.getSource().getModel().bindContext("/getFileForVOB(...)");
                    oFunction.setParameter("fileName", path); // 
                    await oFunction.execute();

                    // Retrieve the signed URL directly
                    let fileUrl = oFunction.getBoundContext().getValue().value;
                    let fileExtension = filename.split('.').pop().toLowerCase(); // Extract file extension

                    // Check the file type to determine whether to open in a new window or download
                    if (["pdf", "png", "jpeg", "jpg"].includes(fileExtension)) {
                        // For PDF and image files, open them in a new window
                        let newWindow = window.open(fileUrl, '_blank');
                        if (!newWindow) {
                            sap.m.MessageToast.show("Please allow pop-ups to view the file.");
                        }
                    } else {
                        // For other file types, initiate download
                        let link = document.createElement("a");
                        link.href = fileUrl;
                        link.download = filename; // Set the file name for download
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link); // Clean up
                    }
                } catch (error) {
                    // Log the error and show a toast message or handle the error
                    console.error("An error occurred:", error);
                    oBusyDialog.close();
                    sap.m.MessageToast.show("An error occurred while opening the file.");
                } finally {
                    // Hide the busy indicator after the process is complete (success or failure)

                    oBusyDialog.close();
                }
            },
            onPDFPrintPress: async function (oEvent) {
                const oSaveAsPdfButton = oEvent.getSource();
                const jsPDFUrl = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js';
                const html2pdfUrl = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js';

                // Create and open the BusyDialog
                const oBusyDialog = new sap.m.BusyDialog({
                    text: "Preparing your PDF. This might take a moment..."
                });
                oBusyDialog.open();

                try {
                    // Supplier and Part images
                    let imageSupplierContainer = this.byId("imageSupplierContainerApproval");
                    let imagePartContainer = this.byId("imagePartContainerApproval");

                    // Extract ID from the URL
                    var url = window.location.hash;
                    let regexnewpdf = /vobApproval\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                    const matchesnewpdf = url.match(regexnewpdf);
                    var id = matchesnewpdf[1];
                    await loadImagespdf.call(this, imageSupplierContainer, imagePartContainer, id);

                    // Helper function to dynamically load scripts
                    function loadScript(url) {
                        return new Promise((resolve, reject) => {
                            const existingScript = document.querySelector(`script[src="${url}"]`);
                            if (existingScript) {
                                resolve(); // Script already loaded
                            } else {
                                const script = document.createElement('script');
                                script.src = url;
                                script.onload = resolve;
                                script.onerror = reject;
                                document.head.appendChild(script);
                            }
                        });
                    }

                    // Load required scripts
                    await Promise.all([
                        loadScript(jsPDFUrl),
                        loadScript(html2pdfUrl)
                    ]);

                    console.log('Libraries loaded successfully.');

                    const sectionIds = [
                        "vobPartRequest",
                        "supplierSectionApproval",
                        "partSectionApproval",
                        "vobSupplierDetails",
                        "vobDocuments",
                        "workflowhistory"
                    ];

                    const combineSection = [
                        ["approvalCashFlowSection", "approvalCashFlowSectionComments"],
                        ["itemdataSection", "dtbpackingSection"],
                        ["approvalInvestmentSection", "investmentSection"],
                        ["approvalRiskSection", "riskSection"]
                    ];

                    document.body.classList.add("print-mode");

                    const pdfContent = document.createElement("div");
                    pdfContent.style.width = "100%";

                    sectionIds.forEach(sectionId => {
                        const section = this.byId(sectionId).getDomRef();
                        if (section) {
                            if (sectionId === "vobSupplierDetails") {
                                combineSection.forEach(pair => {
                                    const section1 = this.byId(pair[0]).getDomRef();
                                    const section2 = this.byId(pair[1]).getDomRef();

                                    if (section1 && section2) {
                                        const combinedDiv = document.createElement('div');
                                        combinedDiv.style.pageBreakAfter = "always";

                                        combinedDiv.appendChild(section1.cloneNode(true));
                                        combinedDiv.appendChild(section2.cloneNode(true));

                                        pdfContent.appendChild(combinedDiv);
                                    }
                                });
                            } else {
                                const clonedSection = section.cloneNode(true);
                                clonedSection.style.pageBreakAfter = "always";
                                pdfContent.appendChild(clonedSection);
                            }
                        }
                    });

                    let sequentialvobid = this.byId("approvalheadertitle").getText();
                    const options = {
                        margin: 0,
                        filename: `${sequentialvobid}.pdf`,
                        image: { type: 'jpeg', quality: 0.98 },
                        html2canvas: { scale: 2, useCORS: true },
                        jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
                    };

                    await html2pdf().from(pdfContent).set(options).save();

                    console.log("PDF downloaded successfully.");
                } catch (error) {
                    console.error("Error generating PDF:", error);
                    sap.m.MessageToast.show("An error occurred while generating the PDF. Please try again.");
                } finally {
                    // Always close the BusyDialog
                    oBusyDialog.close();
                    document.body.classList.remove("print-mode");
                }
            }
        });

    }
);
