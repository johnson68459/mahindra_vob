sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox"
  ],
  function (BaseController, Filter, FilterOperator, MessageBox) {
    "use strict";

    return BaseController.extend("vobwizard.controller.App", {
      onInit: function () {
        debugger

      },
      onBeforeRendering: function () {
        debugger
        try {
          var oTable = this.byId("vobtable");
          var oBinding = oTable.getBinding("items");

          if (oBinding) {
            // Create a custom sorter for the VOB ID column
            var oVobIdSorter = new sap.ui.model.Sorter("sequentialvobid", true);
            oVobIdSorter.fnCompare = function (a, b) {
              // Split the string to extract the numeric part
              var regExp = /(\d+)/;
              var numA = a.match(regExp) ? parseInt(a.match(regExp)[0], 10) : 0;
              var numB = b.match(regExp) ? parseInt(b.match(regExp)[0], 10) : 0;

              // Sort based on the extracted number
              return numA - numB;
            };

            // Create a sorter for the createdAt field (descending order)
            var oCreatedAtSorter = new sap.ui.model.Sorter("createdAt", true);

            // Apply both sorters to the binding
            oBinding.sort([oCreatedAtSorter, oVobIdSorter]);
          } else {
            console.error("Table binding not available yet.");
          }
        } catch (error) {
          console.error("An error occurred during sorting:", error);
        }

      },
      onItemPress: function (oEvent) {
        debugger;
        let vobId = oEvent.getSource().getBindingContext().getObject().id;
        let flowstatus = oEvent.getSource().getBindingContext().getObject().flowstatus;

        if (flowstatus === "Approved") {
          // Navigate to the approved view route
          this.getOwnerComponent().getRouter().navTo("RouteApprovedViewPage", {
            key: `id=${vobId},IsActiveEntity=true`
          });
        } else {
          // Navigate to the regular ObjectPage route
          this.getOwnerComponent().getRouter().navTo("RouteObjectPage", {
            key: `id=${vobId},IsActiveEntity=true`
          });
        }
      },
      onCreatePressed: async function (oEvent) {
        try {
          // Bind context to the createEntry function
          const oFunction = this.getView().getModel().bindContext("/createEntry(...)");
          oFunction.setParameter("status", "vobpost");

          // Execute the function and wait for completion
          await oFunction.execute();

          // Retrieve the result from the bound context
          const result = oFunction.getBoundContext().getValue();

          // Refresh the table binding
          this.byId("vobtable").getBinding("items").refresh();

          // Navigate to the Object Page with the result key
          const oRouter = this.getOwnerComponent().getRouter();
          oRouter.navTo("RouteObjectPage", {
            key: `id=${result.value},IsActiveEntity=true`
          });
        } catch (error) {
          // Log errors for debugging
          console.error("Error during create and navigation process:", error);
          sap.m.MessageToast.show("An error occurred while creating the entry.");
        }
      },
      onDeletePressed: async function (oEvent) {
        const oTable = this.byId("vobtable");
        const selectedItems = [];
        let isDeleted = false; // Flag to track if any deletable items are selected
        const deletableStatus = "Pending For Approval"; // Non-deletable status for clarity

        // Collect IDs of selected items that are deletable
        oTable.getItems().forEach(item => {
          const context = item.getBindingContext();
          const { id, flowstatus } = context.getObject();

          if (item.getSelected()) {
            if (flowstatus !== deletableStatus) {
              selectedItems.push(id);
              isDeleted = true; // Mark as deletable item found
            }
          }
        });

        // If no deletable items are selected, show a message and return
        if (!isDeleted) {
          sap.m.MessageToast.show(
            "Please select at least one item that is not in 'Pending For Approval' status to delete."
          );
          return;
        }

        // Show confirmation dialog
        MessageBox.confirm(
          "Are you sure you want to delete the selected requests?\n\nNote: Requests in 'Pending For Approval' status will not be deleted.",
          {
            icon: MessageBox.Icon.WARNING,
            title: "Confirm Deletion",
            actions: [MessageBox.Action.YES, MessageBox.Action.NO],
            onClose: async (oAction) => {
              if (oAction === MessageBox.Action.YES) {
                try {
                  // Execute deletion for selected items
                  const oFunction = this.getView().getModel().bindContext("/deleteEntry(...)");
                  oFunction.setParameter("keyid", JSON.stringify(selectedItems));
                  await oFunction.execute();

                  // Provide feedback and refresh the table
                  sap.m.MessageToast.show("The selected items have been successfully deleted.");
                  oTable.getBinding("items").refresh();
                } catch (error) {
                  console.error("Error deleting items:", error);
                  sap.m.MessageToast.show("An error occurred while attempting to delete the selected items. Please try again.");
                }
              }
            }
          }
        );
      },
      onFilterPosts: function (oEvent) {
        const sQuery = oEvent.getParameter("query");
        const oTable = this.byId("vobtable");
        const oBinding = oTable.getBinding("items");

        if (sQuery) {
          // Create filters for relevant fields
          const aFields = [
            "part_system",
            "project_code_description",
            "sop",
            "sequentialvobid",
            "flowstatus"
          ];

          // Generate filters dynamically
          const aFilters = aFields.map(field =>
            new Filter({
              path: field,
              operator: FilterOperator.Contains,
              value1: sQuery,
              caseSensitive: false
            })
          );

          // Combine filters with OR
          const oCombinedFilter = new Filter({
            filters: aFilters,
            and: false
          });

          // Apply the combined filter to the binding
          oBinding.filter([oCombinedFilter]);
        } else {
          // Clear filters if no query
          oBinding.filter([]);
        }
      },
      onHelpIconPressed: function (oEvent) {
        sap.m.MessageToast.show("Help icon pressed..")
      },
      onSOPPressed: function (oEvent) {
        sap.m.MessageToast.show("SOP icon pressed..")
      },
      onLevelPress: async function (oEvent) {
        debugger
        let vobId = oEvent.getSource().getBindingContext().getObject().id;
        const oFunction = this.getView().getModel().bindContext("/getCurrentLevel(...)");
        oFunction.setParameter("vobid", vobId);
        await oFunction.execute()

        // Get the result directly from the context
        const currentLevelValue = oFunction.getBoundContext().getValue();
        const currentlevel_object = currentLevelValue.value; // This will contain the current level details object
        const oPopover = new sap.m.Popover({
          placement: sap.m.PlacementType.Top,
          showHeader: false,
          contentWidth: "40vw",
          resizable: true
        });

        // Create a Table inside the Popover
        const oTable = new sap.m.Table({

          columns: [
            new sap.m.Column({
              header: new sap.m.Text({ text: "Employee Id", })
            }),
            new sap.m.Column({
              header: new sap.m.Text({ text: "Name" })
            }),
            new sap.m.Column({
              header: new sap.m.Text({ text: "Level" })
            })
          ]
        });
        oTable.addStyleClass("poperovertable");

        oTable.addItem(new sap.m.ColumnListItem({
          cells: [

            new sap.m.Text({ text: currentlevel_object.employee_id, tooltip: currentlevel_object.employee_id }),
            new sap.m.Text({ text: currentlevel_object.employee_name, tooltip: currentlevel_object.employee_name }),
            new sap.m.Text({ text: currentlevel_object.level, tooltip: currentlevel_object.level })
          ]
        }))


        // Add the table to the popover content
        oPopover.addContent(oTable);

        // Open the popover
        oPopover.openBy(oEvent.getSource());
      },


    });
  }
);
