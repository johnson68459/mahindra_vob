sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/ComponentContainer",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Label",
    "sap/m/library",
    "sap/m/MessageToast",
    "sap/m/Text",
    "sap/m/TextArea",
    "sap/ui/unified/FileUploader",
    "sap/ui/core/BusyIndicator",
    "sap/m/MessageBox",
],
    function (Controller, ComponentContainer, Dialog, Button, Label, mobileLibrary, MessageToast, Text, TextArea, FileUploader, BusyIndicator, MessageBox) {
        "use strict";
        // shortcut for sap.m.ButtonType
        var ButtonType = mobileLibrary.ButtonType;

        // shortcut for sap.m.DialogType
        var DialogType = mobileLibrary.DialogType;

        var isSupplierNotEmpty;
        var isPartNotEmpty;
        var isImageLoaded;

        var extractedId;
        var flag;
        var vobWizard;
        var vobId;
        var vobidforonafterrendering;
        var IsActiveEntity;
        var base64Supplier;
        var base64Part;
        var screenNumber = 1;
        var oFileNameSupplier;
        var oFileNamePart;
        var base_url;
        var status_check;
        var isApprovedLoaded = true;
        var objectpagelist = ["vobRequestObjectPage", "", "vobSupplierObjectPage", "vobDocumentObjectPage", "vobApprovalObjectPage"];
        // var objectpagelist = ["vobRequestObjectPage", "", "vobSupplierObjectPage", "vobDocumentObjectPage", "vobApprovalObjectPage"];
        const initializeWizardStep = async function (vobWizard, objectpagelist) {
            debugger;
            var rawId = vobWizard.getProgressStep().sId;
            let parts = rawId.split("--");
            var currentStepId = parts[parts.length - 1];

            var oFooterButtons = this.byId("overflowtoolbarwizard"); // Assuming this contains the footer buttons

            var wizstep = this.byId(`${currentStepId}`);
            var ProgressNumber = vobWizard.getProgress();




            // Optionally navigate to the last step
            if (status_check === "Approved" && isApprovedLoaded) {
                ProgressNumber = 5;
                isApprovedLoaded = false;
            }

            if (objectpagelist[ProgressNumber - 1]) {

                var content = wizstep.getContent();

                // Loop through the content and destroy each component explicitly
                if (content && content.length > 0) {
                    content.forEach(function (component) {
                        component.destroy();
                    });
                }

                wizstep.destroyContent();

                var compCont = new ComponentContainer({
                    propagateModel: true,
                    height: "100%"
                });
                wizstep.addContent(compCont);

                var url = window.location.hash;
                const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                const matches = url.match(regex);

                if (matches) {
                    vobId = matches[1];//Need to be fetched from global variavle else on everyclick page will refresh
                    IsActiveEntity = matches[2];
                }
                debugger;

                // Disable footer buttons
                oFooterButtons.setEnabled(false); // Disable the footer buttons

                // Create the component
                this.getOwnerComponent().createComponent({
                    usage: `screen${ProgressNumber}`,
                    async: true,
                    manifest: true
                }).then(function (oFioriApp) {
                    var keyValue = `id=${vobId},IsActiveEntity=${IsActiveEntity}`;

                    oFioriApp.getRouter().navTo(`${objectpagelist[ProgressNumber - 1]}`, {
                        key: keyValue
                    });
                    screenNumber++;
                    compCont.setComponent(oFioriApp);

                    // Enable footer buttons after component is successfully loaded
                    oFooterButtons.setEnabled(true); // Enable them again
                }.bind(this)).catch(function (error) {
                    // Error handling block
                    console.log("Component creation failed:", error);

                    // Display a message toast to inform the user
                    sap.m.MessageToast.show("Failed to load the requested screen. Please try again.");

                    // Enable footer buttons in case of an error
                    oFooterButtons.setEnabled(true); // Enable them again
                }.bind(this));
            }
        };


        const handleWizardButton = function () {
            debugger
            let vobWizard = this.byId("CreateVOBWizard");
            let currentStep = vobWizard.getProgress();

            let oNextButton = this.byId("nextStepButton");
            let oPrevButton = this.byId("previousStepButton");

            // Get the total number of steps in the wizard
            let totalSteps = vobWizard.getSteps().length;

            // If it's the first step, hide the Previous button
            if (currentStep === 1) {
                oPrevButton.setVisible(false);
            } else {
                oPrevButton.setVisible(true);
            }

            // If it's the last step, hide the Next button
            if (currentStep === totalSteps) {
                oNextButton.setVisible(false);
            } else {
                oNextButton.setVisible(true);
            }
        };

        async function checkStatusAndToggleUploadButton(id) {
            try {
                debugger
                // Bind the context to the model for the specified status endpoint
                let oFunction = this.getView().getModel().bindContext("/getStatus(...)");
                oFunction.setParameter("vobid", id);

                // Execute the function call
                await oFunction.execute();

                // Get the result of the status
                var result = oFunction.getBoundContext().getValue().value;

                // Get buttons from Part Section
                var uploadButtonPart = this.byId("partSection").getSubSections()[0].getActions()[0]; // Upload button for part
                var deleteButtonPart = this.byId("partSection").getSubSections()[0].getActions()[1]; // Delete button for part

                // Get buttons from Supplier Section
                var uploadButtonSupplier = this.byId("supplierSection").getSubSections()[0].getActions()[0]; // Upload button for supplier
                var deleteButtonSupplier = this.byId("supplierSection").getSubSections()[0].getActions()[1]; // Delete button for supplier

                // Common logic to set visibility for both Part and Supplier sections
                var isVisible = (result === "New" || result === "Rejected");
                status_check = result;

                // Set visibility for Part Section buttons
                uploadButtonPart.setVisible(isVisible);
                deleteButtonPart.setVisible(isVisible);

                // Set visibility for Supplier Section buttons
                uploadButtonSupplier.setVisible(isVisible);
                deleteButtonSupplier.setVisible(isVisible);

            } catch (error) {
                console.error("Error fetching status:", error);
                // Handle any errors if necessary
            }
        }

        async function loadWizardStep() {

            handleWizardButton.call(this);

            // Disable the Next button before starting the loading process
            var oFooterButtons = this.byId("overflowtoolbarwizard");
            oFooterButtons.setEnabled(false);

            const busyDialog = new sap.m.BusyDialog({ text: "Loading images..." });


            const updateImageContainers = async (filesArray) => {
                // Open the busy dialog before starting the process
                busyDialog.open();
                // Set busy to true before starting the process
                this.byId("ObjectPageLayout").setBusy(true);

                try {
                    const supplierFiles = filesArray.filter(file => file.fileName.includes("/Supplier/"));
                    const partFiles = filesArray.filter(file => file.fileName.includes("/Parts/"));

                    const supplierContainer = this.byId("imageSupplierContainer");
                    const partContainer = this.byId("imagePartContainer");

                    supplierContainer.removeAllItems();
                    partContainer.removeAllItems();

                    // Update Supplier Container
                    const supplierPromise = updateContainer(supplierFiles, supplierContainer, "No Supplier Data Found");

                    // Update Part Container
                    const partPromise = updateContainer(partFiles, partContainer, "No Part Data Found");

                    // Wait for both containers to finish processing
                    await Promise.all([supplierPromise, partPromise]);

                } finally {
                    // Close the busy dialog after loading all images
                    busyDialog.close();
                    // Set busy to false once everything is done
                    this.byId("ObjectPageLayout").setBusy(false);
                    // Enable the Next button after all images are loaded
                    oFooterButtons.setEnabled(true);
                }
            };

            const updateContainer = async (files, container, emptyMessage) => {
                if (files.length === 0) {
                    container.addItem(new sap.m.MessageStrip({ text: emptyMessage }));
                } else {
                    const promises = files.map(file => addImageToContainer.call(this, file, container));
                    await Promise.all(promises);
                }
            };

            const addImageToContainer = async (file, container) => {
                const fileName = file.fileName;
                const parts = fileName.split('/');
                const newFolder = parts[parts.length - 2]; // Get folder name
                const fileBaseName = parts[parts.length - 1]; // Get file name
                const result = `${newFolder} (${fileBaseName})`;

                const oVbox = new sap.m.VBox({
                    items: [
                        new sap.m.Image({
                            src: file.url,
                            width: "100%",
                            height: "auto",
                        }),
                        new sap.m.HBox({
                            items: [
                                new sap.ui.core.Icon({
                                    src: 'sap-icon://circle-task',
                                    press: function (oEvent) {
                                        const oIcon = oEvent.getSource();
                                        oIcon.setSrc(oIcon.getSrc() === 'sap-icon://circle-task' ? "sap-icon://bo-strategy-management" : "sap-icon://circle-task");
                                    }
                                }),
                                new sap.m.Title({
                                    text: result,
                                    textAlign: "Center",
                                    wrapping: true,
                                    width: "100%"
                                })
                            ]
                        })
                    ],
                    alignItems: "Center",
                    justifyContent: "Center",
                    width: "100%"
                }).addStyleClass("eachImageelement");

                oVbox.data("fileName", fileName);
                container.addItem(oVbox); // Add the VBox to the appropriate container
            };

            if (vobWizard.getProgress() === 2) {
                const url = window.location.hash;
                const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                const matches = url.match(regex);

                let vobId = '';
                let IsActiveEntity = '';
                if (matches) {
                    vobId = matches[1];
                    IsActiveEntity = matches[2];
                }

                try {
                    // Open the busy dialog before starting the process
                    busyDialog.open();
                    checkStatusAndToggleUploadButton.call(this, vobId);
                    // if (!isImageLoaded) {
                    let oFunction = this.getView().getModel().bindContext("/getFilesListVOBSupplierPart(...)");
                    oFunction.setParameter("fileName", vobId);
                    await oFunction.execute();

                    // Get the array of files
                    const filesArray = oFunction.getBoundContext().getValue()?.value ?? '';


                    if (!filesArray || filesArray.length === 0) {
                        // If filesArray is empty, show message strips in both containers
                        const supplierContainer = this.byId("imageSupplierContainer");
                        const partContainer = this.byId("imagePartContainer");

                        // Clear existing items in both containers
                        supplierContainer.removeAllItems();
                        partContainer.removeAllItems();

                        // Add "No data found" message strips to each container
                        supplierContainer.addItem(new sap.m.MessageStrip({
                            text: "No Supplier Data Found",
                            type: "Information",
                            showIcon: true,
                            showCloseButton: false
                        }));
                        partContainer.addItem(new sap.m.MessageStrip({
                            text: "No Part Data Found",
                            type: "Information",
                            showIcon: true,
                            showCloseButton: false
                        }));
                        oFooterButtons.setEnabled(true);
                    } else if (typeof filesArray[0] !== 'string' || !filesArray[0].includes("Failed to")) {
                        // Process and update the image containers in parallel if files are found
                        await updateImageContainers.call(this, filesArray);
                    }
                    // isImageLoaded = false;
                    // }
                } catch (error) {
                    oFooterButtons.setEnabled(true);
                    console.error("Error fetching files:", error);
                    // Optionally, display an error message to the user
                    sap.m.MessageToast.show("Error fetching files. Please try again.");
                } finally {
                    busyDialog.close()
                    oFooterButtons.setEnabled(true);
                }
            }
            else {
                initializeWizardStep.call(this, this.byId("CreateVOBWizard"), objectpagelist);
            }
        }


        return Controller.extend("vobwizard.controller.ObjectPage", {
            onInit: function () {
                debugger
                base_url = this.getOwnerComponent()._oManifest._oBaseUri._string;
                // base_url = "/";

            },
            handleNavigationChange: async function (oEvent) {
                debugger
                var wizard_handle = this.byId("CreateVOBWizard");

                // Get the newly selected step from the event
                var oNewStep = oEvent.getParameter("step");

                // Get all steps of the wizard
                var aSteps = wizard_handle.getSteps();

                // Find the index of the newly selected step
                var stepIndex = aSteps.indexOf(oNewStep);
                wizard_handle.discardProgress(oNewStep, false);

                for (var i = stepIndex + 1; i < aSteps.length; i++) {
                    if (i == 1) {
                        continue;
                    }
                    aSteps[i].destroyContent();
                }

                await loadWizardStep.call(this);

            },

            onBeforeRendering: async function (oEvent) {
                debugger
                var url = window.location.hash;
                const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                const matches = url.match(regex);
                var id = matches[1];
                vobidforonafterrendering = id;
                if (id) {
                    console.log(id);
                    if (extractedId != id) {//Checking for same id when navigation happens
                        flag = true;
                    }
                    extractedId = id;// Output: a55567a3-a5a4-4b71-a9e1-858b73ae1cc2
                } else {
                    console.log("ID not found");
                }
                if (flag) {
                    var wizard = this.byId("CreateVOBWizard");
                    var one = wizard.getSteps()[0]
                    wizard.discardProgress(one, false)
                    flag = false;
                    vobId = '';
                } else {
                    debugger
                }
                vobWizard = this.byId("CreateVOBWizard");
                let vobrequest = this.byId("vobrequest");
                let vobsupplier = this.byId("vobsupplier");
                let vobdocument = this.byId("vobdocument");
                let vobapproval = this.byId("vobapproval");
                let oFunction = this.getView().getModel().bindContext("/getStatus(...)");
                oFunction.setParameter("vobid", vobidforonafterrendering);

                // Execute the function call
                await oFunction.execute();

                // Get the result of the status
                var result = oFunction.getBoundContext().getValue().value;
                status_check = result;

                handleWizardButton.call(this);

                if (!vobId) {
                    // Usage
                    isApprovedLoaded = true;
                    initializeWizardStep.call(this, this.byId("CreateVOBWizard"), objectpagelist);
                }

                var supplierContainer = this.byId("imageSupplierContainer").destroyItems();
                var partContainer = this.byId("imagePartContainer").destroyItems();




            },
            onAfterRendering: async function (mBindingInfo) {
                debugger


                const url = window.location.hash;
                const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                const matches = url.match(regex);
                let IsActiveEntity = matches[2];

                if (IsActiveEntity == 'true') {

                    let oFunctionstatus = this.getView().getModel().bindContext("/checkdetailsfilled(...)");

                    oFunctionstatus.setParameter("vobid", vobidforonafterrendering)
                    await oFunctionstatus.execute();
                    var result = oFunctionstatus.getBoundContext().getValue().value;
                    if (result == false) {
                        this.byId("overflowtoolbarwizard").setVisible(false)
                    }
                    else {
                        this.byId("overflowtoolbarwizard").setVisible(true)
                    }
                } else {
                    this.byId("overflowtoolbarwizard").setVisible(false);
                }
            },
            onDialogBackButton: async function (oEvent) {
                debugger;
                vobWizard.previousStep();
                // isApproved = '';
                await loadWizardStep.call(this);


            },

            onDialogNextButton: async function (oEvent) {
                debugger;
                vobWizard.nextStep();
                // isApproved = '';
                await loadWizardStep.call(this);

            },
            onS2UploadSupplier: async function (oEvent) {
                debugger;

                const addUploadedImageToDisplay = (selectedSupplier, base64Supplier, finalName) => {
                    var vboxSupplier = this.byId("imageSupplierContainer");

                    // Check for MessageStrip and remove it if it exists
                    var oMessageStrip = vboxSupplier.getItems().find(item => item instanceof sap.m.MessageStrip);
                    if (oMessageStrip) {
                        vboxSupplier.removeItem(oMessageStrip);
                    }

                    // Format the finalName by replacing the '/' with '(' and appending ')'
                    var formattedFinalName = finalName.replace("/", "(") + ")";

                    var oVbox = new sap.m.VBox({
                        items: [
                            new sap.m.Image({
                                src: "data:image/png;base64," + base64Supplier,
                                width: "100%",
                                height: "auto"
                            }),
                            new sap.m.HBox({
                                items: [
                                    new sap.ui.core.Icon({
                                        src: 'sap-icon://circle-task',
                                        press: function (oEvent) {
                                            var oIcon = oEvent.getSource();
                                            if (oIcon.getSrc() === 'sap-icon://circle-task') {
                                                oIcon.setSrc("sap-icon://bo-strategy-management");
                                            } else {
                                                oIcon.setSrc("sap-icon://circle-task");
                                            }
                                        }
                                    }),
                                    new sap.m.Title({
                                        text: `${formattedFinalName}`,
                                        textAlign: "Center",
                                        wrapping: true,
                                        width: "100%"
                                    })
                                ]
                            })
                        ],
                        alignItems: "Center",
                        justifyContent: "Center",
                        width: "100%"
                    }).addStyleClass("eachImageelement");

                    oVbox.data("fileName", finalName);
                    vboxSupplier.addItem(oVbox);
                };

                // Get the VOB ID from the URL
                var url = window.location.hash;
                const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                const matches = url.match(regex);
                vobId = matches[1];

                // Bind context and fetch supplier part details
                var getSuppPartDetailsS2 = this.oView.getModel().bindContext("/getSuppPartDetailsS2(...)");
                getSuppPartDetailsS2.setParameter("vobid", vobId);
                getSuppPartDetailsS2.setParameter("supOrPart", 'Supplier');
                await getSuppPartDetailsS2.execute();

                var result = getSuppPartDetailsS2.getBoundContext().getValue().value;
                result = JSON.parse(result);
                var supplierlist = result.map(item => item.supplier_name);

                // Create supplier list
                var oSupplierlist = new sap.m.List({
                    mode: "SingleSelect",
                    items: supplierlist.map((supplier) => new sap.m.StandardListItem({ title: supplier })),
                    selectionChange: function (oEvent) {
                        var supplierSelected = oSupplierlist.getSelectedItem();
                        isSupplierNotEmpty = supplierSelected; // Update the state with selected supplier
                    }
                });

                // File uploader
                var oFileUploaderSupplier = new sap.ui.unified.FileUploader({
                    fileType: ['jpg', 'jpeg', 'png'],
                    maximumFileSize: 20,
                    fileSizeExceed: function (oEvent) {
                        debugger
                        MessageToast.show("File size exceeds 20 MB. Please reduce the size of the image.");
                    },
                    change: function (oEvent) {
                        var aFiles = oEvent.getParameter("files");
                        if (aFiles && aFiles.length > 0) {
                            var oFile = aFiles[0];
                            oFileNameSupplier = oFile.name; // Save the file name

                            // Read the file as Base64
                            var oReader = new FileReader();
                            oReader.onload = function (oLoadEvent) {
                                base64Supplier = oLoadEvent.target.result.split(',')[1]; // Extract Base64 data
                                console.log("Base64 Data:", base64Supplier);
                            };
                            oReader.readAsDataURL(oFile);
                        }
                    }
                });

                // Dialog creation
                if (!this._oDialogScreen2) {
                    this._oDialogScreen2 = new Dialog({
                        title: "Upload File",
                        type: DialogType.Message,
                        content: [oFileUploaderSupplier, oSupplierlist],
                        beginButton: new Button({
                            type: ButtonType.Emphasized,
                            text: "Upload",
                            enabled: true,
                            press: async function (oEvent) {
                                debugger
                                if (base64Supplier && isSupplierNotEmpty) {
                                    BusyIndicator.show();

                                    let selectedSupplier = oSupplierlist.getSelectedItem().getTitle();
                                    var finalName = `${selectedSupplier}/${oFileNameSupplier}`;

                                    try {
                                        var response = await $.ajax({
                                            url: `${base_url}odata/v4/vob/uploadFileForVOBSupplierPart`,
                                            type: "POST",
                                            contentType: "application/json",
                                            data: JSON.stringify({
                                                fileName: finalName,
                                                stringbase64: base64Supplier,
                                                path: 'Supplier-Part Images/Supplier',
                                                vobid: vobId
                                            }),
                                        });
                                        if (response?.value?.status === "error" && response?.value?.message?.includes("malware")) {
                                            MessageToast.show("Malware detected in the uploaded file.");
                                        } else {
                                            console.log("File uploaded successfully");
                                            addUploadedImageToDisplay(selectedSupplier, base64Supplier, finalName); // Add image display after upload success
                                        }
                                    } catch (error) {
                                        console.error("Error uploading file", error);
                                        MessageToast.show("Error uploading file. Please try again.");
                                    } finally {
                                        BusyIndicator.hide();
                                        this._oDialogScreen2.close(); // Close dialog after upload
                                        base64Supplier = ''; // Reset states
                                        oFileUploaderSupplier.clear(); // Clear file uploader
                                        // isSupplierNotEmpty = '';
                                        oFileNameSupplier = '';
                                    }
                                } else {
                                    MessageToast.show("Invalid Input");
                                }
                            }.bind(this)
                        }),
                        endButton: new Button({
                            text: "Cancel",
                            press: function (oEvent) {
                                this._oDialogScreen2.close(); // Close dialog on cancel
                            }.bind(this)
                        })
                    });
                }

                this._oDialogScreen2.open(); // Open the dialog for uploading
            },
            onS2UploadPart: async function (oEvent) {
                debugger;

                // Utility function to add uploaded image to display
                const addUploadedImageToDisplay = (selectedPartNo, base64Part, mergedPart, selectPartName) => {
                    debugger
                    var vboxPart = this.byId("imagePartContainer");

                    // Check for MessageStrip and remove it if exists
                    var oMessageStrip = vboxPart.getItems().find(item => item instanceof sap.m.MessageStrip);
                    if (oMessageStrip) {
                        vboxPart.removeItem(oMessageStrip);
                    }

                    var formattedMergedPart = mergedPart.replace("/", "(").replace(/$/, ")")

                    // Create a VBox containing the image and related info
                    var oVbox = new sap.m.VBox({
                        items: [
                            new sap.m.Image({
                                src: "data:image/png;base64," + base64Part,
                                width: "100%",
                                height: "auto"
                            }),
                            new sap.m.HBox({
                                items: [
                                    new sap.ui.core.Icon({
                                        src: 'sap-icon://circle-task',
                                        press: function (oEvent) {
                                            var oIcon = oEvent.getSource();
                                            oIcon.setSrc(oIcon.getSrc() === 'sap-icon://circle-task' ? "sap-icon://bo-strategy-management" : "sap-icon://circle-task");
                                        }
                                    }),
                                    new sap.m.Title({
                                        text: `${formattedMergedPart}`,
                                        textAlign: "Center",
                                        wrapping: true,
                                        width: "100%"
                                    })
                                ]
                            })
                        ],
                        alignItems: "Center",
                        justifyContent: "Center",
                        width: "100%"
                    }).addStyleClass("eachImageelement");

                    oVbox.data("fileName", mergedPart);
                    vboxPart.addItem(oVbox);
                };

                try {
                    // Step 1: Extract VOB ID from the URL
                    var url = window.location.hash;
                    const regex = /vobRequest\(id=([a-zA-Z0-9-]+),IsActiveEntity=(true|false)\)/;
                    const matches = url.match(regex);
                    vobId = matches[1];

                    // Step 2: Fetch Part Details
                    var getSuppPartDetailsS2 = this.oView.getModel().bindContext("/getSuppPartDetailsS2(...)");
                    getSuppPartDetailsS2.setParameter("vobid", vobId);
                    getSuppPartDetailsS2.setParameter("supOrPart", 'Part');
                    await getSuppPartDetailsS2.execute();

                    var result = getSuppPartDetailsS2.getBoundContext().getValue().value;
                    result = JSON.parse(result);

                    var partdetails = result.map(item => ({
                        mgsp_part_nos: item.mgsp_part_nos,
                        applicable_model: item.applicable_model
                    }));

                    // Step 3: Set up JSON model for parts
                    var oModel = new sap.ui.model.json.JSONModel({ parts: partdetails });

                    // Step 4: Create Part List
                    var oPartList = new sap.m.List({
                        mode: "SingleSelect",
                        items: {
                            path: "partModel>/parts",
                            template: new sap.m.StandardListItem({
                                title: "{partModel>mgsp_part_nos}"
                            })
                        },
                        selectionChange: function (oEvent) {
                            var partSelected = oPartList.getSelectedItem();
                            isPartNotEmpty = partSelected; // Update the state with selected part
                        }
                    }).setModel(oModel, "partModel");

                    // Step 5: File Uploader Setup
                    var oFileUploaderPart = new sap.ui.unified.FileUploader({
                        fileType: ['jpg', 'jpeg', 'png'],
                        maximumFileSize: 20,
                        fileSizeExceed: function (oEvent) {
                            debugger
                            MessageToast.show("File size exceeds 20 MB. Please reduce the size of the image.");
                        },
                        change: function (oEvent) {
                            var aFiles = oEvent.getParameter("files");
                            oFileNamePart = aFiles[0].name;

                            if (aFiles && aFiles.length > 0) {
                                var oFile = aFiles[0];
                                var oReader = new FileReader();

                                oReader.onload = function (oLoadEvent) {
                                    base64Part = oLoadEvent.target.result.split(',')[1]; // Extract Base64 data
                                };

                                oReader.readAsDataURL(oFile);
                            }
                        }
                    });

                    // Step 6: Dialog Creation
                    var oDialogScreen2;
                    if (!oDialogScreen2) {
                        oDialogScreen2 = new Dialog({
                            title: "Upload File",
                            type: DialogType.Message,
                            content: [oFileUploaderPart, oPartList],
                            beginButton: new Button({
                                type: ButtonType.Emphasized,
                                text: "Upload",
                                press: async function () {
                                    if (base64Part && isPartNotEmpty) {
                                        BusyIndicator.show();

                                        let selectedPartNo = oPartList.getSelectedItem().getTitle();
                                        let selectPartName = oPartList.getSelectedItem().getBindingContext("partModel").getProperty("applicable_model") ?? '';
                                        let mergedPart = `${selectedPartNo}-${selectPartName}/${oFileNamePart}`;

                                        try {
                                            // Step 7: File Upload Process
                                            var response = await $.ajax({
                                                url: `${base_url}odata/v4/vob/uploadFileForVOBSupplierPart`,
                                                type: "POST",
                                                contentType: "application/json",
                                                data: JSON.stringify({
                                                    fileName: mergedPart,
                                                    stringbase64: base64Part,
                                                    path: 'Supplier-Part Images/Parts',
                                                    vobid: vobId
                                                }),
                                            });

                                            if (response?.value?.status == "error" && response?.value?.message?.includes("malware")) {
                                                MessageToast.show("Malware detected in the uploaded file.");
                                            } else {
                                                console.log("File uploaded successfully");
                                                addUploadedImageToDisplay(selectedPartNo, base64Part, mergedPart, selectPartName); // Add image display after upload success
                                            }

                                            // Reset variables
                                            base64Part = '';
                                            isPartNotEmpty = '';
                                            oFileNamePart = '';

                                        } catch (error) {
                                            console.error("Error uploading file", error);
                                            MessageBox.error("Error uploading file");
                                        } finally {
                                            BusyIndicator.hide();
                                            oDialogScreen2.close();
                                        }
                                    } else {
                                        MessageToast.show("Invalid Input");
                                    }
                                }.bind(this)
                            }),
                            endButton: new Button({
                                text: "Cancel",
                                press: function () {
                                    // Reset variables
                                    base64Part = '';
                                    isPartNotEmpty = '';
                                    oFileNamePart = '';
                                    oDialogScreen2.close();
                                }.bind(this)
                            })
                        });
                    }

                    oDialogScreen2.open(); // Open dialog for file upload
                } catch (error) {
                    console.log("Error in onS2UploadPart:", error);
                    MessageBox.error("An error occurred while fetching part details or opening the dialog.");
                } finally {
                    BusyIndicator.hide(); // Hide busy indicator after processing
                }
            },
            onS2DeletePart: async function (oEvent) {
                var that = this;
                MessageBox.confirm("Are you sure you want to delete?", {
                    onClose: async function (status) {
                        if (status == 'OK') {
                            var vboxPart = that.byId("imagePartContainer");
                            var vBoxItems = vboxPart.getItems();
                            var deletePromises = []; // To hold all the delete operations

                            BusyIndicator.show(); // Show busy indicator

                            // Helper function to format part name
                            function formatPartName(partName) {
                                let finalName;
                                if (partName.includes("BTP/")) {
                                    const parts = partName.split("/");
                                    const supplierPartIndex = parts.indexOf("Supplier-Part Images");
                                    if (supplierPartIndex !== -1) {
                                        finalName = parts.slice(supplierPartIndex).join("/");
                                    } else {
                                        finalName = "Supplier-Part Images/" + partName;
                                    }
                                } else {
                                    finalName = `Supplier-Part Images/Parts/${partName}`;
                                }
                                return finalName;
                            }

                            // Helper function to delete file asynchronously
                            async function deleteFile(finalName) {
                                let oFunction = that.getView().getModel().bindContext("/deleteFileForVOBSupplierPart(...)");
                                oFunction.setParameter("fileName", finalName);
                                oFunction.setParameter("vobid", vobId);  // Use the global vobId
                                await oFunction.execute();
                            }

                            // Loop through each VBox item
                            try {
                                for (let i = 0; i < vBoxItems.length; i++) {
                                    var partName = vBoxItems[i]?.data("fileName");
                                    let iconStatus = vBoxItems[i]?.getItems()[1].getItems()[0].getSrc() ?? '';

                                    if (partName && iconStatus) {
                                        let finalName = formatPartName(partName);
                                        if (iconStatus === 'sap-icon://bo-strategy-management') {
                                            deletePromises.push(deleteFile(finalName));  // Add the delete operation to the array
                                        }
                                    }
                                }

                                // Wait for all delete operations to finish
                                await Promise.all(deletePromises);

                                // After successful deletion, show success message and remove items from VBox
                                MessageToast.show("Files deleted successfully.");
                                for (let i = 0; i < vBoxItems.length; i++) {
                                    var partName = vBoxItems[i]?.data("fileName");
                                    let iconStatus = vBoxItems[i]?.getItems()[1].getItems()[0].getSrc() ?? '';
                                    if (partName && iconStatus && iconStatus === 'sap-icon://bo-strategy-management') {
                                        vboxPart.removeItem(vBoxItems[i]);
                                    }
                                }

                            } catch (error) {
                                console.error("Error deleting files:", error);
                                MessageToast.show("Error deleting files. Please try again.");
                            } finally {
                                BusyIndicator.hide();  // Ensure BusyIndicator is hidden after operations
                            }
                        }
                    }
                });
            },
            onS2DeleteSupplier: async function (oEvent) {
                var that = this;
                MessageBox.confirm("Are you sure you want to delete?", {
                    onClose: async function (status) {
                        if (status == 'OK') {
                            var vboxSupplier = that.byId("imageSupplierContainer");
                            var vBoxItems = vboxSupplier.getItems();
                            var deletePromises = []; // To hold all the delete operations

                            BusyIndicator.show(); // Show busy indicator

                            // Helper function to format supplier name
                            function formatSupplierName(supplierName) {
                                let finalName;
                                if (supplierName.includes("BTP/")) {
                                    const parts = supplierName.split("/");
                                    const supplierPartIndex = parts.indexOf("Supplier-Part Images");
                                    if (supplierPartIndex !== -1) {
                                        finalName = parts.slice(supplierPartIndex).join("/");
                                    } else {
                                        finalName = "Supplier-Part Images/" + supplierName;
                                    }
                                } else {
                                    finalName = `Supplier-Part Images/Supplier/${supplierName}`;
                                }
                                return finalName;
                            }

                            // Helper function to delete file asynchronously
                            async function deleteFile(finalName) {
                                let oFunction = that.getView().getModel().bindContext("/deleteFileForVOBSupplierPart(...)");
                                oFunction.setParameter("fileName", finalName);
                                oFunction.setParameter("vobid", vobId);  // Use the global vobId
                                await oFunction.execute();
                            }

                            // Loop through each VBox item
                            try {
                                for (let i = 0; i < vBoxItems.length; i++) {
                                    var supplierName = vBoxItems[i]?.data("fileName");
                                    let iconStatus = vBoxItems[i]?.getItems()[1].getItems()[0].getSrc() ?? '';

                                    if (supplierName && iconStatus) {
                                        let finalName = formatSupplierName(supplierName);
                                        if (iconStatus === 'sap-icon://bo-strategy-management') {
                                            deletePromises.push(deleteFile(finalName));  // Add the delete operation to the array
                                        }
                                    }
                                }

                                // Wait for all delete operations to finish
                                await Promise.all(deletePromises);

                                // After successful deletion, show success message and remove items from VBox
                                MessageToast.show("Files deleted successfully.");
                                for (let i = 0; i < vBoxItems.length; i++) {
                                    var supplierName = vBoxItems[i]?.data("fileName");
                                    let iconStatus = vBoxItems[i]?.getItems()[1].getItems()[0].getSrc() ?? '';
                                    if (supplierName && iconStatus && iconStatus === 'sap-icon://bo-strategy-management') {
                                        vboxSupplier.removeItem(vBoxItems[i]);
                                    }
                                }

                            } catch (error) {
                                console.error("Error deleting files:", error);
                                MessageToast.show("Error deleting files. Please try again.");
                                BusyIndicator.hide();
                            } finally {
                                BusyIndicator.hide();  // Ensure BusyIndicator is hidden after operations
                            }
                        }
                    }
                });
            }
        });
    });
