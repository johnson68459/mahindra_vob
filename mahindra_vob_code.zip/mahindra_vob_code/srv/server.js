const cds = require('@sap/cds');
const express = require('express');
const cors = require('cors');
const axios = require('axios');

cds.on('bootstrap', (app) => {
    const expressApp = express();
    const corsOptions = {
        origin: '*',
        optionsSuccessStatus: 200
    };

    expressApp.use(cors(corsOptions));

    expressApp.get('/api/publicIsValid', async (req, res) => {
        const email = req.query.email; // Get email from query parameters

        if (!email) {
            return res.status(400).json({ error: 'Email parameter is required.' });
        }

        try {
            // Call the VOBService and retrieve data from the vobMain entity
            const vobService = await cds.connect.to('VOBService'); // Ensure the service is connected

            // Modify the SELECT statement to filter by email
            const vobData = await vobService.run(SELECT.from('Master_workflow').where({ employee_id: email })); // Use the email in the filter

            // Example master data check (replace this with your actual check)
            const masterData = vobData.length > 0 ? vobData[0] : null; // Replace with actual master data retrieval logic

            if (masterData) { // Check if master data has a value
                // Retrieve clientId and clientSecret from environment variables
                const xsuaaCredentials = process.env.VCAP_SERVICES; // Ensure this is set in your environment
                const parsedCredentials = JSON.parse(xsuaaCredentials);

                const clientId = parsedCredentials.xsuaa[0].credentials.clientid;
                const clientSecret = parsedCredentials.xsuaa[0].credentials.clientsecret;
                const tokenurl = parsedCredentials.xsuaa[0].credentials.url;

                // Encode clientId and clientSecret in Base64
                const base64Credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

                // Setup request to obtain token
                const tokenSettings = {
                    url: tokenurl + "/oauth/token?grant_type=client_credentials",
                    method: "GET",
                    headers: {
                        "Authorization": `Basic ${base64Credentials}`, // Set Basic Auth header
                    },
                };

                // Make the HTTP request to obtain the token
                const tokenResponse = await axios(tokenSettings);

                // If token obtained successfully
                res.json({
                    message: 'Token obtained successfully.',
                    token: tokenResponse.data.access_token, // Return the obtained token if needed
                    data: vobData // Include the data retrieved from the service
                });
            } else {
                res.status(401).json({ error: 'Unauthorized: Master data is invalid or not present.' });
            }
        } catch (error) {
            console.error('Error retrieving data or obtaining token:', error);
            // Handle errors (unauthorized or invalid user)
            if (error.response && error.response.status === 401) {
                res.status(401).json({ error: 'Unauthorized: Invalid user or credentials.' });
            } else {
                res.status(500).json({ error: 'Failed to retrieve data or obtain token.' });
            }
        }
    });

    app.use((req, res, next) => {
        // Middleware for other routes
        next();
    });

    app.use(expressApp);
});

// Export the cds server
module.exports = cds.server;
