const cds = require('@sap/cds');
const { Storage } = require('@google-cloud/storage');
const { jwtDecode } = require('jwt-decode');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

module.exports = cds.service.impl(async function () {
    var BPA = await cds.connect.to("vobBpaTrigger");

    console.log("check " + process.env.NODE_ENV);

    // Check if the app is running in production
    if (process.env.NODE_ENV === 'production') {
        const xsuaaCredentials = process.env.VCAP_SERVICES;
        var afterstringy = JSON.parse(xsuaaCredentials);

        const vapplication = process.env.VCAP_APPLICATION;
        const afterstringyvapplication = JSON.parse(vapplication);

        var urlapp = afterstringyvapplication.application_uris[0];
        var finalurlapp = "https://" + `${urlapp}`;

        console.log("urlapp=" + `${urlapp}`);
        console.log("finalurlapp=" + `${finalurlapp}`);
    } else {
        console.log("Not in production, skipping this logic.");
    }


    let { vobDocument, vobMain, YOY, potentialSuplier, comment, supplierdetails, Workflow_History, Files, vobRequest, vendorsearchhelp, materialsearchhelp, Sector_searchhelp, Incoterm_searchhelp, PaymentTerm_searchhelp, Master_workflow, Approvers } = this.entities;

    const bucketName = process.env.bucketName || 'sapprdshare';
    const basepath = 'BTP/VOB Details/';
    const basepathvob = basepath;
    // const basepathvob = 'BTP/VOB Details/';

    let currentSubaccount = subaccount = process.env.SUBACCOUNT;
    let RemoteRD2;

    if (currentSubaccount == 'DEV') {
        console.log("RD2 System")
        RemoteRD2 = await cds.connect.to('RemoteRD2');
    }
    else if (currentSubaccount == 'UAT') {
        console.log("RQ2 System")
        RemoteRD2 = await cds.connect.to('RemoteRQ2');
    }
    else if (currentSubaccount == 'PROD') {
        console.log("RP2 System")
        RemoteRD2 = await cds.connect.to('RemoteRP2');
    }
    else {
        console.log("SUBACCOUNT env variable not created");
        RemoteRD2 = await cds.connect.to('RemoteRD2');
    }



    function newStorageCall() {

        var typeofGCP = typeof (process.env.GCP);
        var GCP_key;
        var raw_GCP_key = process.env.GCP;

        if (typeofGCP == 'string') {
            try {
                GCP_key = JSON.parse(raw_GCP_key);  // Safely parse the string
                console.log("GCP key is a string");
            } catch (error) {
                console.log('Failed to parse GCP credentials from environment:', error);
                // throw new Error('GCP credentials in environment are not valid JSON.');
            }
        } else {
            GCP_key = raw_GCP_key;  // Use directly if it's already an object
            console.log("GCP key is a object");
        }



        return new Storage({
            projectId: GCP_key.project_id,
            credentials: {
                client_email: GCP_key.client_email,
                private_key: GCP_key.private_key
            }
        });
    }

    //YOY

    this.before('CREATE', YOY.drafts, async (req) => {
        try {
            var details = await SELECT.from(YOY.drafts).where({ vob_id: req.data.vob_id });

            // Check if the number of parts is already at the maximum limit
            if (details.length == 30) {
                return req.error({
                    message: 'Maximum of Thirty Parts allowed',
                    status: 400
                });
            }

            // You may add additional logic here if needed

        } catch (error) {
            // Handle any errors that occurred during the execution
            console.error("error in yoy.drafts create", error);
        }
    });

    this.on('UPDATE', YOY.drafts, async (req, next) => {
        // console.log('red');

        try {
            // Regex to match text enclosed in '<' and '>' symbols
            const invalidPattern = /<[^>]*>/;

            // Fields to validate
            const fieldsToValidate = ['proposed_vf_part_no', 'applicable_model'];

            for (const field of fieldsToValidate) {
                const fieldValue = req.data[field] || "";

                // Validate only if fieldValue has a value
                if (fieldValue && invalidPattern.test(fieldValue)) {
                    return req.error({
                        message: `The "${field}" field contains invalid characters. Please remove any text enclosed within '<' and '>' symbols.`,
                        status: 400
                    });
                }
            }

            if (req.data.mgsp_part_nos) {
                // Fetch the current draft details based on the provided ID
                var details = await SELECT.from(YOY.drafts).where({ id: req.data.id });
                // Fetch all drafts with the same vob_id
                var data = await SELECT.from(YOY.drafts).where({ vob_id: details[0].vob_id });

                // Check if the mgsp_part_nos is unique among the fetched drafts
                for (const item of data) {
                    if (item.id != req.data.id && item.mgsp_part_nos == req.data.mgsp_part_nos) {
                        return req.error({
                            message: 'Part Number should be Unique',
                            status: 400
                        });
                        // console.log(req.data);
                        // return; // Return to stop further processing
                    }

                }
            }
            return next(); // Proceed to the next middleware if no errors
        } catch (error) {
            // Handle any unexpected errors that occurred during the execution
            console.error("error in yoy.drafts update", error);
        }
    });

    //potentialSuplier

    this.before("DELETE", potentialSuplier.drafts, async (req) => {
        try {
            debugger;

            // Fetch the supplier to be deleted
            var deleted_supplier = await SELECT.from(potentialSuplier.drafts).where({ id_main: req.data.id_main });

            // Extract supplier_id from the request
            var supplier_id = req.data.id_main;

            // Fetch YOY details related to the supplier
            var yoy_details = await SELECT.from(YOY.drafts).where({ vob_id: deleted_supplier[0].vob_id });

            console.log("delete triggered");

            // Loop through yoy_details to find records with the matching supplier_id 
            // and update the supplierid to an empty string to reset the color indicator 
            // on the VOB supplier screen.
            yoy_details.forEach(async (detail) => {
                if (detail.supplierid == supplier_id) {

                    // Update the record in the database
                    await UPDATE(YOY.drafts).set({ supplierid: '' }).where({ id: detail.id });
                }
            });

        } catch (error) {
            console.error("Error in potentialSuplier.drafts during DELETE operation:", error);
            // You can handle or throw the error as needed
            // throw error; // Optionally rethrow the error if further action is needed
        }
    });

    this.before('CREATE', potentialSuplier.drafts, async (req) => {
        try {
            var details = await SELECT.from(potentialSuplier.drafts).where({ vob_id: req.data.vob_id });

            // Check if the number of suppliers is already at the maximum limit
            if (details.length >= 5) {
                return req.error({
                    message: 'Maximum of Five Suppliers allowed',
                    code: 'Invalid',
                    status: 400
                });
            }

            // You may add additional logic here if needed

        } catch (error) {
            // Handle any errors that occurred during the execution
            // return req;
            console.error("error in potentialSuplier.drafts create", error);
        }
    });

    this.on('UPDATE', potentialSuplier.drafts, async (req, next) => {
        try {

            var invalidPattern = /<[^>]*>/;

            // Fields to validate
            const fieldsToValidate = ['supplier_name', 'supplier_location', 'supplier_id', 'supplier_assessment_score'];

            for (const field of fieldsToValidate) {
                const fieldValue = req.data[field] || "";

                // Check if the field contains the invalid pattern
                if (invalidPattern.test(fieldValue)) {
                    return req.error({
                        message: `The "${field}" field contains invalid characters. Please remove any text enclosed within '<' and '>' symbols.`,
                        status: 400
                    });
                }
            }

            // var invalidCharacters = `><?:;~!@#$%^*'_()+=/`; // Invalid characters list
            // var alphanumericRegex = /^[^><\?:;~!@#$%^*'_()\+=/]+$/;

            // // Fields to validate
            // const fieldsToValidate = ['supplier_name', 'supplier_location', 'supplier_id'];

            // for (const field of fieldsToValidate) {
            //     const fieldValue = req.data[field] || "";

            //     // Validate only if fieldValue has a value
            //     if (fieldValue && !alphanumericRegex.test(fieldValue)) {
            //         return req.error({
            //             message: `Invalid input. The following characters are not allowed: ${invalidCharacters}`,
            //             status: 400
            //         });
            //     }
            // }

            // var alphanumericRegex = /^[^><\?:;~!@#$^*'_()\+=/]+$/;
            // var invalidCharacters = `><?:;~!@#$^*'_()+=/`; // Invalid characters list

            // if (req.data.supplier_assessment_score) {

            //     let fieldValue = req.data.supplier_assessment_score

            //     // Validate only if fieldValue has a value
            //     if (fieldValue && !alphanumericRegex.test(fieldValue)) {
            //         return req.error({
            //             message: `Invalid input. The following characters are not allowed: ${invalidCharacters}`,
            //             status: 400
            //         });
            //     }

            // }

            // Fields to validate


            if (req.data.supplier_id) {
                // Fetch the current draft details based on the provided id_main
                var details = await SELECT.from(potentialSuplier.drafts).where({ id_main: req.data.id_main });
                // Fetch all drafts with the same vob_id
                var data = await SELECT.from(potentialSuplier.drafts).where({ vob_id: details[0].vob_id });

                // Check if the supplier_id is unique among the fetched drafts
                for (const item of data) {
                    if (item.id_main != req.data.id_main && item.supplier_id == req.data.supplier_id) {
                        return req.error({
                            message: 'Suppliers Should be Unique',
                            status: 400
                        });
                        // console.log(req.data);
                        // return; // Stop further processing
                    }
                }
            }
            // if (req.data.supplier_assessment_score) {
            //     let score = req.data.supplier_assessment_score;

            //     // Regular expression to check if the score is a valid percentage (0% to 100% including decimals)
            //     const percentagePattern = /^(100(\.0+)?|[0-9]{1,2}(\.[0-9]+)?)(%)$/;

            //     // Check if the score matches the pattern
            //     if (percentagePattern.test(score)) {
            //         // Valid percentage format
            //         console.log(`Valid score: ${score}`);

            //         // Proceed with further processing
            //     } else {
            //         // Invalid percentage format
            //         console.log(`Invalid score format: ${score}. Please enter a score in the format '30%', '100%', '0.5%', etc.`);
            //         return req.error({
            //             message: `Invalid score format: ${score}. Please enter a score in the format '30%', '100%', '0.5%', etc.`,
            //             status: 400
            //         });
            //         // Handle the error (e.g., send a response back, throw an error, etc.)
            //     }
            // }

            return next(); // Proceed to the next middleware if no errors
        } catch (error) {
            // Handle any unexpected errors that occurred during the execution
            console.error("error in potentialSuplier.drafts update", error);
        }
    });

    //vobRequest

    this.before("SAVE", vobRequest, async (req, next) => {
        try {
            var supplier_details = await SELECT.from(potentialSuplier.drafts).where({ vob_id: req.data.id });
            var yoy_details = await SELECT.from(YOY.drafts).where({ vob_id: req.data.id });
            // var workflow_data = await SELECT.from(Workflow_History.drafts).where({ vob_id: req.data.id, level: { '!=': '0' } });

            console.log("Supplier Details fetched")

            // Validation for supplier details
            for (let item of supplier_details) {
                if (item.supplier_id == null || item.supplier_id == undefined) {
                    return req.error({
                        message: 'Supplier details should not be empty',
                        code: 'Invalid',
                        status: 400
                    });
                }
            }

            // Validation for MGSP part numbers in yoy_details
            for (let item of yoy_details) {
                if (item.mgsp_part_nos == null || item.mgsp_part_nos == undefined) {
                    return req.error({
                        message: 'MGSP Part Number Should Not be Empty',
                        code: 'Invalid',
                        status: 400
                    });
                }
            }

            // Ensure minimum of two suppliers are provided
            if (supplier_details.length < 2) {
                return req.error({
                    message: 'Minimum of two suppliers required',
                    code: 'Invalid',
                    status: 400
                });
            }

            // Ensure minimum of one part is provided
            if (yoy_details.length < 1) {
                return req.error({
                    message: 'Minimum of one part required',
                    code: 'Invalid',
                    status: 400
                });
            }

            // Call next() if all validations pass
            next();
        } catch (error) {
            // Handle any errors that occurred during the execution
            // return req;
            console.error("error in vobRequest save", error);
            // throw(error);
        }
    });

    this.on('UPDATE', vobRequest.drafts, async (req, next) => {

        console.log("inside vobrequest");

        // Regular expression to check for alphanumeric text
        var alphanumericRegex = /^[^><\?:;~!@#$%^*'_()\+=/]+$/;

        // Fields to validate
        const fieldsToValidate = ['sop', 'part_system', 'project_code_description'];

        for (const field of fieldsToValidate) {
            const fieldValue = req.data[field] || "";

            // Validate only if fieldValue has a value
            if (fieldValue && !alphanumericRegex.test(fieldValue)) {
                return req.error({
                    message: `The "${field}" field must contain only alphanumeric characters.`,
                    status: 400
                });
            }
        }
        return next();
    });

    //Master_workflow
    this.before('CREATE', Workflow_History.drafts, async (req) => {
        try {
            var details = await SELECT.from(Workflow_History.drafts).where({ vob_id: req.data.vob_id, level: { '!=': '0' } });
            console.log("test");

            // Check if the number of approvers is already at the maximum limit
            if (details.length >= 5) {
                return req.error({
                    message: 'Maximum of Five Approvers allowed',
                    code: 'Invalid',
                    status: 400
                });
            }

            // You may add additional logic here if needed

        } catch (error) {
            // Handle any errors that occurred during the execution
            // return req;
            console.error("error in Workflow_History.drafts create", error);
        }
    });


    //Files
    this.before('CREATE', Files, async (req) => {
        try {
            console.log('Create called');
            console.log(JSON.stringify(req.data));

            // Check if ID is present in req.data
            if (!req.data.ID) {
                console.log("Id is not present in Files create");
            }

            // Set the URL property based on the provided ID
            req.data.url = `/odata/v4/vob/Files(${req.data.ID})/content`;

            // Additional logic can be added here if needed

        } catch (error) {
            // Handle any unexpected errors that occurred during execution
            console.error("error in files create", error);
        }
    });


    this.before('READ', vendorsearchhelp, async (req) => {
        try {
            let vendordata_array;
            const reqParams = req._queryOptions;
            console.log("ReqParams", JSON.stringify(reqParams))

            // Check if the environment is production and fetch data accordingly
            await DELETE.from(vendorsearchhelp);
            if (process.env.NODE_ENV === 'production') {
                if (req._queryOptions?.$filter) { // Check for $filter in query options
                    var filter = req._queryOptions.$filter;

                    if (filter.startsWith("contains")) {
                        debugger;

                        // Extract value within single quotes using RegEx
                        let match = filter.match(/'([^']+)'/);
                        if (match?.[1]) { // Optional chaining for safety
                            let extractedValue = match[1];
                            odataUrl = `/sap/opu/odata/sap/C_SUPPLIER_FS_SRV/C_Suppliercontracts?$select=Supplier,SupplierName,AddressID&$filter=substringof('${extractedValue}', Supplier) or substringof('${extractedValue}', SupplierName) or substringof('${extractedValue}', AddressID)&$top=500`;
                            console.log("Odata URL Filter:", odataUrl);
                            console.log("Extracted Value:", extractedValue);
                        } else {
                            console.log("No value found in the filter.");
                        }
                    }
                }
                if (reqParams && reqParams.$search) {
                    // Remove surrounding quotes if present
                    const searchValue = reqParams.$search.replace(/^"|"$/g, '').trim();

                    // Escape single quotes and encode for OData
                    const filterValue = encodeURIComponent(searchValue.replace(/'/g, "''"));

                    odataUrl = `/sap/opu/odata/sap/C_SUPPLIER_FS_SRV/C_Suppliercontracts?$select=Supplier,SupplierName,AddressID&$filter=substringof('${filterValue}', Supplier) or substringof('${filterValue}', SupplierName) or substringof('${filterValue}', AddressID)&$top=500`;
                    console.log("ODataURlVendor", odataUrl);
                } else {
                    odataUrl = `/sap/opu/odata/sap/C_SUPPLIER_FS_SRV/C_Suppliercontracts?$select=Supplier,SupplierName,AddressID&$top=500`;
                }
                vendordata_array = await RemoteRD2.tx(req).get(odataUrl);
                // vendordata_array = await RemoteRD2.tx(req).get(odataUrl);



                console.log("Vendor data from s/4", JSON.stringify(vendordata_array));
            } else {
                vendordata_array = [
                    { "Supplier": "35011554", "SupplierName": "UNIVERSAL ABRASIVES", "AuthorizationGroup": "", "SupplierAccountGroup": "LIEF", "IsBusinessPurposeCompleted": "" },
                    { "Supplier": "35011426", "SupplierName": "SKYKING INSTRUMENTS PVT. LTD.", "AuthorizationGroup": "", "SupplierAccountGroup": "LIEF", "IsBusinessPurposeCompleted": "" }
                ];
            }

            // Delete existing vendor data


            // Prepare the vendor data for insertion
            const vendordata = vendordata_array.map((entity) => ({
                lifnr: entity.Supplier,          // Map "Supplier" to "lifnr"
                name: entity.SupplierName,       // Map "SupplierName" to "name"
                ort: entity.AddressID // Map "SupplierAccountGroup" to "ort" (or another appropriate value if needed)
            }));

            // Insert the new vendor data
            await INSERT.into(vendorsearchhelp).entries(vendordata);

            // Optional: console log for testing purposes
            console.log("Vendor data successfully processed");

        } catch (error) {
            // Error handling
            console.error("Error in before READ handler for vendorsearchhelp:", JSON.stringify(error));
            // throw new Error("Failed to process vendor search help data. Please try again later.");
        }
    });


    this.before('READ', materialsearchhelp, async (req) => {
        try {
            const reqParams = req._queryOptions;
            await DELETE.from(materialsearchhelp);

            if (process.env.NODE_ENV === 'production') {

                if (req._queryOptions?.$filter) { // Check for $filter in query options
                    var filter = req._queryOptions.$filter;

                    if (filter.startsWith("contains")) {
                        debugger;

                        // Extract value within single quotes using RegEx
                        let match = filter.match(/'([^']+)'/);
                        if (match?.[1]) { // Optional chaining for safety
                            let extractedValue = match[1];
                            odataUrl = `/sap/opu/odata/sap/MMIM_MATERIAL_DATA_SRV/I_InvtryMgmtMatlMstrVH?$select=Material&$filter=substringof('${extractedValue}', Material)&$top=500`;
                            console.log("Extracted Value:", extractedValue);
                        } else {
                            console.log("No value found in the filter.");
                            return;
                        }
                    }
                }



                if (reqParams && reqParams.$search) {
                    console.log("Material filter", JSON.stringify(reqParams));
                    const searchValue = reqParams.$search.replace(/^"|"$/g, '').trim();

                    // Escape single quotes and encode for OData
                    const filterValue = encodeURIComponent(searchValue.replace(/'/g, "''"));
                    // const filterValue = encodeURIComponent(reqParams.$search.replace(/'/g, "''")); // Escape single quotes
                    odataUrl = `/sap/opu/odata/sap/MMIM_MATERIAL_DATA_SRV/I_InvtryMgmtMatlMstrVH?$select=Material&$filter=substringof('${filterValue}', Material)&$top=500`;
                } else {
                    odataUrl = `/sap/opu/odata/sap/MMIM_MATERIAL_DATA_SRV/I_InvtryMgmtMatlMstrVH?$top=500`;
                }

                var materialsearchhelp_data = await RemoteRD2.tx(req).get(odataUrl);
                // var materialsearchhelp_data = await RemoteRD2.tx(req).get(odataUrl);
                console.log("Material data from s/4", JSON.stringify(materialsearchhelp_data));
            }
            else {
                materialsearchhelp_data = [
                    {
                        "Material": "000A973",
                        "MaterialName": "SETSCREW",
                        "Plant": "A016"
                    },
                    {
                        "Material": "000A972",
                        "MaterialName": "HANDLE SHIFT LEVER",
                        "Plant": "A016"
                    }
                ];
            }
            const materialserialdata_array = materialsearchhelp_data.map(item => ({
                materialname: `${item.Material}` // Map `Material` from API to `materialname` in the DB
            }));

            // Insert the processed data into the `materialsearchhelp` entity
            await INSERT.into(materialsearchhelp).entries(materialserialdata_array);
        } catch (error) {
            // Handle and log errors
            console.error("Error in before READ handler for materialsearchhelp:", error.message);
            // throw new Error("Failed to process material search help data. Please try again later.");
        }
    });

    //VOB Wizard List Calls
    this.on('createEntry', async (req) => {
        try {
            debugger;
            var yoydata = req.data.status;

            async function generateVOBID() {
                const currentDate = new Date();
                let fiscalYear;

                // Fiscal year starts in April and ends in March of the next calendar year
                const currentYear = currentDate.getFullYear();
                const currentMonth = currentDate.getMonth() + 1;  // Months are 0-indexed

                // Determine fiscal year based on the month
                if (currentMonth >= 4) {
                    fiscalYear = currentYear + 1; // Set to next year for April and beyond
                } else {
                    fiscalYear = currentYear; // Set to current year for Jan, Feb, and March
                }

                // Get the running number for this fiscal year
                let runningNumber = await getRunningNumberForFiscalYear(fiscalYear);

                // Ensure runningNumber is padded with leading zeros to be 5 digits
                const runningNumberPadded = String(runningNumber).padStart(5, '0');

                // Generate VOB ID in the format: FYXX-VOB-YYYY (e.g., FY25-VOB-00001)
                const vobID = `FY${String(fiscalYear).slice(-2)}-VOB-${runningNumberPadded}`;

                return vobID;
            }

            // Function to get or initialize the running number for the specified fiscal year
            async function getRunningNumberForFiscalYear(fiscalYear) {
                // Fetch running number and last fiscal year from the database
                let runningNumberData = await SELECT.from(comment).where({ id_com: 'runningNumber' });
                let lastFiscalYearData = await SELECT.from(comment).where({ id_com: 'lastFiscalYear' });

                // If no records exist, initialize them
                if (!runningNumberData.length || !lastFiscalYearData.length) {
                    await INSERT.into(comment).entries({ id_com: 'runningNumber', comment: '1' });
                    await INSERT.into(comment).entries({ id_com: 'lastFiscalYear', comment: `${fiscalYear}` });
                    console.log("First Running Number is created for new fiscal year");
                    return 1;
                }

                // Parse stored data
                let runningNumber = parseInt(runningNumberData[0].comment);
                let lastFiscalYear = parseInt(lastFiscalYearData[0].comment);

                // If the fiscal year has changed, reset the running number to 1 and update lastFiscalYear
                if (lastFiscalYear !== fiscalYear) {
                    await UPDATE(comment, { id_com: 'runningNumber' }).with({ comment: '1' });
                    await UPDATE(comment, { id_com: 'lastFiscalYear' }).with({ comment: `${fiscalYear}` });
                    console.log("New fiscal year detected. Running number reset to 1.");
                    return 1;
                }

                // Increment the running number for the current fiscal year
                let updatedRunningNumber = runningNumber + 1;
                await UPDATE(comment, { id_com: 'runningNumber' }).with({
                    comment: `${updatedRunningNumber}`
                });

                return updatedRunningNumber;
            }


            var seqvobID = await generateVOBID();
            console.log(seqvobID);  // Output example: FY24-VOB-00026

            if (req.data.status == 'vobpost') {
                let data = await INSERT.into(vobRequest).entries({ project_code: '', sequentialvobid: seqvobID });

                // Retrieve the latest inserted row by ordering by `createdAt` in descending order
                let data1 = await SELECT.from(vobRequest).orderBy('createdAt desc').limit(1);

                return data1[0].id; // The first result will be the latest inserted record
            }

        } catch (error) {
            // Error handling
            console.error("Error in createEntry handler:", error.message);
            // throw new Error("Failed to create the entry. Please check your input and try again.");
        }
    });

    this.on('deleteEntry', async (req) => {
        try {
            let result = req.data.keyid;

            // Parse the result string as an array
            result = JSON.parse(result);

            // Iterate over the array and check status before deletion
            for (let i = 0; i < result.length; i++) {
                const entryId = result[i];

                // Step 1: Retrieve the entry to check its status
                const vobEntry = await SELECT.one.from(vobRequest).where({ id: entryId });

                // Proceed if vobEntry exists
                if (vobEntry) {
                    // Check if the status is "pending for approval"
                    if (vobEntry.flowstatus === 'Pending For Approval') {
                        console.log(`Entry with id ${entryId} is pending for approval, skipping deletion.`);
                    } else {
                        // Proceed to delete if status is not "pending for approval"
                        await DELETE.from(vobRequest).where({ id: entryId });
                        await DELETE.from(Approvers).where({ vob_id: entryId });
                        console.log(`Deleted entry with id ${entryId}.`);
                    }
                } else {
                    console.log(`No entry found with id ${entryId}, skipping deletion.`);
                }
            }

            console.log("Deletion process completed.");

        } catch (error) {
            // Error handling
            console.error("Error in deleteEntry handler:", error.message);
            // Optionally, throw a custom error
            // throw new Error("Failed to delete the requested entries. Please try again.");
        }
    });

    this.on("getCurrentLevel", async (req) => {
        try {
            console.log("triggered current level");

            // Fetch data from Workflow_History table based on vob_id
            var data = await SELECT.from(Workflow_History).where({ vob_id: req.data.vobid });

            if (data.length === 0) {
                throw new Error("No data found for the provided vob_id.");
            }

            // Sort data in descending order based on `end_date_time`
            data.sort((a, b) => {
                // Convert `end_date_time` to Date objects
                const dateA = new Date(a.end_date_time.split(", ")[0].split("/").reverse().join("-") + " " + a.end_date_time.split(", ")[1]);
                const dateB = new Date(b.end_date_time.split(", ")[0].split("/").reverse().join("-") + " " + b.end_date_time.split(", ")[1]);
                // Sort in descending order
                return dateB - dateA;
            });

            // Function to get the next level
            function getNextLevel(currentLevel) {
                if (currentLevel == "0") {
                    return "R1"; // Special case: When level is 0, set it to R1
                }
                let numericLevel = parseInt(currentLevel.slice(1), 10); // Extract the numeric part of the level
                numericLevel++; // Increment the level
                return 'R' + numericLevel; // Return the next level with the 'R' prefix
            }

            var latestEntry = data[0];
            console.log(latestEntry);

            // Get the next level based on the latest entry
            var latestEntryLevel = getNextLevel(data[0].level);

            // Fetch final level data from Approvers table based on vob_id and next level
            var final_level = await SELECT.from(Approvers).where({ vob_id: req.data.vobid, level: latestEntryLevel });

            if (final_level.length === 0) {
                throw new Error(`No approvers found for vob_id: ${req.data.vobid} at level: ${latestEntryLevel}`);
            }

            // Return the final level data
            return final_level;

        } catch (error) {
            console.error("Error occurred:", error.message);
            return { error: error.message }; // Return the error message
        }
    });

    //VOB Wizard ObjectPage Calls
    // Event handler for retrieving the flow status based on vob_id
    this.on('getStatus', async (req) => {
        console.log("STATUS CALLED");

        try {
            const vobid = req.data.vobid; // Extract the vob_id from the request data

            // Fetch workflow data associated with the provided vob_id
            const workflowdata = await SELECT.from(vobMain).where({ id: vobid });

            // Check if any workflow data is retrieved
            if (workflowdata.length == 0) {
                throw new Error("No workflow data found for the given vob_id."); // Handle case where no data is found
            }

            const respdata = workflowdata[0].flowstatus; // Retrieve the flow status

            return respdata; // Return the flow status
        } catch (error) {
            // Log the error for debugging purposes
            console.error("Error fetching flow status:", error);

            // Throw a new error with a user-friendly message
            // throw new Error("An error occurred while retrieving the flow status. Please try again later.");
        }
    });

    this.on('checkdetailsfilled', async (req) => {
        try {
            console.log("In checkdetailsfilled event");

            // Retrieve the vob_id from the request data
            const vob_id = req.data.vobid;
            console.log(`VOB ID: ${vob_id}`);

            // Fetch the suppliers and parts based on the vob_id
            const supplier_final = await SELECT.from(potentialSuplier).where({ vob_id });
            const partfinal = await SELECT.from(YOY).where({ vob_id });

            // Log the lengths of the retrieved arrays for debugging
            console.log(`Number of suppliers: ${supplier_final.length}`);
            console.log(`Number of parts: ${partfinal.length}`);

            // Check if the criteria are met
            if (supplier_final.length >= 2 && partfinal.length >= 1) {
                return true; // Criteria met
            } else {
                return false; // Criteria not met
            }

        } catch (error) {
            // Handle any unexpected errors
            console.error("An error occurred while checking checkdetailsfilled", error);
            // return false; // Optionally return false or an error message depending on your application's needs
        }
    });

    //VOB Supplier Part Images

    const generateSignedUrls = async (folderPath) => {
        const storage = newStorageCall();
        const bucket = storage.bucket(bucketName);

        const [files] = await bucket.getFiles({ prefix: folderPath });
        const signedUrlPromises = files.map(async (file) => {
            const [url] = await file.getSignedUrl({
                action: 'read',
                expires: Date.now() + 5 * 60 * 1000, // 1 hour expiration
            });
            return { fileName: file.name, url };
        });

        return Promise.all(signedUrlPromises);
    };

    this.on('getFilesListVOBSupplierPart', async (req) => {
        const { fileName } = req.data;
        // var fileName = '70ac0c95-4022-4da3-b6e6-4aea987d03f7';

        try {
            // Fetch VOB sequential ID based on the file name
            const sequentialvobid = await SELECT.one.from(vobRequest).where({ id: fileName });

            if (!sequentialvobid) {
                throw new Error('VOB ID not found.');
            }

            // Construct the prefix for GCS
            const prefix = `${basepathvob + sequentialvobid.sequentialvobid + '/Supplier-Part Images'}`;

            // Retrieve signed URLs from GCS
            const signedUrls = await generateSignedUrls(prefix);

            // Log each URL to the console
            signedUrls.forEach(({ fileName, url }) => {
                console.log(`File: ${fileName}, URL: ${url}`);
            });

            // Return the signed URLs
            return signedUrls;

        } catch (error) {
            console.error('File retrieval failed(getFilesListVOBSupplierPart):', error);
            return `Failed to retrieve files: ${error.message}`;
        }
    });

    this.on('getSuppPartDetailsS2', async (req) => {
        try {
            debugger;
            var vobid = req.data.vobid;
            var supOrPart = req.data.supOrPart;

            let data;

            if (supOrPart == 'Supplier') {
                data = await SELECT.from(potentialSuplier).where({ vob_id: vobid });
            } else {
                data = await SELECT.from(YOY).where({ vob_id: vobid });
            }

            console.log(data);
            return JSON.stringify(data);
        } catch (error) {
            console.error("Error in getSuppPartDetailsS2:", error.message);
            return JSON.stringify({ error: "Failed to fetch data. Please try again later." });
        }
    });

    const uploadFile = async (fileName, base64String) => {
        try {
            // Decode base64 string to a Buffer
            const storage = newStorageCall();
            const buffer = Buffer.from(base64String, 'base64');
            const bucket = storage.bucket(bucketName);
            const file = bucket.file(fileName);

            return await new Promise((resolve, reject) => {
                const stream = file.createWriteStream({
                    resumable: true,
                    contentType: 'application/octet-stream',
                    metadata: {
                        cacheControl: 'public, max-age=31536000',
                    },
                });

                stream.on('error', (err) => {
                    console.error('Stream error:', err);
                    reject(new Error('Failed to upload file due to stream error.'));
                });

                stream.on('finish', () => {
                    console.log(`File ${fileName} uploaded to ${bucketName}.`);
                    resolve(`File ${fileName} successfully uploaded.`);
                });

                stream.on('close', () => {
                    console.log('Stream closed.');
                });

                stream.on('destroy', () => {
                    console.error('Stream was destroyed.');
                });

                // Start writing to the stream
                stream.end(buffer);
            });
        } catch (error) {
            console.error("Error in file upload(uploadFile):", error.message);
            // throw new Error('File upload failed.'); // Optionally rethrow or handle the error accordingly
        }
    };
    // Function to scan a file for malware
    async function scanMalwareFile(filedata) {
        const scanApiUrl = process.env.scanApiUrl + "/scan";
        const username = process.env.Musername;
        const password = process.env.Mpassword;

        console.log("Triggered scanMalwareFile");

        try {
            // Decode Base64 to Binary Buffer
            const byteCharacters = Buffer.from(filedata, 'base64'); // Decode base64
            const filePath = path.join(__dirname, 'temp', `tempFile_${Date.now()}`); // Temporary file path

            // Ensure the directory exists
            if (!fs.existsSync(path.dirname(filePath))) {
                fs.mkdirSync(path.dirname(filePath), { recursive: true });
            }

            // Save the binary data to a temp file
            fs.writeFileSync(filePath, byteCharacters);
            console.log("File written to:", filePath);

            // Create FormData
            const formData = new FormData();
            const fileStream = fs.createReadStream(filePath); // Create readable stream

            // Append the file stream to FormData
            formData.append("file", fileStream, "scannedFile");

            // Prepare Headers for Basic Authentication
            const credentials = Buffer.from(`${username}:${password}`).toString('base64');
            const headers = {
                "Authorization": `Basic ${credentials}`,
                ...formData.getHeaders(), // Include headers for FormData
            };

            // Perform POST Request with streaming
            const response = await axios.post(scanApiUrl, formData, { headers });
            console.log("Malware scan result:", response.data);

            // Clean up temporary file
            fs.unlinkSync(filePath);

            return response.data; // Send back to caller if needed
        } catch (error) {
            console.error("Error during malware scan:", error);

            // Clean up temporary file in case of error
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }

            throw new Error("Malware scan process encountered an issue.");
        }





    }



    this.on('uploadFileForVOBSupplierPart', async (req) => {
        const { fileName, stringbase64, path, vobid } = req.data;
        let sequentialvobid = await SELECT.from(vobRequest).where({ id: vobid });
        let updatedFileName = `${basepathvob + sequentialvobid[0].sequentialvobid}/${path}/${fileName}`;

        try {
            var response = await scanMalwareFile(stringbase64);
            var malwareDetected = response.malwareDetected;
            if (malwareDetected == false) {
                // Call the uploadFile function and pass the fileName and base64 string
                console.log("Updated file name", updatedFileName);
                await uploadFile(updatedFileName, stringbase64);
                return updatedFileName;
            }
            else {
                return {
                    status: "error",
                    message: "File upload aborted due to malware detection.",
                    details: response // Optional: include scan details for more context
                };
            }
        } catch (error) {
            console.log('File upload failed(uploadFileForVOBSupplierPart):', error);
            return `Failed to upload file: ${error.message}`;
        }
    });

    this.on('deleteFileForVOBSupplierPart', async (req) => {
        debugger
        const filePath = req.data.fileName;  // Extract the file path from request data
        const vobid = req.data.vobid;  // Extract the file path from request data

        let sequentialvobid = await SELECT.from(vobRequest).where({ id: vobid });
        var updatedFileName

        updatedFileName = `${basepathvob + sequentialvobid[0].sequentialvobid}/${filePath}`;

        try {
            const storage = newStorageCall();

            // Create a reference to the file in Google Cloud Storage
            const bucket = storage.bucket(bucketName);
            const file = bucket.file(updatedFileName);

            // Delete the file
            await file.delete();

            return `File ${filePath} deleted successfully.`;
        } catch (error) {
            console.error('Error deleting file(deleteFileForVOBSupplierPart)');
            return error.message;
        }
    });

    //VOB Request

    this.on('onSubmitFunc', async (req) => {
        try {
            const reqdata = JSON.parse(req.data.status);

            if (reqdata.status == 'submitsecondscreen') {
                console.log("Processing submitsecondscreen");

                // Extract part details and supplier details
                const partdetails = reqdata.partdetails || [];
                const supplier_details_old = reqdata.supplier_details_old || [];

                // Update part details
                if (partdetails.length > 0) {
                    for (const partdetail of partdetails) {
                        await UPDATE(YOY, partdetail.id).with({
                            existing_mgsp_po_price: partdetail.existing_mgsp_po_price,
                            mgsp_vendor_inco_term: partdetail.mgsp_vendor_inco_term,
                            target_price: partdetail.target_price,
                            supplierid: partdetail.supplierid,
                            msgp_supplier_name: partdetail.msgp_supplier_name,
                            finished_weight_of_part: !isNaN(parseFloat(partdetail.finished_weight_of_part))
                                ? parseFloat(partdetail.finished_weight_of_part).toFixed(2)
                                : "0.00"
                        });
                    }
                }



                // Process old suppliers
                if (supplier_details_old.length > 0) {
                    for (const old_supplier_array of supplier_details_old) {
                        await DELETE.from(supplierdetails).where({ id_supplier: old_supplier_array[0].id_supplier });
                        for (const old_supplier_detail of old_supplier_array) {
                            if (old_supplier_detail.value) {
                                await INSERT.into(supplierdetails).entries({
                                    id_supplier: old_supplier_detail.id_supplier,
                                    value_key: old_supplier_detail.value_key,
                                    value: old_supplier_detail.value
                                });
                            }
                        }
                    }
                }
            }

            // Handle selected year submission
            if (reqdata.status == 'selectedyearsubmit') {
                console.log("Triggering vobMain update");
                await UPDATE(vobMain, reqdata.id).with({
                    selected_year: parseInt(reqdata.selected_year)
                });
            }

        } catch (error) {
            console.error("An error occurred in onSubmitFunc:", error);
        }
    });

    this.on('getStatusForRequest', async (req) => {
        // Log that the status request has been called
        console.log("STATUS CALLED");

        // Extract vobid from the request data
        const vobid = req.data.vobid;

        try {
            // Fetch workflow data based on vobid
            const workflowdata = await SELECT.from(vobMain).where({ id: vobid });

            // Check if the request indicates the vob is active
            if (req.data.isActive == 'true') {
                // Fetch draft data associated with the vobid
                const draftvobidData = await SELECT.from(vobRequest.drafts).where({ id: vobid });
                // Log the draft data for debugging
                console.log("Draft Table Vob request Data", JSON.stringify(draftvobidData));

                // If there are any drafts, delete them
                if (draftvobidData.length) {
                    await DELETE.from(vobRequest.drafts).where({ id: vobid });
                }
            }

            // Check if workflow data exists and extract flow status
            if (workflowdata.length > 0) {
                const respdata = workflowdata[0].flowstatus;
                return respdata; // Return the flow status
            } else {
                // Log and throw an error if no workflow data was found
                console.error("No workflow data found for vobid:", vobid);
                // throw new Error("Workflow data not found");
            }
        } catch (error) {
            // Log any errors that occur during the process
            console.error("Error processing getStatusForRequest:", error);
            // Throw an error to indicate a failure in processing the request
            // throw new Error("Internal server error");
        }
    });

    this.on("getyeardata", async (req) => {
        debugger
        var vobdata1 = await SELECT.from(vobRequest).where({ id: req.data.id });
        return JSON.stringify({ vobdata: vobdata1 });;

    })

    //VOB Supplier

    this.on('vendordetails', async (req) => {
        try {
            console.log("Vendordetails event called");

            // Parse the request data
            const reqdata = JSON.parse(req.data.status);
            console.log(`Processing VOB ID: ${reqdata.id}`);

            // Fetch YOY details
            const yoy_details = await SELECT.from(YOY).where({ vob_id: reqdata.id });

            // Fetch suppliers related to the VOB ID
            const suppliers = await SELECT.from(potentialSuplier).where({ vob_id: reqdata.id });

            // Fetch VOB details
            const vob_details = await SELECT.from(vobMain).where({ id: reqdata.id });

            // Initialize an array to hold supplier details
            const suplier_detail_together = [];

            // Loop through each supplier to fetch their details
            for (const supplier of suppliers) {
                // Fetch the supplier details for the current supplier
                const supplierDetails = await SELECT.from(supplierdetails).where({ id_supplier: supplier.id_main });

                // Create a new object for the current supplier
                const newObj = {
                    supplier: supplier.supplier_name, // Assuming supplier is the property containing the supplier name
                    id_main: supplier.id_main,
                    supplier_id: supplier.supplier_id,
                    rel: supplierDetails
                };

                // Push the new object into the array
                suplier_detail_together.push(newObj);
            }

            // Prepare the final details object
            const details_final = JSON.stringify({ yoy_details, suppliers, suplier_detail_together, vob_details });

            // Log the final details for debugging
            console.log("Final details prepared:", details_final);

            // Return the final details
            return details_final;

        } catch (error) {
            // Handle any unexpected errors
            console.error("An error occurred while fetching vendordetails:", error);
            return JSON.stringify({ error: "Failed to fetch vendor details. Please try again later." });
        }
    });

    this.on('commentfunction', async (req) => {
        try {
            console.log("Inside Comment Function");

            // Parse the request data
            const reqdata = JSON.parse(req.data.status);
            console.log(`Fetching comment for ID: ${reqdata.id}`);

            // Fetch comment details based on the provided ID
            let value = await SELECT.from(comment).where({ id: reqdata.id });

            // Convert the fetched value to a JSON string
            value = JSON.stringify(value);

            // Log the fetched comment value for debugging
            console.log("Fetched comment value:", value);

            // Return the JSON string of the comment value
            return value;
        } catch (error) {
            // Handle any errors that occur during the execution
            console.error("An error occurred while fetching the commentfunction:", error);
            return JSON.stringify({ error: "Failed to fetch the comment. Please try again later." });
        }
    });

    this.on("getsearchhelpdata", async (req) => {
        try {
            debugger;
            const srv = cds.services['VOBService'];
            var reqdata = JSON.parse(req.data.status);

            if (reqdata.status == "getsearchhelp") {
                // Fetch the search help data from respective tables
                var sectorsearchhelp_data = await srv.read(Sector_searchhelp);
                var incotermsearchhelp_data = await srv.read(Incoterm_searchhelp);
                var PaymentTerm_searchhelp_data = await srv.read(PaymentTerm_searchhelp);
                var vendorDatalist = await srv.read(vendorsearchhelp);

                // Convert the results to JSON format
                var allsearchhelp_data = JSON.stringify({
                    sectorsearchhelp_data: sectorsearchhelp_data,
                    incotermsearchhelp_data: incotermsearchhelp_data,
                    PaymentTerm_searchhelp_data: PaymentTerm_searchhelp_data,
                    vendorData: vendorDatalist
                });

                return allsearchhelp_data; // Return the proper JSON string
            } else {
                return JSON.stringify({ error: "Invalid request status" });
            }
        } catch (error) {
            console.error("Error in getsearchhelpdata:", error.message);
            return JSON.stringify({ error: "Failed to fetch search help data. Please try again later." });
        }
    });

    this.on('commentadd', async (req) => {

        try {
            // if()
            console.log("Inside Comment Add Function");

            // Parse the request data
            const reqdata = JSON.parse(req.data.status);
            if (reqdata.status == "screen2commentview") {
                var comment_array = reqdata.comment_value;

                // Fetch existing comments for the given ID
                var existingComments = await SELECT.from(comment).where({ id: reqdata.id });

                for (var comment_entry of comment_array) {
                    if (comment_entry.startsWith("Risk Analysis") || comment_entry.startsWith("Investment Breakup") || comment_entry.startsWith("Cash Flow")) {
                        // Look for an existing comment that starts with the same phrase
                        let existingComment = existingComments.find(existing =>
                            existing.comment.startsWith(comment_entry.split(':')[0]) // Match only the starting phrase
                        );

                        if (existingComment) {
                            // Update the existing comment using id_comj
                            await UPDATE(comment)
                                .set({ comment: comment_entry })
                                .where({ id_com: existingComment.id_com }); // Update based on id_com
                        } else {
                            // Insert a new comment if no existing comment matches
                            await INSERT.into(comment).entries({
                                "id": reqdata.id,
                                "comment": comment_entry
                                // "IsActiveEntity": true // Uncomment if needed
                            });
                        }
                    } else {
                        // For other comments, insert directly
                        await INSERT.into(comment).entries({
                            "id": reqdata.id,
                            "comment": comment_entry
                            // "IsActiveEntity": true // Uncomment if needed
                        });
                    }
                }
            }
            else if (reqdata.status == "screen4commentview") {
                var comment_array = reqdata.comment_value;

                // Fetch existing comments for the given ID
                var existingComments = await SELECT.from(comment).where({ id: reqdata.id });

                for (var comment_entry of comment_array) {
                    if (comment_entry.startsWith("Team Recommendation with Rationale") || comment_entry.startsWith("Decision and MOM of Forum")) {
                        // Look for an existing comment that starts with the same phrase
                        let existingComment = existingComments.find(existing =>
                            existing.comment.startsWith(comment_entry.split(':')[0]) // Match only the starting phrase
                        );

                        if (existingComment) {
                            // Update the existing comment using id_comj
                            await UPDATE(comment)
                                .set({ comment: comment_entry })
                                .where({ id_com: existingComment.id_com }); // Update based on id_com
                        } else {
                            // Insert a new comment if no existing comment matches
                            await INSERT.into(comment).entries({
                                "id": reqdata.id,
                                "comment": comment_entry
                                // "IsActiveEntity": true // Uncomment if needed
                            });
                        }
                    } else {
                        // For other comments, insert directly
                        await INSERT.into(comment).entries({
                            "id": reqdata.id,
                            "comment": comment_entry
                            // "IsActiveEntity": true // Uncomment if needed
                        });
                    }
                }

            }

            else {
                console.log(`Adding comment for ID: ${reqdata.id}`);



                // Insert the new comment into the database
                await INSERT.into(comment).entries({
                    "id": reqdata.id,
                    "comment": reqdata.comment_value
                    // "IsActiveEntity": true // Uncomment if needed
                });

                console.log("Comment added successfully.");

                // Fetch the latest comments for the provided ID
                const data = await SELECT.from(comment).where({ id: reqdata.id });
                console.log("Fetched comments:", JSON.stringify(data));

                // Return the fetched comments
                return JSON.stringify(data);
            }
        } catch (error) {
            // Handle any errors that occur during the execution
            console.error("An error occurred while adding the commentadd:", error);
            // return JSON.stringify({ error: "Failed to add the comment. Please try again later." });
        }
    });

    //VOB Document

    // Handler for document screen functionality
    this.on('documentscreenfunc', async (req) => {
        try {
            // Parse the incoming request data
            const reqdata = JSON.parse(req.data.status);

            // Check if the status indicates a request for vendor details
            if (reqdata.status == 'getvendordetails') {
                // Fetch all part details from YOY table
                let partdetails = await SELECT.from(YOY);

                // Fetch YOY details based on the provided vob_id
                let yoy_details = await SELECT.from(YOY).where({ vob_id: reqdata.id });

                // Fetch potential suppliers related to the provided vob_id
                let suppliers = await SELECT.from(potentialSuplier).where({ vob_id: reqdata.id });

                // Fetch the vob document details using the provided vob_id
                let vob_details = await SELECT.from(vobDocument).where({ id: reqdata.id });

                // Array to hold supplier details with their respective supplier information
                let suplier_detail_together = [];

                // Iterate over each supplier to fetch their detailed information
                for (let supplier of suppliers) {
                    try {
                        // Fetch the supplier details for the current supplier
                        let supplierDetails = await SELECT.from(supplierdetails).where({ id_supplier: supplier.id_main });

                        // Create a new object for the current supplier with their details
                        let newObj = {
                            id_main: supplier.id_main,
                            supplier: supplier.supplier_name, // Property containing the supplier name
                            rel: supplierDetails // Related supplier details
                        };

                        // Push the new object into the array
                        suplier_detail_together.push(newObj);
                    } catch (error) {
                        console.error(`Error fetching supplier details for supplier ID ${supplier.id_main}:`, error);
                    }
                }

                let masterSearchHelp = await SELECT.from(Master_workflow)
                let fileSize = parseInt(process.env.FileSize);    //To be dynamically fetched from API
                let fileTypeInString = process.env.AllowedFileTypes

                // Convert the string into an array
                fileTypeInString = JSON.parse(fileTypeInString);

                console.log(fileTypeInString)


                // Prepare the final response string with all relevant data
                let vendorString = JSON.stringify({ suppliers, yoy_details, suplier_detail_together, vob_details, masterSearchHelp, fileSize, fileTypeInString });
                return vendorString; // Return the assembled string containing vendor details
            }

            // Check if the status indicates a request to trigger a workflow
            if (reqdata.status == 'triggerworkflow') {
                const vobid = reqdata.id; // Get the vob_id from the request data

                // Fetch workflow data for the specified vob_id at level 1
                let workflowdata = await SELECT.from(Approvers).where({ vob_id: vobid, level: "R1" });

                // Map the workflow data to extract employee IDs into a comma-separated string
                const result = workflowdata.map(item => item.employee_id).join(', ');

                // Fetch the main vob details using the vob_id
                const vob_details = await SELECT.from(vobMain).where({ id: vobid });
                const sequentialvobid = vob_details[0].sequentialvobid; // Extract the sequential vob ID

                console.log("Triggered triggerworkflow"); // Log the workflow trigger action
                console.log(JSON.stringify("values", `${finalurlapp}`)); // Log connection values

                // Connect to the BPA service for workflow triggers
                const BPA = await cds.connect.to("vobBpaTrigger");
                console.log("inbox link");
                console.log(process.env.INBOXLINK);

                // Define the body of the request to create a new workflow instance
                const body = {
                    "definitionId": `${process.env.definitionId}`,
                    "context": {
                        "users": `${result}`,
                        "currlevel": "R1",
                        "baseurl": `${finalurlapp}`,
                        "vobid": `${vobid}`,
                        "sequentialvobid": `${sequentialvobid}`,
                        "initiatedrequestor": `${reqdata.submitteduser}`,
                        "inboxlink": `${process.env.INBOXLINK}`
                    }
                };

                // Post the request to create a workflow instance
                const response = await BPA.post('/workflow/rest/v1/workflow-instances', body);
                console.log("BPA response:", JSON.stringify(response));
                // Function to parse date strings into Date objects
                function parseDateString(dateString) {
                    const parts = dateString.split(/[\s/:,]+/); // Split by spaces, colons, slashes, and commas
                    const day = parseInt(parts[0], 10);
                    const month = parseInt(parts[1], 10) - 1; // Months are zero-based
                    const year = parseInt(parts[2], 10);
                    var hours = parseInt(parts[3], 10);
                    const minutes = parseInt(parts[4], 10);
                    const seconds = parseInt(parts[5], 10);
                    const ampm = parts[6].toLowerCase(); // AM/PM

                    // Adjust hours based on AM/PM notation
                    if (ampm == "pm" && hours < 12) {
                        hours += 12;
                    } else if (ampm == "am" && hours == 12) {
                        hours = 0;
                    }

                    // Return a new Date object constructed from parsed components
                    return new Date(year, month, day, hours, minutes, seconds);
                }

                // Get the current date and time in a specified format for the workflow
                const BeginDateString = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });
                const beginDate = parseDateString(BeginDateString); // Parse the date string into a Date object
                var workflowId = response.id;

                // Get user information for workflow updates
                const username = reqdata.submitteduser;
                const submittedusername = reqdata.submittedusername;
                await INSERT.into(Workflow_History).entries({
                    workflow_id: workflowId, // New workflow_id from the API response
                    vob_id: vobid, // Existing or new vob_id
                    level: '0',
                    status: 'Request Initiated',
                    begin_date_time: `${BeginDateString}`,
                    end_date_time: `${BeginDateString}`,
                    employee_name: `${submittedusername}`,
                    employee_id: `${username}`,
                    comments: `${reqdata.comment_value}`
                })
                var nextApproval = `${workflowdata[0].employee_name} (${workflowdata[0].level})`;
                // Update the main vob to indicate its workflow status
                await UPDATE(vobMain).set({
                    flowstatus: "Pending For Approval",
                    startedat: nextApproval
                }).where({
                    id: vobid

                });
            }
            if (reqdata.status == "addworkflowdata") {
                var workflowdata = reqdata.workflowdata;
                await DELETE.from(Approvers).where({ vob_id: reqdata.id });


                for (const entry of workflowdata) {
                    await INSERT.into(Approvers).entries({
                        employee_id: entry.employeeId,   // Assuming this corresponds to the first cell
                        employee_name: entry.employeeName, // Assuming this corresponds to the second cell
                        level: entry.level,
                        vob_id: reqdata.id               // Assuming this corresponds to the third cell
                    });
                }

            }
        } catch (error) {
            // Log the error and return a user-friendly message
            console.error("Error processing documentscreenfunc:", error);
            // throw new Error("An error occurred while processing your request. Please try again later.");
        }
    });

    // Event handler for retrieving workflow data
    this.on('workflowdata', async (req) => {
        try {


            const vobid = req.data.vobid;
            if (req.data.status == "approverdata") {

                const workflowdata = await SELECT.from(Approvers).where({ vob_id: vobid });

                // Convert the workflow data to a JSON string for the response
                const respdata = JSON.stringify(workflowdata);

                return respdata;
            }
            else {
                const workflowdata = await SELECT.from(Workflow_History).where({ vob_id: vobid });

                // Convert the workflow data to a JSON string for the response
                const respdata = JSON.stringify(workflowdata);

                return respdata;

            }
            // Return the serialized workflow data
        } catch (error) {
            // Log the error for debugging purposes
            console.error("Error fetching workflow data:", error);

            // Throw a new error with a user-friendly message
            // throw new Error("An error occurred while retrieving workflow data. Please try again later.");
        }
    });

    const getSignedUrl = async (fileName) => {
        try {
            const storage = newStorageCall();
            const bucket = storage.bucket(bucketName);
            const file = bucket.file(fileName);

            // Set expiration time to 10 minutes from now
            const expires = Date.now() + 10 * 60 * 1000; // 10 minutes in milliseconds

            // Generate signed URL
            const [signedUrl] = await file.getSignedUrl({
                action: 'read',
                expires: expires
            });

            return signedUrl;
        } catch (error) {
            console.error('Error getting signed URL from GCS (getSignedUrl)', error);
            // throw new Error(`Failed to generate signed URL: ${error.message}`);
        }
    };

    this.on('getFileForVOB', async (req) => {
        const { fileName } = req.data;

        try {
            // Call the getSignedUrl function and pass the fileName
            const signedUrl = await getSignedUrl(fileName);
            return signedUrl;
        } catch (error) {
            console.error('Signed URL retrieval failed (getFileForVOB)', error);
            return `Failed to retrieve signed URL: ${error.message}`;
        }
    });

    this.on('deleteFileForVOB', async (req) => {
        debugger
        const filePath = req.data.fileName;  // Extract the file path from request data
        try {
            const storage = newStorageCall();

            // Create a reference to the file in Google Cloud Storage
            const bucket = storage.bucket(bucketName);
            const file = bucket.file(filePath);

            // Delete the file
            await file.delete();

            await DELETE.from(Files).where({ folder: filePath });

            return `File ${filePath} deleted successfully.`;
        } catch (error) {
            console.error('Error deleting file(deleteFileForVOB)');
            return error.message;
        }
    });

    this.on('getSignedURLForDocUpload', async (req) => {
        const { fileName, contentType, vobid, path } = req.data;
        const storage = newStorageCall();

        const corsConfig = [
            {
                origin: ['*'], // Replace '*' with your app's origin for stricter security
                method: ['PUT', 'POST', 'GET'], // Allow PUT and POST for file upload
                responseHeader: ['Content-Type', 'Authorization'], // Expose headers
                maxAgeSeconds: 3600, // Cache preflight responses for 1 hour
            },
        ];

        async function configureBucketCors() {
            try {
                await storage.bucket(bucketName).setCorsConfiguration(corsConfig);
                console.log(`Bucket ${bucketName} was updated with a CORS configuration.`);
            } catch (err) {
                console.error('Error configuring CORS:', err);
            }
        }

        await configureBucketCors();

        if (!fileName || !contentType || !vobid || !path) {
            req.error(400, 'File name, content type, VOB ID, and path are required.');
        }

        // Fetch the sequential VOB ID from the database
        let sequentialVobIdData;
        try {
            sequentialVobIdData = await SELECT.from(vobMain).where({ id: vobid });

            if (!sequentialVobIdData || sequentialVobIdData.length === 0) {
                req.error(404, `VOB ID ${vobid} not found.`);
            }
        } catch (err) {
            console.error('Error fetching VOB ID:', err);
            req.error(500, 'Failed to fetch VOB ID from the database.');
        }

        const sequentialVobId = sequentialVobIdData[0].sequentialvobid;

        // Construct the updated file path
        const updatedFileName = `${basepathvob}${sequentialVobId}/${path}/${fileName}`;

        // Generate a signed URL for the updated file path
        const options = {
            version: 'v4',
            action: 'write',
            expires: Date.now() + 15 * 60 * 1000, // URL valid for 15 minutes
            contentType: contentType,
        };

        try {
            const [url] = await storage.bucket(bucketName).file(updatedFileName).getSignedUrl(options);
            return { signedUrl: url, filePath: updatedFileName };
        } catch (err) {
            console.error('Error generating signed URL:', err);
            req.error(500, 'Failed to generate signed URL.');
        }
    })

    this.on('notifyBackendForGCS', async (req) => {
        const { fileName, contentType, vobid, path } = req.data;
        if (fileName) {
            await INSERT.into(Files).entries({
                mediaType: contentType,
                fileName: fileName,
                folder: path,
                vob_id: vobid,
                url: path
            })
        }



        const storage = newStorageCall();

        // CORS Configuration for disabling CORS
        const restrictedCorsConfig = [];

        // Disable CORS configuration
        async function disableCorsForBucket() {
            try {
                await storage.bucket(bucketName).setCorsConfiguration(restrictedCorsConfig);
                console.log(`CORS configuration removed for bucket ${bucketName}.`);
            } catch (err) {
                console.error('Error disabling CORS:', err);
                req.error(500, 'Failed to remove CORS configuration.');
            }
        }

        await disableCorsForBucket();
    });

    this.on('scanMalwareFile', async (req) => {
        const filedata = req.data.filedata; // Assume this contains the base64 string.
        const scanApiUrl = process.env.scanApiUrl + "/scan";
        const username = process.env.Musername;
        const password = process.env.Mpassword;

        console.log("Triggered scanMalwareFile");

        try {
            // Decode Base64 to Binary Buffer
            const byteCharacters = Buffer.from(filedata, 'base64'); // Decode base64
            const filePath = path.join(__dirname, 'temp', `tempFile_${Date.now()}`); // Temporary file path

            // Ensure the directory exists
            if (!fs.existsSync(path.dirname(filePath))) {
                fs.mkdirSync(path.dirname(filePath), { recursive: true });
            }

            // Save the binary data to a temp file
            fs.writeFileSync(filePath, byteCharacters);
            console.log("File written to:", filePath);

            // Create FormData
            const formData = new FormData();
            const fileStream = fs.createReadStream(filePath); // Create readable stream

            // Append the file stream to FormData
            formData.append("file", fileStream, "scannedFile");

            // Prepare Headers for Basic Authentication
            const credentials = Buffer.from(`${username}:${password}`).toString('base64');
            const headers = {
                "Authorization": `Basic ${credentials}`,
                ...formData.getHeaders(), // Include headers for FormData
            };

            // Perform POST Request with streaming
            const response = await axios.post(scanApiUrl, formData, { headers });
            console.log("Malware scan result:", response.data);

            // Clean up temporary file
            fs.unlinkSync(filePath);

            return response.data; // Send back to caller if needed
        } catch (error) {
            console.error("Error during malware scan:", error);

            // Clean up temporary file in case of error
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }

            throw new Error("Malware scan process encountered an issue.");
        }
    });


    //VOB Approval

    const getFilesInPath = async (folderPath) => {
        try {
            const storage = newStorageCall();
            const bucket = storage.bucket(bucketName);

            // List all files in the specified folder
            const [files] = await bucket.getFiles({ prefix: folderPath });

            // If no files found, throw an error
            if (files.length == 0) {
                throw new Error('No files found in the specified path.');
            }

            // Parallelize the file downloads using Promise.all for faster processing
            const base64Files = await Promise.all(files.map(async (file) => {
                const [fileBuffer] = await file.download();
                const base64String = fileBuffer.toString('base64');
                return { fileName: file.name, content: base64String };
            }));

            // Return the array of base64 encoded file contents
            return base64Files;
        } catch (error) {
            console.error('Error getting files from GCS(getFilesInPath):', error);
            // throw new Error(`Failed to retrieve files: ${error.message}`);
        }
    };

    this.on('getFilesListVOBSupplierPartPdf', async (req) => {
        const { fileName } = req.data;

        try {
            // Fetch VOB sequential ID based on the file name
            const sequentialvobid = await SELECT.one.from(vobRequest).where({ id: fileName });

            if (!sequentialvobid) {
                throw new Error('VOB ID not found.');
            }

            // Construct the prefix for GCS
            const prefix = `${basepathvob + sequentialvobid.sequentialvobid + '/Supplier-Part Images'}`;

            // Retrieve files from GCS
            const base64Files = await getFilesInPath(prefix);

            return base64Files; // Return an array of base64 encoded files
        } catch (error) {
            console.error('File retrieval failed(getFilesListVOBSupplierPart):', error);
            return `Failed to retrieve files: ${error.message}`;
        }
    });

    //VOB Workflow Functions

    this.on('workflowfun', async (req) => {
        // Start of the workflow function
        console.log("Workflow function called");
        var commentsValue = req.data.comments;
        // commentsValue = decodeURIComponent(commentsValue);
        // commentsValue = JSON.parse(commentsValue);

        // Check if the status is "Approved"
        if (req.data.status == "Approved") {
            // Function to parse date strings into Date objects
            function parseDateString(dateString) {
                var parts = dateString.split(/[\s/:,]+/); // Split the string by spaces, colons, slashes, and commas
                var day = parseInt(parts[0], 10);
                var month = parseInt(parts[1], 10) - 1; // Months are zero-based
                var year = parseInt(parts[2], 10);
                var hours = parseInt(parts[3], 10);
                var minutes = parseInt(parts[4], 10);
                var seconds = parseInt(parts[5], 10);
                var ampm = parts[6].toLowerCase();

                // Adjust hours based on AM/PM
                if (ampm == "pm" && hours < 12) {
                    hours += 12;
                } else if (ampm == "am" && hours == 12) {
                    hours = 0;
                }

                return new Date(year, month, day, hours, minutes, seconds);
            }

            try {
                // Fetch workflow history data based on level and vob_id
                var data = await SELECT.from(Workflow_History).where({ vob_id: req.data.vob_id });

                // Sort data in descending order based on `begin_date_time`
                data.sort((a, b) => {
                    // Convert `begin_date_time` to Date objects
                    const dateA = new Date(a.end_date_time.split(", ")[0].split("/").reverse().join("-") + " " + a.end_date_time.split(", ")[1]);
                    const dateB = new Date(b.end_date_time.split(", ")[0].split("/").reverse().join("-") + " " + b.end_date_time.split(", ")[1]);

                    // Sort in descending order
                    return dateB - dateA;
                });

                var latestEntry = data[0];
                console.log("LAST Entry", latestEntry);
                // Get the start date and current date for calculations
                var startDateString = latestEntry.end_date_time;
                var endDateString = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });

                // Parse the start and end date strings
                var startDate = parseDateString(startDateString);
                var endDate = parseDateString(endDateString);

                // Calculate the difference in milliseconds and convert to days
                var differenceInMilliseconds = endDate - startDate;
                var differenceInDays = Math.round(differenceInMilliseconds / (1000 * 60 * 60 * 24));

                // Log the person who approved or rejected
                console.log(req.data.app_rej_by);

                var oApproverData = await SELECT.from(Approvers).where({ employee_id: `${req.data.app_rej_by}`, vob_id: req.data.vob_id });

                // Update the workflow history with approved status and other details
                await INSERT.into(Workflow_History).entries({
                    employee_id: `${oApproverData[0].employee_id}`,
                    employee_name: `${oApproverData[0].employee_name}`,
                    begin_date_time: `${latestEntry.end_date_time}`,
                    status: 'Approved',
                    end_date_time: `${endDateString}`,
                    days_taken: `${differenceInDays}`,
                    vob_id: req.data.vob_id,
                    level: req.data.level,
                    comments: commentsValue
                })

                // Increment the level for the next workflow step
                let currentLevel = req.data.level;
                let newLevel;

                // Increment the level based on its current value
                if (currentLevel.startsWith('R')) {
                    newLevel = `R${parseInt(currentLevel.slice(1)) + 1}`; // Increment R levels
                } else {
                    console.error('Invalid level format'); // Log error if level format is not R
                }

                console.log(newLevel); // Outputs the new level

                // Fetch the next level workflow data
                var nextLevelWFData = await SELECT.from(Approvers).where({ level: `${newLevel}`, vob_id: req.data.vob_id });
                if (!nextLevelWFData.length) {
                    // If no next level, update the main VOB status to 'Approved'
                    await UPDATE(vobMain, { id: req.data.vob_id }).with({
                        flowstatus: 'Approved',
                        startedat: ''
                    });
                    return 'No level'; // Indicate there are no further levels
                }
                var nextApproval = `${nextLevelWFData[0].employee_name} (${nextLevelWFData[0].level})`;
                await UPDATE(vobMain, { id: req.data.vob_id }).with({
                    startedat: nextApproval
                });
                // Prepare a string with employee IDs from the next level workflow data
                let usersdata = '';
                console.log("Got data from nextLevelWFData");
                for (let i = 0; i < nextLevelWFData.length; i++) {
                    var empid = nextLevelWFData[i].employee_id;
                    usersdata += empid + ' ,'; // Concatenate employee IDs
                }

                return usersdata; // Return the employee IDs

            } catch (error) {
                // Log any errors that occur during processing
                console.error("Error processing  workflowfun:", error);
                // throw new Error("Failed to process approved workflow");
            }

        } else {
            // Handle the case where the status is not "Approved"
            console.log("Status is not Approved");

            // Date parsing function
            function parseDateString(dateString) {
                var parts = dateString.split(/[\s/:,]+/); // Split the string by spaces, colons, slashes, and commas
                var day = parseInt(parts[0], 10);
                var month = parseInt(parts[1], 10) - 1; // Months are zero-based
                var year = parseInt(parts[2], 10);
                var hours = parseInt(parts[3], 10);
                var minutes = parseInt(parts[4], 10);
                var seconds = parseInt(parts[5], 10);
                var ampm = parts[6].toLowerCase();

                // Adjust hours based on AM/PM
                if (ampm == "pm" && hours < 12) {
                    hours += 12;
                } else if (ampm == "am" && hours == 12) {
                    hours = 0;
                }

                return new Date(year, month, day, hours, minutes, seconds);
            }

            try {
                // Fetch workflow history data based on level and vob_id
                var data = await SELECT.from(Workflow_History).where({ vob_id: req.data.vob_id });

                // Sort data in descending order based on `begin_date_time`
                data.sort((a, b) => {
                    // Convert `begin_date_time` to Date objects
                    const dateA = new Date(a.begin_date_time.split(", ")[0].split("/").reverse().join("-") + " " + a.begin_date_time.split(", ")[1]);
                    const dateB = new Date(b.begin_date_time.split(", ")[0].split("/").reverse().join("-") + " " + b.begin_date_time.split(", ")[1]);

                    // Sort in descending order
                    return dateB - dateA;
                });

                var latestEntry = data[0];
                console.log("LAST Entry", latestEntry);



                var startDateString = latestEntry.end_date_time;
                var endDateString = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });

                // Parse the start and end date strings
                var startDate = parseDateString(startDateString);
                var endDate = parseDateString(endDateString);

                // Calculate the difference in milliseconds and convert to days
                var differenceInMilliseconds = endDate - startDate;
                var differenceInDays = Math.round(differenceInMilliseconds / (1000 * 60 * 60 * 24));

                console.log(req.data.app_rej_by);

                var oApproverData = await SELECT.from(Approvers).where({ employee_id: `${req.data.app_rej_by}`, vob_id: req.data.vob_id });
                console.log("Approvers Data", oApproverData);
                // Update the workflow history with approved status and other details
                await INSERT.into(Workflow_History).entries({
                    employee_id: `${oApproverData[0].employee_id}`,
                    employee_name: `${oApproverData[0].employee_name}`,
                    begin_date_time: `${latestEntry.end_date_time}`,
                    status: 'Rejected',
                    end_date_time: `${endDateString}`,
                    days_taken: `${differenceInDays}`,
                    vob_id: req.data.vob_id,
                    level: req.data.level,
                    comments: commentsValue
                })

                // Update the main VOB status to 'Rejected'
                await UPDATE(vobMain, { id: req.data.vob_id }).with({
                    flowstatus: 'Rejected',
                    startedat: ''
                });
                return 'No level'; // Indicate there are no further levels

            } catch (error) {
                // Log any errors that occur during processing
                console.error("Error processing rejected workflowfun:", error);
                // throw new Error("Failed to process rejected workflow");
            }
        }
    });

    //Folder Structure App

    const sbuBasePath = 'BTP/SBU Value Fit'

    this.on('getDocumentsByPath', async (req) => {
        try {
            debugger;
            var sPath = req.data.sPath;
            console.log(sPath);

            // Initialize the storage
            const storage = newStorageCall();

            // Determine the full path based on sPath
            let folderwithpart;
            if (sPath.startsWith("/")) {
                folderwithpart = sbuBasePath + sPath;
            } else {
                folderwithpart = basepath + sPath;
            }

            console.log("Full folder path:", folderwithpart);

            // Fetch files from the specified bucket and folder
            const [files] = await storage.bucket(bucketName).getFiles({
                prefix: folderwithpart
            });

            // Extract file names
            let filesNameArray = [];
            files.forEach(file => {
                if (file.name != folderwithpart) {
                    filesNameArray.push(file.name);
                }

            });

            console.log("Files found:", filesNameArray);

            // Return file names as JSON
            return JSON.stringify(filesNameArray);

        } catch (error) {
            console.error("Error in getDocumentsByPath:", error.message);
            return JSON.stringify({ error: "Failed to retrieve documents. Please check the path and try again." });
        }
    });

    this.on("getFile", async (req) => {

        var filename = req.data.fileName;
        if (filename.startsWith("/")) {
            var fileLoc = sbuBasePath + filename;
        }
        else {
            var fileLoc = basepath + filename;
        }

        try {
            const signedUrl = await getSignedUrl(fileLoc);
            return signedUrl;
        } catch (error) {
            console.error('Error downloading file getFile:', error);
            // throw error;  // Propagate the error to be handled by the caller
        }
    });

    this.on('getFilesList', async (req) => {
        let auth = req?.headers?.authorization;

        const fileName = sbuBasePath + req.data.fileName;  // Extract fileName from request data
        debugger
        try {
            // Get a reference to the bucket
            const storage = newStorageCall();

            // List files in the bucket that match the fileName pattern
            // const [files] = await bucket.getFiles({ prefix: fileName });
            const [files] = await storage.bucket(bucketName).getFiles({
                prefix: fileName
            });

            // Map the file names to an array of file names
            const fileNames = files.map(file => file.name);

            function createFolderStructure(files) {
                const root = {
                    text: "BTP/SBU Value Fit",
                    nodes: []
                };

                files.forEach(file => {
                    const parts = file.split('/');
                    let currentNode = root;

                    // Traverse parts: parts[1] = part1, parts[2] = vendor 1, parts[3] = subfolders, etc.
                    parts.slice(1).forEach((part, index) => {
                        if (!currentNode.nodes) {
                            currentNode.nodes = [];
                        }

                        let existingNode = currentNode.nodes.find(node => node.text == part.trim());

                        if (!existingNode) {
                            existingNode = { text: part.trim() };
                            currentNode.nodes.push(existingNode);
                        }

                        currentNode = existingNode;
                    });
                });

                return root;
            }

            function createFolderStructureCustom(files, fileName) {
                const root = {
                    text: fileName,
                    nodes: []
                };

                files.forEach(file => {
                    const parts = file.split('/');
                    let currentNode = root;

                    // Traverse parts: parts[1] = part1, parts[2] = vendor 1, parts[3] = subfolders, etc.
                    parts.slice(1).forEach((part, index) => {
                        if (!currentNode.nodes) {
                            currentNode.nodes = [];
                        }

                        let existingNode = currentNode.nodes.find(node => node.text == part.trim());

                        if (!existingNode) {
                            existingNode = { text: part.trim() };
                            currentNode.nodes.push(existingNode);
                        }

                        currentNode = existingNode;
                    });
                });

                return root;
            }
            var folderStructure
            if (!req.data.fileName.trim()) {
                folderStructure = createFolderStructure(fileNames);
            }
            else {
                // Trim the file paths, keeping only the portion after 'PPT'
                var lastFolder = fileName.split('/').pop();
                const newFileName = fileName.replace(lastFolder, '');
                let trimmedFiles = fileNames.map(file => {
                    if (typeof file == 'string') {
                        return file.replace(newFileName, '');
                    } else {
                        console.warn(`Skipping non-string element: ${file}`);
                        return file; // or handle non-string elements as needed
                    }
                });
                console.log(trimmedFiles);


                console.log(lastFolder);
                folderStructure = createFolderStructureCustom(trimmedFiles, lastFolder);
            }


            return JSON.stringify(folderStructure, null, 2);
            // Return the list of file names as a JSON string
            // return JSON.stringify(trimmedAndSplitFiles);
        } catch (error) {
            console.error('Error listing files getFilesList:', error);
            // throw new Error(`Failed to list files: ${error.message}`);
        }
    });

    this.on('uploadFile', async (req) => {
        debugger
        try {
            const storage = newStorageCall();

            const stringbase64 = req.data.stringbase64;
            var oFileName = req.data.fileName;
            if (oFileName.startsWith("/")) {
                var fileLoc = sbuBasePath + oFileName;
            }
            else {
                var fileLoc = basepath + oFileName;
            }

            // Extract the fileName

            const fileName = fileLoc.split('/').pop();  // Extract the last part after splitting by '/'
            console.log(fileName);



            // Decode base64 string to a Buffer
            const buffer = Buffer.from(stringbase64, 'base64');
            const bucket = storage.bucket(bucketName);
            // Create a file object in the specified bucket
            const file = bucket.file(fileLoc);

            // Create a stream to upload the file to GCS
            const stream = file.createWriteStream({
                resumable: false, // Can set to true for larger files
                contentType: 'application/octet-stream', // Optional: set the correct content type
                metadata: {
                    cacheControl: 'public, max-age=31536000',
                },
            });
            function upload() {
                return new Promise((resolve, reject) => {
                    stream.on('error', (err) => {
                        console.error('Error uploading file:', err);
                        reject(err);
                    });

                    stream.on('finish', () => {
                        console.log(`File ${fileName} uploaded to ${bucketName}.`);
                        resolve(`File ${fileName} successfully uploaded.`);
                    });

                    // Write the buffer to the file stream
                    stream.end(buffer);
                });

            }
            await upload();
            console.log(`File uploaded to ${bucketName}`);
            // fs.unlink(filePath, (err) => {
            //     if (err) {
            //         console.error(`Error deleting file: ${err.message}`);
            //         return;
            //     }
            //     console.log('File deleted successfully');
            // });

            return "file saved";
        } catch (error) {
            console.log("file upload(uploadFile)", error);
            // return error;
        }
    });

    this.on('deleteFile', async (req) => {
        debugger
        const storage = newStorageCall();
        // const filePath = basepath + req.data.fileName;  // Extract the file path from request data
        var filename = req.data.fileName;
        if (filename.startsWith("/")) {
            var filePath = sbuBasePath + filename;
        }
        else {
            var filePath = basepath + filename;
        }
        try {
            // Create a reference to the file in Google Cloud Storage
            const bucket = storage.bucket(bucketName);
            const file = bucket.file(filePath);

            // Delete the file
            await file.delete();
            var myfile = filename.split('/').pop();
            return `File ${myfile} deleted successfully.`;
        } catch (error) {
            console.error('Error deleting file(deleteFile):', error);
            return error;
        }
    });

    this.on('getrole', async (req) => {
        try {
            let auth = req?.headers?.authorization;
            var decoded;
            let fileSize = parseInt(process.env.FileSize);    //To be dynamically fetched from API
            let fileTypeInString = process.env.AllowedFileTypes

            // Convert the string into an array
            let fileTypeInArray = JSON.parse(fileTypeInString);

            console.log(fileTypeInString)
            if (process.env.NODE_ENV === 'production') {
                if (process.env.isDev) {
                    let resultAlongWithRoles = {
                        userrole: "Admin",
                        fileSizeLimit: fileSize,
                        AllowedFileTypes: fileTypeInArray
                    }
                    return JSON.stringify(resultAlongWithRoles);
                }

                if (auth != undefined) {
                    let token = auth.split(" ");
                    if (token[0] == 'Basic') {
                        let decod = atob(token[1]);
                        let decode = decod.split(":");
                        decoded = {
                            "user_name": decode[0]
                        };
                        console.log(JSON.stringify(decoded));
                    } else if (token[0] == 'Bearer') {
                        decoded = jwtDecode(token[1]);
                        console.log(JSON.stringify(decoded));
                    }
                }

                if (!decoded || !decoded["xs.system.attributes"] || !decoded["xs.system.attributes"]["xs.rolecollections"]) {
                    throw new Error("Role collections not found in decoded token");
                }

                var roleCollections = decoded["xs.system.attributes"]["xs.rolecollections"];
                var userrole;

                for (let i = 0; i < roleCollections.length; i++) {
                    if (roleCollections[i] == "VOBFolderViewer") {
                        userrole = "Viewer";
                        break;
                    } else if (roleCollections[i] == "VOBFolderAdmin") {
                        userrole = "Admin";
                        break;
                    }
                }

                console.log("User Role", userrole);
                let resultAlongWithRoles = {
                    userrole: userrole || "No role found",
                    fileSizeLimit: fileSize,
                    AllowedFileTypes: fileTypeInArray
                }
                return JSON.stringify(resultAlongWithRoles);
            } else {
                let resultAlongWithRoles = {
                    userrole: "Admin",
                    fileSizeLimit: fileSize,
                    AllowedFileTypes: fileTypeInArray
                }
                return JSON.stringify(resultAlongWithRoles);
            }

        } catch (error) {
            console.error("Error in getrole handler:", error.message);
            return "Error determining role"; // You can return a custom error message or handle the error accordingly
        }
    });

    this.on('getSignedURLForFolderStructure', async (req) => {
        const { path, contentType } = req.data;
        const storage = newStorageCall();

        const corsConfig = [
            {
                origin: ['*'], // Replace '*' with your app's origin for stricter security
                method: ['PUT', 'POST', 'GET'], // Allow PUT and POST for file upload
                responseHeader: ['Content-Type', 'Authorization'], // Expose headers
                maxAgeSeconds: 3600, // Cache preflight responses for 1 hour
            },
        ];

        async function configureBucketCors() {
            try {
                await storage.bucket(bucketName).setCorsConfiguration(corsConfig);
                console.log(`Bucket ${bucketName} was updated with a CORS configuration.`);
            } catch (err) {
                console.error('Error configuring CORS:', err);
            }
        }

        await configureBucketCors();

        if (!path) {
            req.error(400, ' path is required.');
        }


        // Construct the updated file path
        const updatedFileName = sbuBasePath + path;

        // Generate a signed URL for the updated file path
        const options = {
            version: 'v4',
            action: 'write',
            expires: Date.now() + 15 * 60 * 1000, // URL valid for 15 minutes
            contentType: contentType,
        };

        try {
            const [url] = await storage.bucket(bucketName).file(updatedFileName).getSignedUrl(options);
            return { signedUrl: url, filePath: updatedFileName };
        } catch (err) {
            console.error('Error generating signed URL:', err);
            req.error(500, 'Failed to generate signed URL.');
        }
    })
    this.on('create_folder', async (req) => {

        try {
            const folderName = sbuBasePath + '/' + req.data.path;
            const storage = newStorageCall();
            const file = storage.bucket(bucketName).file(folderName);
            await file.save(''); // Saving an empty string as file content     
            console.log(`Folder "${folderName}" created successfully in bucket "${bucketName}".`);
            return `Folder Created Successfully`;
        }
        catch (error) {
            console.error('Error creating folder:', error);
            return ' Error while creating folder';
        }
    })
})